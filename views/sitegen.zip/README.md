# SiteGen

A live, editable website builder. Users sign up, fill in simple forms
(hero, about, services, testimonials, gallery, FAQ, hours, contact),
and publish a real, public website instantly — paste the URL of an old
website to have it modernized automatically, or just type a business type
("plumbing company", "hair salon") to generate a full starting site with
real photos.

## Run it

**Windows (easiest):** double-click `start.bat`. It installs what's needed,
creates your `.env` (with a random `SESSION_SECRET`) the first time, stops an
old copy still holding the port, starts the server and opens your browser.
Leave the window open while you use SiteGen; close it (or press Ctrl+C) to stop.

**Anywhere else, or by hand:**

```
npm install
cp .env.example .env   # then edit SESSION_SECRET in .env
node server.js
```

Then open http://localhost:3000

Run the automated tests:

```
npm test
```

## Core features

- Sign up / log in with email + password (bcrypt-hashed, session-based auth).
- Dashboard listing all of a user's sites.
- Form-based editor: hero, about, services, testimonials, gallery, FAQ,
  hours, and contact sections, plus a theme picker (colors, font, style,
  logo). Changes autosave a second or so after you stop typing, with a
  full "Save changes" button as a fallback.
- **Drag to reorder sections**, and hide any section from the published
  page without deleting its content.
- **Version history** — every save snapshots the previous version (last 10
  kept), restorable with one click.
- **Image uploads** — upload a photo directly instead of only pasting a URL,
  for the hero background, logo, and each gallery image.
- Publishing makes the site live at `/site/:slug`. Unpublishing takes it
  down again. Users can only edit their own sites.
- **Every site is a real multi-page site** — Home is just the hero, featured
  photos, and a closing call-to-action; About, Services, Reviews, Why Choose
  Us, Gallery, FAQ, Hours, and Contact each get their own page/URL (e.g.
  `/site/:slug/about`), linked from a real nav bar instead of in-page jump
  links. A page only exists (and only appears in the nav) if its section is
  visible and has content — an empty or hidden section's URL 404s. This
  applies to every site automatically, including ones built before this
  existed. The editor's preview panel has a page picker so you can preview
  each page on its own.
- **SEO basics** — per-site page title and meta description, plus a global
  `/sitemap.xml` (published sites only) and `/robots.txt`.
- **Custom domains** — set a domain on a site and, once its DNS points at
  wherever this app is deployed, visitors to that domain see the site.
- An automatic map embed appears on the contact section whenever an
  address is filled in.
- **"Why Choose Us" section** — a row of colored icon cards (pick from 10
  icons) for short, scannable reasons to choose the business. Hidden
  automatically until at least one reason is added.
- **A real, working contact form** on the published page (toggle it on/off
  per site in the Contact section) — visitors can send a message and
  optionally attach a photo. Submissions land on a **Leads** page in the
  editor (linked from the top bar, with an unread-style count), never in
  fabricated form; spam is screened with an invisible honeypot field. A
  dedicated rate limit protects the endpoint since it's reachable by anyone
  who finds the live site.
- **Top phone/social bar + social links** — set Facebook/Instagram/Twitter
  URLs in the Contact section and they show as icon links in a thin top bar
  and in the footer; the top bar also surfaces the phone number if one is
  set.
- **Featured photo row** — if a gallery has photos, the first two appear as
  a large side-by-side pair right under the hero, before the smaller
  gallery grid further down the page.
- **Testimonials support a real star rating and date** (both optional, and
  both exactly what the business owner enters — nothing is invented or
  defaulted to 5 stars).
- **Client intake on the dashboard** — "Client details (optional)" under
  *Generate a site*: phone, email, address, weekday/Saturday/Sunday hours,
  Facebook/Instagram links and a brand color. Anything filled in lands in the
  new site (contact page, hours page, social links, theme color) so there's
  far less to fix by hand. Blank fields are left alone.
- **"Before you publish" checklist** at the top of the editor, refreshed
  after every autosave. Red items would look unfinished to a visitor (no
  phone/email, the default Mon–Fri 9–5 hours still in place, empty About
  or Services); tips are nice-to-haves (hero photo, address for the map,
  SEO description, real reviews).
- **Duplicate** button on each site in the dashboard — copies the content,
  theme and layout into a new draft (never published, no custom domain).
- **Email alerts for contact-form leads** — see "Email alerts" below.
- **Search & sharing polish** on every published page: canonical link,
  Open Graph / Twitter share tags (with absolute image URLs), a favicon
  generated from the brand color and business initial, and `LocalBusiness`
  structured data built only from what the owner entered (nothing invented).
  `/sitemap.xml` lists every real page of every published site (on a custom
  domain it lists just that site), and `robots.txt` points to it. The editor
  preview is marked `noindex`.
- **Photo cleanup** — uploaded photos (and photos sent through the contact
  form) are auto-rotated and shrunk to at most 1920px (1600px for visitor
  photos) so phone-camera originals don't slow the site down. If the optional
  `sharp` package can't load on a machine, uploads are simply kept as-is.
  Photos attached to spam or rejected submissions are deleted, not kept.
- **Export** button in the editor — downloads the finished site as a zip of
  plain HTML files (`index.html`, `about.html`, …) with its uploaded photos
  bundled and links rewritten to work from any folder or web host. The
  contact form is left out of the export (it needs this server to receive
  messages); phone, email, address and map still show.

## Email alerts

Off by default. To get an email whenever someone submits a site's contact
form, add SMTP settings to `.env` (see `.env.example`):

```
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=you@gmail.com
SMTP_PASS=your-google-app-password
```

(For Gmail, create an *app password* in your Google account's security
settings; your normal password won't work.) Each site's Contact section has
a "Send new-message alerts to" field; if it's blank the alert goes to the
site's contact email. Replying to the alert replies to the visitor. If
sending ever fails, the visitor's message is still saved on the Leads page —
the failure is only logged in the server window.

- **AI-written copy** (optional, see "AI-written copy" below) — instead of generic
  template text, Claude writes the headline, About text, services, FAQ and search
  description from the client's real details, with strict rules against inventing
  licenses, years, guarantees or other claims. A "Rewrite text with AI" box in the
  editor redoes the copy later (with optional direction like "more premium"); the
  previous version is saved to history first.
- **Photo picker** — a "Choose photo" button next to the hero, About and gallery
  image fields opens a searchable grid of free Pexels photos (needs the Pexels key).
- **Trust & credentials** — owner-entered badges ("Licensed & Insured"), highlight
  numbers ("12 Years in business"), a service-area list, a Google reviews link, and
  before/after photo pairs. They show as a trust strip on the home page, an
  "Areas We Serve" block on the About page, a Google button on the Reviews page and a
  before/after section on the Gallery page; the service area also goes into the
  search-engine data. Nothing is filled in automatically.
- **Honest checklist** — the "Before you publish" panel now also flags claims in the
  text (licensed, insured, 24/7, same-day, free estimates, guarantees…) until the
  owner confirms them.
- **Client edit link** — in the editor's "Client access" box, create a private link
  your client can open (no account) to update their headline, About text, services,
  hours, contact details and photos. They can't touch the design, publishing, domain,
  credentials or reviews. Replace or turn off the link any time; every client save is
  kept in version history.
- **Full backup** — an admin-only "Download a full backup" link on the dashboard
  (zip with the whole database and all uploaded photos).

- **Local SEO** — set a **Main city** (editor → "Local SEO & tracking", or the
  "City" box when generating). It goes into the page titles, a small
  "Roofer in Orlando, FL" tag above the home headline, the Services page, the
  footer, and the business details Google reads. **Every service gets its own
  page** (`/site/<name>/services/roof-repair`) with the city in its heading, a
  built-in quote form, links to the other services and the service-area list.
  Add a few sentences of real text per service in the editor (or use "Rewrite
  text with AI") — a service page only goes into the sitemap, and is only
  indexable, once it has its own text, so thin duplicate pages don't hurt you.
- **Quote requests that convert** — the contact form is now "Request a quote"
  with a **Service needed** dropdown (the chosen service shows on the Leads page
  and in the email alert). Submitting sends the visitor to a **Thank-you page**.
  On phones a **Call Now / Get a Quote bar** stays at the bottom of every page.
  Links like `/contact?service=Roof%20Repair` preselect a service (handy for ads).
- **Tracking (optional)** — paste a **Google Analytics ID** (`G-…`) and/or a
  **Meta Pixel ID** under "Local SEO & tracking". Only the live site is tracked,
  never the preview. A finished quote request counts as a lead
  (`generate_lead` / `Lead`) and a tap on the phone number as a call. Depending
  on where visitors are, the business may need a cookie/privacy notice.

- **Lead follow-up** — the Leads page now has **New / Contacted / Won / Lost**
  statuses, a private note on each lead, filter tabs and a **CSV download**. Turn
  on "Email visitors a 'we received your request' note" in the Contact section to
  send each visitor a short receipt (needs email sending set up; replies go to your
  alert address).
- **Real reviews** — the **Reviews** button in the editor gives you a review link
  (`/site/<name>/review`, or `/review` on the client's own domain), a ready-to-paste
  message, and (with email set up) a button to email the request. Customers' reviews
  wait for your **Approve / Reject**; approved ones go onto the Reviews page. The
  link is meant for every customer, not only happy ones; Google and review sites
  forbid filtering who you ask.
- **Client reports** — the **Report** button shows page views (counted without
  cookies or personal data, bots excluded), leads, what people asked about, new
  reviews and the most viewed pages for 7, 30 or 90 days, printable as a PDF.
  Clients see the same report from their private edit link. Add a "Send monthly
  website reports to" address (Local SEO & tracking) and last month's numbers are
  emailed automatically on the first run each month (email must be set up).
- **Town pages** — every town in the service-area list gets its own page
  ("Roofing company in Kissimmee"). Write something true and specific per town in
  the editor; a town page only goes in the sitemap once it has text.
- **Blog / News & tips** and **Extra pages** (Financing, Service plans, Careers ...)
  — new blocks in the editor. Posts get their own pages; each extra page gets its
  own address and a menu link. Both are included in the sitemap and the static export.

## AI-written copy

Off by default (sites use the built-in templates). To turn it on, get an API key from
https://console.anthropic.com and add it to `.env`:

```
ANTHROPIC_API_KEY=your-key-here
```

Each generated site or rewrite makes one API call (typically a few cents). The model
can be changed with `ANTHROPIC_MODEL`. If the call ever fails, the site is built from
the templates instead, so generating never breaks. **Always read AI (and template) text
before publishing** — the prompt forbids invented facts, but only the owner knows what
is actually true.

## Putting it online (HTTPS for client domains)

Running SiteGen on your own computer is fine for building sites; to host client sites
for real you need it on an always-on server (a small VPS works). The `deploy/` folder
has what's needed:

1. On the server install Node.js and [Caddy](https://caddyserver.com/docs/install), copy
   the project there, run `npm install`, and fill in `.env` — set `NODE_ENV=production`,
   a strong `SESSION_SECRET`, `APP_DOMAIN=app.yourcompany.com` (where you log in) and
   optionally `ADMIN_EMAIL`.
2. Keep SiteGen running with `deploy/sitegen.service` (systemd) or any process manager.
3. Run Caddy with `deploy/Caddyfile`. It gets and renews free HTTPS certificates
   automatically for the dashboard domain and for every client's custom domain the
   first time it is visited. Before issuing one it asks SiteGen (`/internal/domain-check`)
   whether it really hosts that domain: only published sites with that exact custom
   domain (or `APP_DOMAIN`) are approved.
4. Point DNS at the server: an A record for `APP_DOMAIN`, and for each client domain
   (enter it in the site's "Custom domain" box exactly as visitors will type it, e.g.
   `www.clientsite.com`).

Back up regularly with the dashboard's backup link. To restore: stop SiteGen, put
`sitegen.db` from the zip into `data/` and the `uploads/` files into `public/uploads/`.

## Generate a site from a business type

From the dashboard, type a business type (e.g. "plumbing company", "hair
salon", "Italian restaurant") and optionally a business name, then click
"Generate site." The app:

1. Matches the business type against a library of ~25 common local-business
   categories (plumbing, electrical, HVAC, landscaping, cleaning, roofing,
   contracting, auto repair, salon, spa, restaurant, bakery, law, accounting,
   real estate, dental, veterinary, fitness, photography, pet grooming, IT
   services, moving, pest control, painting, and more) — or falls back to a
   generic small-business template if nothing matches
2. Fills in a real headline, about text, 3-4 services with descriptions, and
   FAQ entries for that category
3. Pulls real, free-to-use stock photos for the hero image and gallery from
   Pexels, matched to the business type
4. Creates the site and sends you to the editor to review, personalize, and
   publish

**To enable real photos**, get a free Pexels API key:

1. Go to https://www.pexels.com/api/ and click "Get Started" (a free
   Pexels account is all that's required — no credit card)
2. Copy your API key from the dashboard it gives you
3. Paste it into `.env` as `PEXELS_API_KEY=your-key-here`
4. Restart the server (`Ctrl+C`, then `node server.js` again)

Without a key, sites still generate fully (headline, text, services, FAQ) —
they just won't have a hero image or gallery photos until you add your own.
Pexels' free tier is generous (200 requests/hour, 20,000/month) and doesn't
require attribution, though crediting photographers is appreciated.

## Modernize an old website

From the dashboard, paste the URL of an existing live website. The app:

1. Fetches and parses it (headline, intro text, service-like headings,
   contact email/phone/address, a logo, real photos — filtering out
   icons/logos from the gallery)
2. Creates a brand-new site from that content using the modern theme
   (keeping the old site's brand color if it declared one)
3. Sends you to the editor with a banner flagging it as imported, so you
   can review and adjust anything before publishing

If a site was created this way, its editor gets a **"Refresh from
source"** button to re-pull content from the same URL later (your current
content is saved to version history first, so it's never a one-way trip).

This reads static HTML. If a site renders its content entirely via
JavaScript, install Playwright to enable a headless-browser fallback the
scraper will use automatically:

```
npm install playwright && npx playwright install chromium
```

(Not installed by default, to keep the base install light — most old
business sites are plain server-rendered HTML and never need it.)

## Pull inspiration from social media

Both "Generate a site" and "Modernize an existing website" have an optional
"Facebook / Instagram / Google Business link" field. When filled in, the app
fetches that page's public metadata (Open Graph tags) — a profile/cover
photo, a bio, and a declared brand color — and uses it in the new site:

- **Generate a site**: a real photo from the link replaces the generic stock
  hero image, and the brand color (if found) replaces the auto-picked one.
- **Modernize an existing website**: the social link only fills in what the
  old site was missing (e.g. no hero image, no brand color) rather than
  overriding what was already found.

This only works with whatever a page exposes **without logging in**.
Facebook and Instagram both aggressively limit that for most business
pages, so results range from "a nice cover photo and brand color" to
"nothing at all" — if nothing usable comes back, the site still generates
normally, just without that extra polish. Google Business Profile listings
and plain business websites tend to work better than Instagram in
particular. There's no error shown if a social link comes back empty; it's
treated as a bonus, not a requirement.

## Design

Published sites use a clean, corporate/premium visual style out of the
box: full-bleed hero imagery with a color overlay, card-based sections,
generous whitespace, a sticky nav with real links to each page (not
in-page anchors), an accessible FAQ accordion, a two-column About section
with a photo (falls back to centered text if no photo is set), and a
two-column contact section with an embedded map (shown automatically once
an address is filled in). A closing call-to-action band appears above the
footer on every page except Contact itself. Six style options plus a primary/accent
color picker and font choice are available per site from the theme
settings in the editor:

- **Modern** — the default: clean sans-serif, pill buttons, soft shadows.
- **Classic** — a more traditional serif/4px-corner look.
- **Bold** — modern's shapes with punchier color use.
- **Editorial** — a warmer, premium/magazine style: cream page background,
  serif headlines (Playfair Display), left-aligned section headers instead
  of centered ones. Modeled on premium service-business sites (law firms,
  consultancies) that favor an editorial feel over a tech-startup one.
- **Minimal** — quiet and flat: no shadows, thin hairline rules, small
  tracked-out uppercase section labels, sharp-cornered buttons. Good for
  studios, consultants, anyone who wants restraint over polish.
- **Warm** — cozy and rounded: a soft cream/peach background, a gentle
  serif (Fraunces) for headings, extra-rounded cards and photos. Good for
  home services, salons, and family-run businesses.

All styles share the optional hero **"trust line"** field — short facts
separated by `•` (e.g. "Free consultation • No hidden fees • Available
24/7"), rendered as a row of checkmark bullets under the subheadline.

Nothing fabricated ships by default: there's no placeholder testimonial, no
invented trust badges ("Licensed & Insured" etc.) — sections with no real
content (like testimonials) simply don't render until you add some,
instead of showing something fake. If a hero or About photo URL ever goes
dead (stock-photo links do rot), the page detects the failed load and
falls back to a themed pattern background instead of showing a broken
image or a blank gray box.

## Security & production hardening

- **Rate limiting** on login, signup, the URL importer, the "generate a
  site" tool, and the public contact form (which has no login to protect
  it, since anyone who finds the live site can reach it).
- **Spam honeypot** on the public contact form: a hidden field real
  visitors never fill in; a submission that does gets silently dropped
  instead of stored, with no indication to the bot that anything failed.
- **SSRF protection** on the importer: it resolves the target host and
  refuses to fetch anything pointing at loopback, private (RFC1918),
  link-local, or other non-public IP ranges — including through redirects,
  checked hop by hop. Set `ALLOW_PRIVATE_IMPORT_HOSTS=true` in `.env` only
  for local development if you need to import from `localhost`.
- **Input validation** on signup/login (email format, password length),
  and on every editor field (length caps, hex-color checks, and
  `href`/`src` values restricted to `http(s)`/`#`/relative paths so a
  pasted value can't become a `javascript:` link).
- Session cookies are `httpOnly`, `sameSite=lax`, and `secure` when
  `NODE_ENV=production`.
- `SESSION_SECRET` and `PORT` come from `.env` (see `.env.example`)
  instead of being hardcoded.

## Performance

- An index on `sites.user_id` keeps dashboard queries fast as the number
  of sites grows.
- Published pages are cached in memory per-page (home, about, contact, …)
  and served without touching the database or re-rendering, invalidated
  immediately whenever that site is saved, published, unpublished, or
  deleted (5-minute safety-net TTL besides that).
- Gallery and map images use `loading="lazy"`.
- Photo speed pass: see "Speed, header options, form builder and launch audit" below.

## Files

- `server.js` — all routes (auth, dashboard, editor, autosave, uploads,
  versions, import/refresh, custom domains, public renderer, sitemap)
- `db.js` — SQLite schema, migrations, and connection (`DB_PATH` env var
  overrides the file location, used by the test suite)
- `defaults.js` — default content/theme/layout for a new site
- `scraper.js` — fetches a URL (with SSRF protection) and extracts content
  for the "modernize" import and "refresh from source" features
- `templates.js` — the business-type copy library for the "generate a site"
  feature
- `photos.js` — Pexels stock-photo search, used by "generate a site"
- `social.js` — best-effort Open Graph scrape of a Facebook/Instagram/Google
  Business link for a photo, bio, and brand color ("draw inspiration")
- `validate.js` — shared input validation helpers
- `cache.js` — tiny in-memory cache for rendered public pages
- `mailer.js` — optional SMTP email alerts for new leads
- `checklist.js` — the "Before you publish" checks
- `images.js` — optional (sharp-based) upload resizing/rotation
- `ai.js` — optional Claude-written copy (with strict no-invented-claims rules)
- `deploy/` — Caddyfile (automatic HTTPS) and a systemd unit for running on a server
- `views/client-edit.ejs` — the limited editor behind client edit links
- `start.bat`, `scripts/setup-env.js` — the Windows launcher and its `.env` helper
- `views/` — EJS templates; `views/sections/*.ejs` are the individual
  editor field partials, looped over in the order stored per site;
  `views/leads.ejs` lists a site's contact-form submissions
- `tests/` — `node --test` integration + unit tests
- `data/sitegen.db` — SQLite database file (created on first run; includes
  the `contact_submissions` table that backs the Leads page)
- `public/uploads/` — user-uploaded images (hero/about/gallery photos, and
  photos attached to contact-form submissions)

## Known limitations / next steps

- Uploaded images are stored on local disk — fine for a single server,
  but swap `multer`'s disk storage for S3 (or similar) before running
  multiple server instances behind a load balancer.
- The importer only follows redirects and reads one page; it doesn't
  crawl a whole old site.
- Custom domains require you to actually deploy this app somewhere with a
  stable address and point DNS at it — there's no automatic TLS/certificate
  provisioning here (put it behind something like Caddy or a
  load balancer that handles that).
- No password reset / email verification flow yet.

## Round 5: cookie notice, accessibility, speed, Sankara starter site

**Cookie notice and tracking.** In the editor's Local SEO box, "Tracking" is either *Ask visitors first* (default) or *Always on*. With "ask", a small banner appears and Google Analytics / Meta Pixel load only after a visitor clicks Accept. The built-in page counts and reports use no cookies, so they are unaffected. Existing sites that already had tracking IDs will now show the banner; switch to "Always on" if you prefer the old behavior (check your local rules first).

**Legal note.** The Trust box has a "Legal note" field (license numbers, disclosures). It shows in the footer. Only enter things that are true and verifiable.

**Accessibility basics.** Skip-to-content link, visible keyboard focus, a main landmark, and a checklist warning when white text on the brand color would be hard to read.

**Speed.** Pages are gzip-compressed (about 75% smaller), uploaded photos are cached for 30 days, Google Fonts no longer block rendering, and the home hero photo is preloaded.

**Create the Sankara Insurance Group starter site** (run once, after you've signed up in SiteGen):

    node scripts\create-site.js examples\sankara.json

It lands in your account unpublished. It deliberately contains no license numbers, years in business, service areas or carrier claims. Add your phone, email, address, license number (Legal note), photos and hours, then follow the checklist before publishing. Use `node scripts\create-site.js file.json you@email.com` to pick the account. You can make your own starter files by copying `examples/sankara.json`.

## Round 6: more looks, and charging for hosting

**Three new styles** (editor, Theme box, Style): *Midnight* (dark), *Split hero* (text on the left, photo on the right on wide screens), and *Poster* (loud uppercase headings, hard edges). They work with any brand colors. Check the contrast warning in the checklist if you pick a very light primary color.

### Charging for hosting

SiteGen can take a monthly hosting fee through Stripe and automatically take a client's site offline if they stop paying. You never handle card numbers; Stripe does.

One-time setup (about 10 minutes):

1. Make a Stripe account at stripe.com. Start in **Test mode** (toggle at the top) until everything works.
2. **Product catalog → Add product**: for example "Website hosting", **Recurring**, monthly, your price. Copy its **Price ID** (starts with `price_`).
3. **Developers → API keys**: copy the **Secret key** (starts with `sk_test_`, later `sk_live_`).
4. **Developers → Webhooks → Add endpoint**: the address is `https://YOUR-SITEGEN-ADDRESS/stripe/webhook` (it must be your public https address; see "Putting it online"). Select these events: `checkout.session.completed`, `customer.subscription.created`, `customer.subscription.updated`, `customer.subscription.deleted`, `invoice.paid`, `invoice.payment_failed`. Copy the **Signing secret** (starts with `whsec_`).
5. In your `.env` file add:

       STRIPE_SECRET_KEY=sk_test_...
       STRIPE_PRICE_ID=price_...
       STRIPE_WEBHOOK_SECRET=whsec_...

   then restart SiteGen.
6. Optional: **Settings → Billing → Customer portal** in Stripe: turn it on so clients can update their card or cancel.

Using it, per site: open the site in the editor, click **Billing**. Enter the client's email and click *Create link* (or *Create and email it*). The client pays on Stripe's page and the status turns Active by itself. Tick *Take this site offline when its hosting subscription is not active* once the client has agreed to the terms. Then:

- A failed payment keeps the site live for 7 days while Stripe retries the card, then it goes offline (visitors see a polite "temporarily unavailable" page).
- A cancelled subscription takes the site offline right away. When they pay again it comes back right away.
- Your own preview and editor always work, and you can untick the box at any time to put a site back online.
- One price applies to every site. If you want different prices, tell me and I'll add a price per site.

Things to know: this only works when SiteGen is online at a public https address (Stripe needs to reach the webhook). To test on your own computer, use Stripe's free CLI: `stripe listen --forward-to localhost:3000/stripe/webhook`, and put the `whsec_` it prints in `.env`. Test with Stripe's test card `4242 4242 4242 4242`. Put a short hosting agreement in front of clients before you turn on the offline switch, and check your local rules on taxes and recurring billing.

### Fonts

Editor → Theme has a **Heading font** and a **Body font**. Pick from about 40 curated Google Fonts (grouped: Eccentric, Bold headlines, Elegant, Clean, Script, Mono), or type the name of *any* font from fonts.google.com. The sample text under each one previews it as you choose. "Heading capitalization" lets you force Normal (best for gothic and script fonts, which are hard to read in capitals) or UPPERCASE.

For an edgy shop (tattoo, barber, bar): try the **Midnight** or **Poster** style with heading font *Pirata One* or *UnifrakturCook*, capitalization *Normal*, and body font *Inter* or *Lora* so the paragraphs stay easy to read. Keep the body font plain; eccentric fonts are for headings.

Fonts come from Google at view time, so visitors need to be online (a fallback font shows meanwhile). Leaving both on "Style default" changes nothing for existing sites.

### More starting templates

"Generate a site" now knows 42 business types. New ones: tattoo studio, barbershop, insurance agency, home care, party and event rentals, florist, auto detailing, catering and food trucks, chiropractor, tutoring, weddings and events, pool service, tree service, pressure washing, junk removal, coffee shop, locksmith and child care. Several come with their own look (for example the tattoo studio starts in the dark Midnight style with a blackletter heading font); you can change all of it afterward. The copy deliberately makes no promises about licenses, response times or prices. Add those yourself once they are true.

To add your own, copy an entry in `templates-more.js` (the optional `look` block sets style, colors and fonts). Entries listed there win over older ones when keywords overlap.

### The Agency look (full home page)

Pick **Agency** in Theme → Style (or tick "Show service tiles, service photos and reviews on the home page" in any style) and the home page becomes a full landing page:

- a dark top bar with phone, "Email an agent" and social links
- a photo hero, then a row of colored **service tiles** with icons (up to 8; the icon is chosen from the service name, or pick one per service)
- a short intro from your About text
- a dark band of **service cards with photos** and "Read more" links
- a **ratings summary and review cards** built only from the reviews you have entered or approved (the average and count are computed from them, never invented)
- a footer with quick links, your latest blog posts, and your main and **other offices** (Contact box → Other offices)
- on desktop, a slim "Questions? We're here to help. Get a Quote / Call" bar along the bottom that visitors can close

For each service, use **Choose photo** (Services box) to add the card photo; the checklist reminds you if any are missing. The Insurance template and the Sankara starter file use this look. Headings use the condensed Oswald font in capitals unless you pick a heading font yourself.

## Hero photo slideshow and office maps

- **More hero photos** (Hero box in the editor): after you set the main hero photo, add up to 5 more. The home page then fades between them every 6 seconds, with previous/next arrows. It pauses on hover and does not auto-play for visitors who ask their device to reduce motion. Leave the list empty for a single photo.
- **Other offices** (Contact box): add up to 6 offices (name, address, phone). They show as cards with a Google map on the Contact page and in the footer. The main address also gets a footer map on the full home look (Agency, or the "full home page" checkbox).
- Maps load only when a visitor scrolls to them, and need an internet connection. They are not included in static exports.

## Content blocks

In the editor, open **Content blocks** and use **+ Photo + text block** or **+ Numbered steps block**. Add as many as you like.

- **Photo + text:** a photo beside a heading, paragraphs and an optional button. With "Alternate automatically", the photo switches sides from one block to the next.
- **Numbered steps:** one step per line, written as `Title | short description`.
- Each block can have a plain, light-tint or brand-color background, and can sit near the top or lower on the home page.
- Use the arrows to reorder, **Duplicate** to copy a block, **Delete** to remove it.
- Blocks show on the home page only. Nothing is filled in automatically. Empty blocks are dropped when you save.

More block types: **Feature cards** (one per line, `Title | description`, with an icon picked from the title), **Closing call-to-action band** (headline, text and button over an optional background photo) and **Area chips** (one place per line; add `| /link` to make a chip clickable).

New pet templates: **Mobile Pet Grooming** (type "mobile pet grooming"; Agency look with photo + text, steps and feature-card blocks), **Dog Training** and **Pet Sitting & Boarding** (also matches dog walking, daycare and kennel). Plain "pet grooming" still uses the salon template. Templates can now bring their own content blocks.

## More themes

Theme > Style now also has **Luxe**, **Coastal**, **Playful**, **Earthy**, **Corporate** and **Blush**. Switch between them on any site at any time; your text, photos and blocks stay the same. Each theme sets its own background, corner roundness, button shape and heading font, and still uses the site's brand colors, so adjust the primary color after switching. Tick "full home page" to get the tiles, service cards and review layout in any theme. Picking your own heading font overrides the theme's. New themes are defined in `themes.js`.

## Styles and home page layouts

There are now 19 styles (Theme > Style, or click a style name above the list). The newer ones (Luxe, Coastal, Playful, Earthy, Corporate, Blush, Studio, Gallery, Journal) each bring their own home page layout and hero arrangement, so a site no longer has to look like the others. **Home page layout** lets you override that with Basic, Full, Story (photo + text rows), Photo tiles or List. Switch as often as you like; the preview refreshes after a moment and nothing you've written is lost. Pet templates now use Studio (mobile grooming), Gallery (dog training) and Playful (pet sitting).

## Styles across pages

- **Inner pages follow the layout.** The Story, Photo tiles and List layouts now also apply to the Services page, not just the home page.
- **Different style on specific pages.** In the editor, open "Different style on specific pages" and pick a style for any page (Home, About, Services, Reviews, FAQ, Contact, and so on). The Services choice also covers each individual service page. That page's menu and footer follow its style, so use it sparingly. "Same as the site" removes the override. It also works in the preview and in the static export.

## Style hints and per-industry defaults

- Hover over a style name in Theme to see what it feels like and which businesses it suits.
- Every industry template now generates with its own style (and sometimes home layout): salons get Luxe, law firms Journal, plumbers Studio, accountants Corporate with a list layout, and so on. The mapping is in `template-looks.js`; change it if you disagree. Unmatched business types still get the generic Modern look. You can always switch in Theme > Style.

## Hero feature cards and logo strip

- **Feature cards over the hero** (Hero box): up to 4 cards, each a short title and one line, that overlap the bottom of the hero photo on the home page. Empty rows are left out. Only say things that are true for the business.
- **Logo strip** (Trust & credentials): up to 8 association, certification or partner logos with an optional heading such as "Our memberships". They show as a row on the home page. Only add logos the business is entitled to show.
Both are empty by default and never filled in automatically.

## Photo strip, split blocks and shaped edges

New content block types (Content blocks > add):
- **Side-scrolling photo strip:** a row of up to 20 photos that visitors scroll sideways (arrows on desktop, swipe on phones). Add photos by upload, stock search or URL. An optional button underneath works well as "Follow us on Instagram".
- **Heading + text (split):** a big uppercase heading on the left, paragraphs and an optional button on the right.
- **Dark band** is now a background choice for any block.
- **Wavy or scalloped top edge** for any block, and a **bottom edge for the hero** (Hero box).

Instagram: the strip shows photos you add yourself. A live Instagram feed needs a Meta developer app and access token, which SiteGen does not set up, so link to the profile with the button instead.

## Online booking

Each site can have a booking page (`/book`) where customers choose a service, optional add-ons, a date and a time, answer questions that suit the industry (for pet grooming: pet name, type, breed, size, coat, handling notes), and send the request.

**Turn it on:** editor → *Online booking*. Tick "Turn on online booking", pick a **ready-made setup** (pet grooming, mobile grooming, salon, barber, home services, spa/clinic, dog training, general) and press *Load*. That fills in the industry questions and turns the site's services into bookable services. Then set your own:

- opening hours per weekday, time zone, how often start times are offered, earliest booking (hours from now), how far ahead customers can book, and how many appointments can overlap
- service lengths (minutes) and optional price text such as "from $65". Prices are only displayed, never charged
- add-ons (extra minutes are added to the appointment), your own questions (short text, dropdown, long text; required or optional), a policy text and a confirmation note

Generated sites from an industry template get the matching setup pre-loaded, **switched off**. Nothing is bookable until you turn it on and check the services and hours.

**What happens to a request:** it waits on the **Bookings** page (button in the editor). You confirm or decline it (with an optional message), or turn on *Confirm automatically*. Booked times disappear from the open times straight away, including requests still waiting for you, and a declined or cancelled one frees its time again. Customers get a private link to see their status or cancel. With email set up (see "Email alerts") you are emailed about new requests and the customer is emailed when you confirm or decline.

**Good to know**
- Times are the business's own clock in the time zone you pick. There is no calendar sync (Google/Outlook) and no payments or deposits; put cancellation or deposit rules in the policy text.
- Customers can't reschedule themselves; they cancel with their link or call you.
- Booking needs the running server, so the static export has no booking page (the "Book Now" button is left out there).
- Loading a ready-made setup replaces services, add-ons and questions (a version is saved to history first). Opening hours stay.

## Matching color palettes

In the editor, under the Primary and Accent color boxes, open **Matching color palettes**:

- **Pull colors from a logo:** choose the client's logo file (or press *Use the site logo*) and it finds the main colors, ignoring white and transparent backgrounds. Click *Logo colors* to use the logo's own pair, or click one color to build matching sets from it. The image is read in your browser and is not uploaded. A logo hosted on another website can't be read that way; choose the file from your computer instead.
- **Build matches from one color:** pick the client's brand color and get eight matching sets (same color deeper, complementary, warm and cool neighbors, triad, neutral slate, softer, bolder). Click one to use it; the preview updates.
- **Ready-made for businesses like this:** 16 palettes (pets, salon, spa, navy, garden, trades, auto, kitchen, care, tech, earthy, black and white, sunny). The ones that fit the site's business type are listed first.
- **Readability check:** white button text sits on the primary color and white text sits on the accent (footer and dark bands). If either is hard to read you get a warning and a one-click darker color of the same hue.
- **Undo palette** puts the previous two colors back. Colors stay the same when you switch styles. Photos and text are never touched.


## Pricing table, announcement bar, photo lightbox, search markup

- **Pricing / packages block** (editor → Content blocks → "+ Pricing / packages block"): one plan per line as `Name | Price | what is included, separated by commas`. Start a line with `*` to highlight that plan (shown with a "Featured" label; nothing says "most popular" unless you write it). The block's button appears on every plan, so point it at your booking page or contact page. Prices are just text you type.
- **Announcement bar** (editor → Announcement bar): a thin bar above the menu on every page, with optional link. Uses the accent color. Visitors can close it and it stays closed until you change the message.
- **Photo lightbox:** clicking a photo on the Gallery page or in a side-scrolling photo strip opens it large, with next/previous arrows, keyboard arrows, Esc, and swipe on phones. Nothing to set up.
- **Search-engine markup:** pages already carried business details (name, phone, address, area, social links). Now the opening hours are included too, but only rows that read as a weekday plus a time range such as "Monday | 9:00 AM – 5:30 PM" (rows like "Closed" or "Call us" are left out rather than guessed), and the FAQ page carries FAQ markup matching the questions shown. Review-star markup is deliberately not added: search engines disapprove of a business marking up reviews it collected itself.

## More blocks and extras

All of these are in the editor under *Content blocks* (add as many as you like, reorder, duplicate) unless noted.

- **Team / staff:** one person per line, `Name | Role | Short bio | Photo link`. Role, bio and photo are optional; without a photo the card shows the person's initial in a color circle.
- **Numbers:** one per line, `Number | Label`, for example `12 | Years in business`. They count up when scrolled into view (not for visitors who prefer reduced motion). You type the numbers; nothing is filled in for you.
- **Video:** paste a YouTube or Vimeo page link, or a direct `.mp4`/`.webm` link. YouTube and Vimeo load only after a visitor clicks play, so nothing from them is loaded or tracked until then. Other links show nothing.
- **Tabs** and **Accordion:** one item per line, `Title | text`. Tabs show one panel at a time; the accordion opens and closes each item.
- **Review carousel:** in the Testimonials section choose "Sliding row" instead of the grid. It applies to the Reviews page and the home page review row, with arrows and swipe.
- **Floating Text us / WhatsApp button** (Contact section): a button in the corner of every page that opens a text message or WhatsApp chat to the site's phone number. A 10-digit number is assumed to be a US number (+1). Only switch it on if the business actually answers texts.
- **Share picture** (the SEO fields at the top of the editor): the picture shown when a link to the site is texted or posted. Empty means the home photo.

The site already has a cookie notice (it appears when the owner adds Google Analytics or a Meta pixel with tracking set to "ask first"), so no separate one was added.

## Page-wide controls (work with every style and industry)

- **Blocks on any page:** every content block has a "page" choice (home, About, Services, Reviews, Why Choose Us, Gallery, FAQ, News & Tips, Hours, Contact) and a "near the top / lower on the page" choice. Use it for a pricing block on the Services page, a team block on About, an accordion on Contact, and so on. Blocks default to the home page, as before.
- **Hero controls** (Hero section): click the photo preview to choose which part stays in view when it is cropped for different screens (a face, a storefront); pick how dark the photo is made so the text reads (or let the style decide); choose text left, centered or right; optionally add a short looping background video (a direct .mp4/.webm link). The video plays silently on computers only; phones and visitors who prefer less motion see the photo, so keep a hero photo set too.
- **Feel controls** (Theme section, above the colors): button shape (square, rounded, pill), corner roundness for cards and photos (sharp, soft, very round) and space between sections (compact, normal, airy). "Let the style decide" keeps each style's own look.
- **Logo as browser-tab icon:** if a logo is set, it is used as the site's tab icon (and home-screen icon on phones) instead of a letter. A square logo image works best.

## Speed, header options, form builder and launch audit

- **Photos load fast on phones.** Every photo you upload gets smaller WebP copies (480, 960, 1440 and 1920 px wide) next to the original. Published pages use them automatically: a phone downloads the small copy, a desktop the large one, photos below the top of the page load only when scrolled to, and the home page photo is WebP and preloaded. Nothing to switch on. Photos uploaded before this update get their copies made in the background the first time a page that uses them is viewed (the first visitor may still get the old file). The exported static site includes the copies. GIFs, SVGs and photos linked from other websites are left as they are, and the logo is never resized.
- **Header options** (Theme section): *Sticky bar* (the default), *Sticky, shrinks as you scroll*, *Transparent over the home photo, solid on scroll* (home page only; other pages have no photo to float over) or *Not sticky*. *Header layout* puts the logo left with the menu right (default) or centered with the menu underneath. Works with every style.
- **Contact form builder** (Contact section): choose *My own form* instead of the standard one. Pick a template (estimate request, insurance or financial quote, pet appointment, event inquiry, consultation) or add your own questions: name, email, phone, a list of your services, long or short answers, dropdown, pick-one buttons, pick-several checkboxes, date, number, photo upload. Give each question a **Step**; questions on different steps become a step-by-step form with a progress bar and Back/Next buttons (everything on step 1 is a normal one-page form). Required questions are checked in the browser and again on the server. Name, email, phone, service and message answers fill the usual Leads columns; every other answer shows on the lead, in the CSV (an "Answers" column) and in the email alert. The same form also appears on service pages. Switching back to *Standard form* keeps your questions saved. Keep a phone or email question so you can reply (the launch audit warns if you do not).
- **Photo descriptions** (Gallery and About): each photo can have a short description, used as alt text for screen readers and Google Images. Blank ones fall back to the business name.
- **Launch audit** (the "Before you publish" list in the editor) now also catches: placeholder text left behind (Lorem ipsum, example.com addresses, 555-01xx phone numbers, the default About text), phone numbers that are too short, buttons that link to a page that does not exist or is hidden, uploaded photos missing from the uploads folder, very large photos, insecure http:// photos, gallery photos with no description, search title or description that is too long or too short, no share picture, a very long headline, a custom form with no way to reply, and booking switched on with no services or no alert email.

## Block library, per-page search settings, redirects, 404 page and visitor actions

- **Block library** (Content blocks section): click "Save to library" on any block, give it a name, and it is saved to *your account*. On any of your sites, pick it in the Block library box and press "Insert into this page"; then choose which page it shows on. Copies are independent: editing the library copy later does not change blocks already placed on sites, and deleting a library entry leaves those blocks alone. Up to 200 saved blocks; other users never see yours.
- **Search & sharing for each page** (own box under Site & SEO): for About, Services, Reviews, Why Choose Us, Gallery, FAQ, News & Tips, Hours, Contact (and Booking when it is on) you can write your own Google title, description and share picture, or ask Google not to list the page (it is also dropped from the sitemap). Each service also has its own title and description boxes inside the Services section. Empty boxes keep the automatic text.
- **Redirects:** map old addresses to new pages (`/about-us.html` to `/about`), a whole folder (`/old-blog/*` to `/news/*`) or another website. Permanent (301) tells Google the move is for good; temporary is 302. Matching ignores capital letters and a trailing slash, keeps the visitor's `?utm=` tags, and works on `/site/<name>/...` links and on a site's own domain. Only GET requests are redirected. The pre-launch list warns if a redirect hides a page that exists or leads to a page that does not.
- **"Page not found" page:** any unknown address on a published site (including its own domain) shows a page in the site's own style, with the header, footer and links to its main pages, and the right 404 status so Google does not index it. You can change the heading and message. Addresses that belong to no site get the plain 404.
- **What visitors did** (on the Report page and in the monthly email): counts of taps on the phone number, email address and Text/WhatsApp button, clicks on "Contact / Book" buttons, taps on directions links, plus booking requests and the share of page views that ended in an action. No cookies, no personal data; bots, the editor preview and the exported static copy are not counted. A tap is not a completed call. If a Google Analytics or Meta Pixel ID is set, those tools also receive `click_to_call`, `click_email`, `click_text` and, after a booking request, `generate_lead` / `Schedule`.

## Scroll animation, privacy & terms, backups and client logins

**Scroll animation.** Replaced by the Motion style setting (see "Motion style" below). "Cards lift on hover" is still in the Design box.

**Privacy Policy and Terms of Use.** Settings → *Privacy & Terms pages*. Turn it on and `/privacy` and `/terms` appear, linked in the footer, in the sitemap and in the exported zip. The text is written from what the site really does (a form, photo upload, booking, Google Analytics / Meta Pixel, Google Fonts), so a paragraph only appears when it applies. It is a starting template, **not legal advice**: have a lawyer review it, and use the "extra text" boxes for your own rules. The cookie bar still appears when tracking IDs are set (asking before anything loads); you can also choose a short privacy notice on every site. The launch audit suggests a policy when a site collects details but has none.

**Backups.** SiteGen saves a compressed copy of the database to `data/backups` about two minutes after starting and every six hours if none exists for today, keeping the newest 14 (`BACKUP_KEEP`, `BACKUP_DIR`, `BACKUP_AUTO=off` in `.env`). The admin account sees them under Dashboard → *Automatic backups* (download, or "Back up now"). They hold the database only; the existing "full backup" zip also includes uploaded photos. Copy backups to another drive or cloud folder now and then.

**One-click copies.** Dashboard → *Duplicate* (exact copy), *Use as template* (keeps design and wording, clears phone, email, address, tracking IDs, report email, redirects and client links) and *Save file* (a `.sitegen.json` file). *Bring in a saved site* turns such a file into a new, unpublished site. Photos are not inside the file. Copies never get the original's custom domain or client access.

**Client logins.** Editor → *Client logins*: enter a client's email, and they get an invite link (emailed if email sending is set up, otherwise shown once for you to send). They choose a password and sign in at `/client-login`, where they can change the same basics as with the private link, plus their report, and nothing about design, publishing or domain. *Reset password* and *Remove* are on the same box. The client session is separate from your owner login. The older private link still works.

## Lead pipeline, follow-up emails, chat assistant, Google reviews and estimate calculator

**Lead pipeline.** On the Leads page every lead has a status (New, Contacted, Quoted, Won, Lost), a private note and a **follow-up date**. A "Follow up today" filter shows what is due, and once a day you get one email per site listing the due leads (turn it off under Settings → *Lead follow-up*). Leads are marked where they came from (form, chat, estimate). The CSV has the new columns.

**Automatic follow-up emails.** Settings → *Lead follow-up*: up to three emails to a new lead who left an email address, sent a number of hours after they asked (for example 1, 48 and 168 hours). Each email goes out only while the lead is still **New**: change the status and the rest are cancelled. Every email carries a "stop emailing me" link. Use [name], [business] and [phone] in the text. Needs email sending set up (see "Email alerts"). Set `PUBLIC_URL` in `.env` (for example `https://sites.yourdomain.com`) so the stop link in the emails points at your real address.

**Chat assistant.** Settings → *Chat assistant* adds a chat bubble. It answers only from the site's own text (services, FAQ, hours, contact) and says "I don't have that detail" instead of guessing, then offers a box that sends the visitor's details as a lead with the conversation attached. It is labelled as automated. With `ANTHROPIC_API_KEY` set it uses AI (`ANTHROPIC_CHAT_MODEL` can pick a cheaper model); without it, it answers from the FAQ and hours only. Each site has a daily cap on AI replies (default 200) to keep costs in check. The Privacy Policy mentions the chat when it is on. Real FAQ answers make it much better.

**Google reviews.** Settings → Reviews box → *Google reviews*: enter the business's Place ID and choose "Star rating badge" or "Badge and Google reviews". Add `GOOGLE_PLACES_API_KEY` to `.env` (a Google Cloud key with the **Places API (New)** enabled; Google gives a monthly free allowance, check their current pricing). Reviews are fetched once a day and shown exactly as Google returns them (nothing is picked or edited), with a "Reviews from Google" credit. Please check Google's current terms for showing and storing their reviews. Not included in the downloaded static copy.

**Estimate / quote calculator.** Settings → *Quote / estimate calculator* adds an estimate page to the menu. You write the questions (dropdowns, buttons, number × price, yes/no add-ons) and set **every price yourself**; starting points for cleaning, lawn care, moving and an insurance quote wizard come with blank prices. The visitor sees a live price range, then sends it as a lead with their choices attached. The server recalculates the price, so it cannot be tampered with. Turn "Show prices" off for a quote wizard without prices. The launch audit warns if every price is zero. Not included in the downloaded static copy (it needs the server).

## Client questionnaire

Open **Client questionnaires** from the dashboard (or `/intake`) and press **Create a link**. Send that link to a new client. They answer a friendly 7-step form on their phone or computer: business, services, story, contact and hours, look and feel, goals and a final step. They can upload a logo and photos, and their progress is saved in their browser as they go.

When they press **Send my answers** you get an email (if email is set up) and their answers appear on the same page. Open them, check the "Check these before you publish" box, then press **Build the website**. The site is built from the client's own words for the services, story, tagline and FAQ, using their logo, photos, colors and chosen look. Nothing is invented. Privacy and terms pages are switched on, and the chat assistant only if they asked for it. Anything you still need to do (no logo, no photos, extras like a store) is listed for you.

You can close a link at any time. A closed or unknown link shows a polite "this form is closed" page. No new setup or environment variables are needed.

## Preview first, section labels, bigger headings, alternating bands and the floating button

- **Preview before creating.** On the dashboard, Generate now opens a preview instead of saving straight away. Switch between ten looks (the words and photos stay the same), flip between desktop and phone width, then press **Create this site** or **Discard**. Nothing is saved until you create it. Unused previews are cleaned up after 7 days.
- **Section labels.** Each section has an optional small label above its heading (for example "Our care") under the heading box in the editor. Generated sites start with a few sensible ones.
- **Heading size** (Normal, Large, Extra large) and **Alternate light and dark sections** are in the editor's look settings. Alternating bands show on home layouts that have several sections.
- **Floating button** (contact settings) now also offers **Call us**, **Book now** (needs online booking on) and **Get a quote**, besides Text and WhatsApp.
- **Benefit-first headlines.** Built-in templates now lead with what the customer gets and keep the business name in the supporting line. AI-written copy is told to do the same.

## Publish online (Netlify), custom domain and HTTPS

Open a site and press **Publish online**. One time only: make a free Netlify account, create a personal access token (User settings, Applications, New access token), add `NETLIFY_AUTH_TOKEN=...` to your `.env` file and restart. The token is never shown on any page.

- **Publish to Netlify** sends the finished site (plain HTML files and photos) to a new Netlify site and gives you a web address straight away. **Publish again** updates the same site after you edit.
- **Your own domain:** enter the domain, add the DNS records the page shows at the company where the domain is registered, wait a little, then press **Turn on HTTPS**. The certificate is free and renews itself.
- **Contact form:** works on the published copy through Netlify Forms. Messages are emailed to the contact notify address (or the contact email, or your login email) and also kept in the Netlify dashboard under Forms. The spam trap field is kept.
- **A 404 page and a thank-you page** are added to the published copy.
- **Not on the published copy:** online booking, the estimate calculator, the chat assistant, the review form, lead follow-ups and visitor reports. They need SiteGen running on a server, so they keep working on the address SiteGen itself serves. The page lists the ones this site uses.
- Netlify allows 3 deploys per minute and 100 per day. The normal **Export** download is unchanged.

## Card payments (Stripe): deposits, payment requests and service purchases

Each site uses the **owner's own Stripe account**: in the editor open *Card payments (Stripe)*, tick the box and paste a Stripe secret or restricted key (`sk_` / `rk_`). The key is stored encrypted, is never shown again, and money goes straight to the owner's Stripe. No webhook or extra setup is needed.

- **Booking deposits** – set a fixed amount or a percent of the service price. The customer is sent to Stripe; the time is held for 30 minutes and the booking is confirmed once paid. Unpaid holds are released automatically.
- **Pay buttons** – put a price (digits only, e.g. `89`) on a service and a "Pay online" button appears on its page.
- **Payment requests (quotes/invoices)** – *Payments* in the editor, or "Request payment" on a lead: enter an amount and description, copy the link or email it. Owners can resend, cancel or mark as paid (cash/check).
- Payments are confirmed by asking Stripe when the customer returns, when the owner views the page, and every 5 minutes in the background.
- Prices always come from the owner's settings, never from the visitor.

## Ask AI to change something (chat-to-edit)

Needs `ANTHROPIC_API_KEY`. In the editor (and on the client edit page) type a change in plain words, for example "make the headline friendlier, add a service called Gutter Cleaning, change the main color to dark green". The AI proposes edits, you see before and after, and nothing is saved until you click **Apply**. Applying saves the previous version to history first.

- It can only change headings, hero text, About, service and FAQ text (and add or remove services and FAQs), the SEO title/description, the announcement bar, and (owner only) colors and style options.
- It cannot touch contact details, hours, prices, photos, payments or credentials, and it is told never to invent facts.
- Clients get the same box with text-only changes.

## Luxury dark style, quick-jump buttons, "Where we work" map, footer columns

- **Style: Luxury dark.** Black with a warm glow, an elegant serif, and outlined pill buttons. The glow, buttons and headings use the **Primary color**; the footer and bands use the **Accent**; the page background is the new **Background color** box (leave empty for near-black). Under the color boxes, click one of eight ready-made palettes (black and gold, navy and rose gold, forest and champagne...) to set all three at once. Button text switches between dark and white automatically so it stays readable.
- **Quick-jump buttons** (Hero section): a row of pills under the hero for Book, Services, About, Reviews, Location and Contact. Only the ones the site actually has are shown.
- **"Where we work" map** (Contact section): a map plus the service areas on the home page.
- **Footer hours** (Contact section) and a **"We accept"** footer column that appears automatically once card payments are on.

## Emoji and doodles, cinematic hero, floating shapes

- **Your emoji** (Colors and fonts): type up to four, or click a quick pick for the kind of business (pets, salon, cleaning, home repair...). Only real emoji are kept.
- **Hand-drawn touches:** sparkle marks around the home headline and a squiggle under section headings. **Emoji next to headings:** shows your first emoji beside every section title.
- **Cinematic hero** is now part of the *Lively* motion style (slow photo zoom, headline rising word by word). Sites that used it were moved to Lively automatically.
- **Floating shapes over the hero:** your emoji drifting upward, twinkling sparkles, rising bubbles, or falling confetti. Drawn on a canvas, so there is nothing to upload; it pauses when scrolled out of view.
- Everything here is switched off for visitors whose device is set to "reduce motion".

## Design data (step 1 of the design-intelligence work)

`design-data/` holds JSON converted from the open-source **UI UX Pro Max** skill (MIT licence, © Next Level Builder; the licence file stays with the data): 192 kinds of business with recommended styles, palettes, fonts, landing patterns and "avoid" lists, plus 88 styles, 74 font pairings, 34 landing patterns and 109 web UX rules. `designdata.js` searches and resolves it (`searchProductTypes`, `designFor`, `recommend`, `searchGuidelines`...) with no Python or network. To refresh it: `node tools/import-design-data.js <path to the skill's data folder>`. Nothing in the editor uses it yet; steps 2 to 5 (industry mapping, recommended looks after the questionnaire, a pre-publish quality check, and on-brand AI prompts) build on it.

## Design suggestions per industry

Each of the 45 industry templates is mapped (`industry-design.js`) to the closest business type in the bundled design data (`design-data/`, MIT, see its LICENSE file). In the editor, under Style, a "Suggested for …" panel shows the styles that suit the business, colour sets (adjusted to pass AA contrast), font pairs, the page flow that works, and what to avoid. Clicking a suggestion only fills the style, colour and font fields; text and photos are untouched. The panel is hidden for the generic template. Fit is marked direct / close / approximate; the data leans toward app and software businesses, so some trades (tattoo, barber, dog training, pet care) are approximate.

## Design options after the questionnaire

On a client's answers page (before building), SiteGen shows 2–3 design options (`design-options.js`). They come from the business type (see "Design suggestions per industry"), the look the client picked, their brand color, and the words they wrote (what they like about other sites, what makes them different, notes). The client's own look always leads; styles the design data says to avoid for that business are not suggested unless the client chose them (then a note says so). Each option shows its style, colors, fonts and why it was suggested. The chosen option is recomputed on the server when you click Build, so a tampered form value is ignored.

## Quality check before publishing

Every site has a "Check quality" button in the editor (`/sites/:id/quality`, code in `quality.js`). It reports, as a fix list:
- **Contrast (WCAG AA):** main and secondary text on the style's background, button labels on the brand color, and the brand color against the page. One click adjusts a weak brand color; the earlier version is saved in history.
- **Phone tap targets:** the page must enforce 44px minimum controls, allow pinch-zoom and have a mobile viewport.
- **Images:** insecure http images, formats browsers can't show, missing files, photos over about 700 KB or 2600px wide, large PNG photos, missing alt text, and lazy loading. "Optimize all photos" re-encodes heavy uploads to WebP (max 1920px) and keeps the originals.
- **Fonts:** font names that can't be requested from Google, `display=swap` and preconnect.

Red items (real problems) pause **Publish** and **Publish to Netlify** and show the list, with a "Publish anyway" button. Orange items are advice only. Photos hosted on other websites can't be measured.

New themes are guarded by tests: `tests/quality.test.js` checks every style's text contrast, and `tests/tap-targets.test.js` opens every style at phone width in a real browser (skipped if Playwright isn't installed) and fails if any button, field or link is under 44px.


## Motion style (Subtle, Lively, None)

One setting per site, in the editor under Colors and fonts → *Motion style*. It drives the only animation script on a site (`public/sitegen-motion.js`, built on the Motion library from motion.dev, version 11.11.17, MIT).

- **Subtle** (default for new sites): soft fade-ups as sections scroll in, quick number counters. **Lively**: bigger movement, the headline rises word by word, the hero photo slowly zooms, staggered cards. **None**: no animation, and the scripts are not even loaded.
- New sites start on Subtle; sites built from an industry template get a suggestion (restaurants, bakeries, events, groomers and similar → Lively; home care, insurance, law, dental and similar → Subtle; a style like Playful also suggests Lively). If a site's industry suggests something different from what it has, the editor offers it with one click. Advice that says an industry should stay calm caps the suggestion at Subtle.
- Pages carry only `data-animate="fade-up | stagger | hero | scene"` attributes and `data-count` (with `data-prefix`, `data-suffix`, `data-decimals`, `data-comma`) on numbers. Numbers like "24/7", "9-5" and years are left alone. There is no per-site animation code.
- **Bundled:** `public/vendor/motion.js` and `public/sitegen-motion.js` are served by your own server and copied into every export and Netlify publish, so a client site never loads code from a CDN. The Motion licence is in `public/vendor/LICENSE-motion.txt`.
- **Safe if anything fails:** content is fully visible without JavaScript. A tiny line in the page head hides animated items only while the script loads, and shows them after 3 seconds if it never starts. If the library is missing or the script throws, the page is shown as it is. Visitors with "reduce motion" turned on never see animation, and printing shows everything.
- **Preview switcher:** the dashboard Preview shows a Subtle / Lively / None bar with Replay, so you can show a client the difference. It exists only in your preview, never on the live site or in exports. "Use this style" saves the choice (the earlier version goes into history).
- Sites saved before this setting existed keep what they had: an old scroll animation becomes Subtle (Zoom becomes Lively), the cinematic hero becomes Lively, and sites with none stay on None.
- Floating shapes, emoji and doodles are separate "accents" and work alongside any motion style.

## Design guidance in the AI prompts

When an AI key is set, the industry's design guidance (the same advice the editor's "Suggested for…" panel shows) now goes into the AI prompts through `design-brief.js`:
- **Copy** (generate a site, "Rewrite with AI", build from a questionnaire): a short "Design direction" block with the site's look, the page flow that works for that business and what to avoid. It shapes tone and structure only; the rules against inventing facts are unchanged.
- **Chat-to-edit** (owner side only, not the client link): styles and color pairs to prefer, styles and options usually not recommended. If the AI proposes something against the guidance, such as a dark style for a salon, the proposal comes back with a "Heads up:" line. The change can still be applied, because the owner decides.
- Businesses with no guidance (the generic template) get exactly the prompts they had before.

## Publish history and rollback

Every publish keeps a copy of the site (newest 20). **Publish history** (editor top bar, and the Hosting page) lets you look at an old copy or roll back to it. A rollback first saves your current content to the editor's version history, so it can be undone. Netlify copies also make the matching Netlify deploy live again.

## Members area (visitor log-ins)

Editor → **Members area**. Turn it on to add a log-in page (`/members`) with members-only pages (text plus a button link). Sign-up can be open, approved by you, or invite-only. Manage people on the **Members** page: approve, add, turn off, remove, or make a one-hour reset link (shown once, for when email is not set up).

- Passwords are hashed with bcrypt; reset tokens are stored hashed and expire in an hour. Log-in errors are the same for a wrong password and an unknown email.
- The members page is `noindex`, `no-store`, excluded from the sitemap and `robots.txt`, and is **not** included in downloaded/static or Netlify exports (it needs this server).
- It is meant for ordinary members-only content, not high-security data.

## Client questionnaire: facts only, no invented claims

The questionnaire now also collects a price per service (optional), up to five "what makes us different" lines, up to six customer questions with the client's own answers, and a preferred tone of voice (alongside services, areas served and years in business).

When you click **Build the website**:
- The AI gets only those facts (`generateGroundedCopy` in `ai.js`). It may rephrase, but it must use exactly the client's services, may not add services, prices, numbers, places or claims, and must leave a field empty rather than pad it.
- `grounding.js` checks the result. If the draft contains a claim, number, place, filler phrase or service the client did not give, the AI is asked once more with the problems listed.
- Then every part of the site (AI wording and template wording alike) is scrubbed. Anything unsupported (for example a template line such as "licensed plumbers", "24/7 emergency service" or "Get a Free Estimate") is replaced with the client's own words or removed. The client's own about text, tagline, services (with prices), differences (shown as "Why choose us" cards) and FAQ always win.
- With no client FAQ, the FAQ section is hidden until real answers exist. The submission page lists what the client left out and what was replaced.

Spelled-out claims the client did make (for example "Licensed and insured") are allowed.
