// Real stock photos from Pexels (https://www.pexels.com/api/) for the
// "generate a site" feature. Requires a free PEXELS_API_KEY in .env.
// Everything here fails soft: with no key, or if a request errors out or
// times out, callers just get an empty array back and the site is created
// without photos (still fully usable, just no gallery/hero image).

const pexelsEndpoint = () => process.env.PEXELS_API_URL || 'https://api.pexels.com/v1/search';

function hasPhotoProvider() {
  return Boolean(process.env.PEXELS_API_KEY);
}

async function searchPhotos(query, count = 4, page = 1) {
  return (await searchPhotosPage(query, count, page)).photos;
}

// Same search, also reporting whether another page of results exists (used by
// the editor's photo picker).
async function searchPhotosPage(query, count = 4, page = 1) {
  const apiKey = process.env.PEXELS_API_KEY;
  if (!apiKey) return { photos: [], hasMore: false };

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 8000);
  try {
    const url = `${pexelsEndpoint()}?query=${encodeURIComponent(query)}&per_page=${count}&page=${page}&orientation=landscape`;
    const res = await fetch(url, {
      headers: { Authorization: apiKey },
      signal: controller.signal
    });
    if (!res.ok) return { photos: [], hasMore: false };
    const data = await res.json();
    const photos = (data.photos || []).map(p => ({
      url: p.src.large,
      thumb: p.src.medium || p.src.large,
      width: p.width,
      height: p.height,
      photographer: p.photographer,
      photographerUrl: p.photographer_url,
      pageUrl: p.url
    }));
    return { photos, hasMore: Boolean(data.next_page) };
  } catch {
    return { photos: [], hasMore: false };
  } finally {
    clearTimeout(timeout);
  }
}

// Fetches a hero image plus a small gallery from a list of search terms,
// spreading requests across terms so the gallery isn't all one subject.
async function fetchPhotoSet(queries, { heroCount = 1, galleryCount = 6 } = {}) {
  if (!hasPhotoProvider() || !queries.length) {
    return { hero: null, gallery: [] };
  }

  const perQuery = Math.max(2, Math.ceil((heroCount + galleryCount) / queries.length));
  const batches = await Promise.all(queries.map(q => searchPhotos(q, perQuery)));
  const all = batches.flat();

  const seen = new Set();
  const deduped = all.filter(p => {
    if (seen.has(p.url)) return false;
    seen.add(p.url);
    return true;
  });

  const hero = deduped[0] || null;
  const gallery = deduped.slice(1, 1 + galleryCount);
  return { hero, gallery };
}

module.exports = { hasPhotoProvider, searchPhotos, searchPhotosPage, fetchPhotoSet };
