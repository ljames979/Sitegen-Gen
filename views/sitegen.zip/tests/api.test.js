const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { spawn } = require('node:child_process');
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');

const PORT = 3999;
const BASE = `http://localhost:${PORT}`;
const TEST_DB = path.join(__dirname, '.test.db');
const MAIL_FILE = path.join(__dirname, '.test-mail.log');

let serverProc;
let oldSiteServer;
let fakeAiServer;
let fakePexelsServer;
let fakeGoogleServer;
const googleRequests = [];
const aiRequests = []; // every request the app made to the fake Anthropic API
const AI_PORT = 3997;
const PEXELS_PORT = 3996;
const GOOGLE_PORT = 3991;
const OLD_SITE_PORT = 3998;
const STRIPE_PORT = 3995;
const STRIPE_WHSEC = 'whsec_test_secret';
const stripeRequests = [];
let fakeStripeServer;
const stripeSessions = {};
let stripeSessionN = 0;
let fakeNetlifyServer;
const NETLIFY_PORT = 3990;
const netlifyCalls = [];
const netlifyState = { sslFail: false, restoreFail: false, createdNames: 0 };

function waitForServer(url, tries = 40) {
  return new Promise((resolve, reject) => {
    const attempt = (n) => {
      http.get(url, (res) => { res.resume(); resolve(); })
        .on('error', () => {
          if (n <= 0) return reject(new Error('server did not start in time'));
          setTimeout(() => attempt(n - 1), 150);
        });
    };
    attempt(tries);
  });
}

// A minimal "old website" served locally so import/refresh tests don't
// depend on the internet being reachable from wherever this suite runs.
function startOldSiteServer(html) {
  return new Promise((resolve) => {
    const server = http.createServer((req, res) => {
      res.setHeader('Content-Type', 'text/html');
      res.end(html());
    });
    server.listen(OLD_SITE_PORT, () => resolve(server));
  });
}

before(async () => {
  for (const suffix of ['', '-wal', '-shm']) fs.rmSync(TEST_DB + suffix, { force: true });
  fs.rmSync(MAIL_FILE, { force: true });

  let oldHeadline = 'Old Biz - Original Headline';
  oldSiteServer = await startOldSiteServer(() => `<!DOCTYPE html><html><head><title>Old Biz</title>
    <meta name="description" content="An old business site."></head><body>
    <h1>${oldHeadline}</h1>
    <p>This paragraph is long enough to be picked up as the about-section body text for the import test.</p>
    <h2>Cleaning</h2><p>We clean things.</p>
    <address>1 Test Ave, Testville</address>
    <a href="mailto:owner@oldbiz.example">owner@oldbiz.example</a>
    </body></html>`);
  // Fake Anthropic API: answers with usable copy only when the prompt contains
  // the marker ZZ-AI-TEST, otherwise fails with HTTP 500 (to exercise fallback).
  fakeAiServer = http.createServer((req, res) => {
    let body = '';
    req.on('data', c => { body += c; });
    req.on('end', () => {
      const parsed = JSON.parse(body || '{}');
      aiRequests.push({ headers: req.headers, body: parsed });
      if (/editing assistant inside a website builder/.test(parsed.system || '')) {
        const ask = parsed.messages[0].content;
        res.setHeader('content-type', 'application/json');
        const say = (o) => res.end(JSON.stringify({ content: [{ type: 'text', text: typeof o === 'string' ? o : '```json\n' + JSON.stringify(o) + '\n```' }] }));
        if (ask.includes('ZZ-EDIT-OK')) return say({ reply: 'Done.', ops: [
          { op: 'set', path: 'hero.headline', value: 'A friendlier headline' },
          { op: 'set', path: 'theme.primaryColor', value: '#116644' },
          { op: 'add', path: 'services.items', value: { title: 'Gutter Cleaning', description: 'Clearing gutters.' } },
          { op: 'set', path: 'contact.email', value: 'evil@x.test' },
          { op: 'set', path: 'theme.accentColor', value: 'red; background:url(x)' },
          { op: 'set', path: '__proto__.polluted', value: 'yes' } ] });
        if (ask.includes('ZZ-EDIT-NOIR')) return say({ reply: 'Switched to a dark look.', ops: [{ op: 'set', path: 'theme.style', value: 'noir' }] });
        if (ask.includes('ZZ-EDIT-NONE')) return say({ reply: 'I cannot change your phone number here.', ops: [{ op: 'set', path: 'contact.phone', value: '555' }] });
        return say('sorry, no json here');
      }
      if (/website assistant/.test(parsed.system || '')) {
        const last = parsed.messages[parsed.messages.length - 1].content;
        res.setHeader('content-type', 'application/json');
        return res.end(JSON.stringify({ content: [{ type: 'text', text: 'AI says: ' + last.slice(0, 60) }] }));
      }
      const prompt = (parsed.messages && parsed.messages[0] && parsed.messages[0].content) || '';
      if (/ONE small business/.test(parsed.system || '') && /ZZ-GROUND/.test(prompt)) { // facts-only copy for client questionnaires
        const retrying = /previous draft was rejected/.test(prompt);
        const bad = !(retrying && /ZZ-GROUND-RETRY/.test(prompt));
        const reply = bad ? {
          hero: { headline: 'Licensed roofers with 25 years of experience', subheadline: 'The best roofing in Orlando, with free estimates', ctaText: 'Get a Free Estimate' },
          about: 'We are a family-owned team serving Orlando with 24/7 emergency service. Look no further.',
          services: [{ title: 'Roof Repair', description: 'Leaks fixed.' }, { title: 'Solar Panels', description: 'Installed in 3 days.' }],
          faq: [{ question: 'Are you insured?', answer: 'Yes, fully insured.' }],
          seoTitle: 'Best Roofing Orlando', seoDescription: 'Award-winning roofers.'
        } : {
          hero: { headline: 'Roof repair in Kissimmee, explained plainly', subheadline: 'Leaks and storm damage fixed.', ctaText: 'Request a Quote' },
          about: 'Test Grounded Roofing repairs roofs in Kissimmee.',
          services: [{ title: 'Roof Repair', description: 'Fixing leaks.' }],
          faq: [], seoTitle: 'Roof repair in Kissimmee', seoDescription: 'Roof repair in Kissimmee.'
        };
        res.setHeader('content-type', 'application/json');
        return res.end(JSON.stringify({ content: [{ type: 'text', text: JSON.stringify(reply) }] }));
      }
      if (!prompt.includes('ZZ-AI-TEST')) { res.statusCode = 500; return res.end('{}'); }
      const reply = {
        hero: { headline: 'Roofs that last, in Kissimmee', subheadline: 'Repairs and replacements explained plainly.', ctaText: 'Request a Quote' },
        about: 'We repair and replace roofs for homes across Osceola County.\n\nTell us what you are seeing and we will take it from there.',
        services: [
          { title: 'Roof Repair', description: 'Fixing leaks, missing shingles and storm damage.' },
          { title: 'Roof Replacement', description: 'Full tear-off and new roofing systems.' },
          { title: 'Inspections', description: 'A clear look at the condition of your roof.' },
          { title: 'Gutters', description: 'Installation and repair to keep water moving away.' }
        ],
        faq: [{ question: 'How do I get a quote?', answer: 'Contact us with a few details and we will get back to you.' }],
        seoTitle: 'Roofing in Kissimmee | Test Roofing', seoDescription: 'Roof repair and replacement in Kissimmee, FL.'
      };
      res.setHeader('content-type', 'application/json');
      res.end(JSON.stringify({ content: [{ type: 'text', text: 'Here you go:\n```json\n' + JSON.stringify(reply) + '\n```' }] }));
    });
  });
  await new Promise(r => fakeAiServer.listen(AI_PORT, r));

  // Fake Pexels: three photos (and a next page) for queries containing "zzroof".
  fakePexelsServer = http.createServer((req, res) => {
    const u = new URL(req.url, 'http://x');
    const q = u.searchParams.get('query') || '';
    const page = parseInt(u.searchParams.get('page') || '1', 10);
    const photos = /zzroof/i.test(q) ? [1, 2, 3].map(n => ({
      width: 4000, height: 3000, photographer: 'Pat', photographer_url: 'https://pexels.test/pat', url: `https://pexels.test/p/${page}-${n}`,
      src: { large: `https://img.test/large-${page}-${n}.jpg`, medium: `https://img.test/medium-${page}-${n}.jpg` }
    })) : [];
    res.setHeader('content-type', 'application/json');
    res.end(JSON.stringify({ photos, next_page: page < 2 && photos.length ? 'more' : undefined }));
  });
  await new Promise(r => fakePexelsServer.listen(PEXELS_PORT, r));

  // Fake Google Places: one known place, everything else 404.
  fakeGoogleServer = http.createServer((req, res) => {
    googleRequests.push({ url: req.url, headers: req.headers });
    res.setHeader('content-type', 'application/json');
    if (!req.url.startsWith('/places/ChIJtestplace12345')) { res.statusCode = 404; return res.end('{}'); }
    res.end(JSON.stringify({ displayName: { text: 'Palm' }, rating: 4.7, userRatingCount: 128, googleMapsUri: 'https://maps.google.com/?cid=123',
      reviews: [{ rating: 5, text: { text: 'Fixed our leak in one visit. <b>Great</b>' }, authorAttribution: { displayName: 'Sam R' }, relativePublishTimeDescription: 'a month ago' },
                { rating: 3, text: { text: 'Okay service, a bit slow.' }, authorAttribution: { displayName: 'Lee T' }, relativePublishTimeDescription: '2 months ago' }] }));
  });
  await new Promise(r => fakeGoogleServer.listen(GOOGLE_PORT, r));

  // Fake Stripe: records requests and hands back checkout/portal URLs.
  fakeStripeServer = http.createServer((req, res) => {
    let body = '';
    req.on('data', c => { body += c; });
    req.on('end', () => {
      stripeRequests.push({ url: req.url, method: req.method, auth: req.headers.authorization, params: new URLSearchParams(body) });
      res.setHeader('content-type', 'application/json');
      if (req.method === 'POST' && req.url === '/v1/checkout/sessions' && new URLSearchParams(body).get('mode') === 'payment') {
        const id = 'cs_pay_' + (++stripeSessionN);
        stripeSessions[id] = { id, status: 'open', payment_status: 'unpaid', url: 'https://checkout.stripe.test/pay/' + id, customer_details: null };
        return res.end(JSON.stringify(stripeSessions[id]));
      }
      const sm = req.url.match(/^\/v1\/checkout\/sessions\/(cs_pay_\d+)$/);
      if (req.method === 'GET' && sm) return res.end(JSON.stringify(stripeSessions[sm[1]] || {}));
      if (req.url === '/v1/checkout/sessions') return res.end(JSON.stringify({ id: 'cs_test_1', url: 'https://checkout.stripe.test/c/pay_abc' }));
      if (req.url === '/v1/billing_portal/sessions') return res.end(JSON.stringify({ url: 'https://billing.stripe.test/p/session_xyz' }));
      res.statusCode = 404; res.end(JSON.stringify({ error: { message: 'unknown' } }));
    });
  });
  await new Promise(r => fakeStripeServer.listen(STRIPE_PORT, r));

  fakeNetlifyServer = http.createServer((req, res) => {
    const chunks = [];
    req.on('data', c => chunks.push(c));
    req.on('end', () => {
      const raw = Buffer.concat(chunks);
      const rec = { method: req.method, url: req.url, auth: req.headers.authorization, type: req.headers['content-type'], raw };
      try { rec.json = JSON.parse(raw.toString() || 'null'); } catch { rec.json = null; }
      netlifyCalls.push(rec);
      res.setHeader('content-type', 'application/json');
      const u = req.url.replace(/^\/api\/v1/, '');
      if (req.method === 'POST' && u === '/sites') { netlifyState.createdNames++; const name = rec.json.name; return res.end(JSON.stringify({ id: 'nl-site-' + netlifyState.createdNames, name, url: `http://${name}.netlify.app`, ssl_url: `https://${name}.netlify.app` })); }
      if (req.method === 'POST' && /^\/sites\/[^/]+\/deploys$/.test(u)) return res.end(JSON.stringify({ id: 'dep-' + netlifyCalls.length, state: 'uploaded' }));
      if (req.method === 'GET' && /^\/deploys\//.test(u)) return res.end(JSON.stringify({ id: u.split('/')[2], state: 'ready' }));
      if (req.method === 'PATCH' && /^\/sites\/[^/]+$/.test(u)) return res.end(JSON.stringify({ id: u.split('/')[2] }));
      if (req.method === 'GET' && /^\/sites\/[^/]+$/.test(u)) { const dom = [...netlifyCalls].reverse().find(c => c.method === 'PATCH'); return res.end(JSON.stringify({ id: u.split('/')[2], name: 'x', ssl_url: 'https://x.netlify.app', custom_domain: dom && dom.json ? dom.json.custom_domain : null, ssl: false })); }
      if (req.method === 'POST' && /^\/sites\/[^/]+\/ssl$/.test(u)) { if (netlifyState.sslFail) { res.statusCode = 422; return res.end(JSON.stringify({ message: 'DNS not ready' })); } return res.end('{}'); }
      if (req.method === 'POST' && /^\/sites\/[^/]+\/deploys\/[^/]+\/restore$/.test(u)) { if (netlifyState.restoreFail) { res.statusCode = 500; return res.end(JSON.stringify({ message: 'nope' })); } return res.end(JSON.stringify({ id: u.split('/')[4], state: 'ready' })); }
      if (req.method === 'POST' && u === '/hooks') return res.end(JSON.stringify({ id: 'hook1' }));
      res.statusCode = 404; res.end(JSON.stringify({ message: 'unknown' }));
    });
  });
  await new Promise(r => fakeNetlifyServer.listen(NETLIFY_PORT, r));

  // exposed so a later test can mutate it before calling /refresh
  global.__setOldHeadline = (h) => { oldHeadline = h; };

  serverProc = spawn(process.execPath, ['server.js'], {
    cwd: path.join(__dirname, '..'),
    env: {
      ...process.env,
      PORT: String(PORT),
      DB_PATH: TEST_DB,
      MAIL_CAPTURE_FILE: MAIL_FILE,
      ANTHROPIC_API_KEY: 'test-anthropic-key',
      ANTHROPIC_API_URL: `http://localhost:${AI_PORT}/v1/messages`,
      PEXELS_API_KEY: 'test-pexels-key',
      PEXELS_API_URL: `http://localhost:${PEXELS_PORT}/v1/search`,
      GOOGLE_PLACES_API_KEY: 'test-google-key', GOOGLE_PLACES_API_URL: `http://localhost:${GOOGLE_PORT}`,
      STRIPE_SECRET_KEY: 'sk_test_fake', STRIPE_PRICE_ID: 'price_test_123', STRIPE_WEBHOOK_SECRET: STRIPE_WHSEC,
      STRIPE_API_BASE: `http://localhost:${STRIPE_PORT}`,
      NETLIFY_AUTH_TOKEN: 'nfp_test_token', NETLIFY_API_URL: `http://localhost:${NETLIFY_PORT}/api/v1`,
      SESSION_SECRET: 'test-secret-for-suite-only-not-for-real-use',
      ALLOW_PRIVATE_IMPORT_HOSTS: 'true',
      NODE_ENV: 'test'
    },
    stdio: 'pipe'
  });
  await waitForServer(BASE + '/');
});

after(async () => {
  serverProc?.kill();
  oldSiteServer?.close();
  fakeAiServer?.close();
  fakePexelsServer?.close();
  fakeGoogleServer?.close();
  fakeStripeServer?.close();
  fakeNetlifyServer?.close();
  for (const suffix of ['', '-wal', '-shm']) fs.rmSync(TEST_DB + suffix, { force: true });
});

// Small fetch wrapper that keeps a cookie jar per "session" so tests can
// simulate a logged-in browser.
function makeClient() {
  let cookie = '';
  async function req(method, urlPath, body, opts = {}) {
    const headers = { ...(opts.headers || {}) };
    if (cookie) headers['Cookie'] = cookie;
    let payload = body;
    if (body && !(body instanceof FormData) && typeof body === 'object') {
      headers['Content-Type'] = 'application/x-www-form-urlencoded';
      const params = new URLSearchParams();
      for (const [k, v] of Object.entries(body)) {
        if (Array.isArray(v)) v.forEach(item => params.append(k, item)); // repeated keys, like a real form
        else params.append(k, v);
      }
      payload = params.toString();
    }
    const res = await fetch(BASE + urlPath, { method, headers, body: payload, redirect: 'manual' });
    const setCookie = res.headers.get('set-cookie');
    if (setCookie) cookie = setCookie.split(';')[0];
    return res;
  }
  return {
    get: (p, opts) => req('GET', p, null, opts),
    post: (p, body, opts) => req('POST', p, body, opts)
  };
}

test('signup creates an account and redirects to dashboard', async () => {
  const c = makeClient();
  const res = await c.post('/signup', { email: 'alice@example.com', password: 'password1' });
  assert.equal(res.status, 302);
  assert.equal(res.headers.get('location'), '/dashboard');
});

test('signup rejects an invalid email', async () => {
  const c = makeClient();
  const res = await c.post('/signup', { email: 'not-an-email', password: 'password1' });
  assert.equal(res.status, 200); // re-renders signup with an error, no redirect
  const html = await res.text();
  assert.match(html, /valid email/i);
});

test('login fails with wrong password, succeeds with right one', async () => {
  const c = makeClient();
  await c.post('/signup', { email: 'bob@example.com', password: 'password1' });
  await c.post('/logout');

  const bad = await c.post('/login', { email: 'bob@example.com', password: 'wrong' });
  assert.equal(bad.status, 200);
  assert.match(await bad.text(), /invalid email or password/i);

  const good = await c.post('/login', { email: 'bob@example.com', password: 'password1' });
  assert.equal(good.status, 302);
  assert.equal(good.headers.get('location'), '/dashboard');
});

test('dashboard requires auth', async () => {
  const c = makeClient();
  const res = await c.get('/dashboard');
  assert.equal(res.status, 302);
  assert.equal(res.headers.get('location'), '/login');
});

test('create site, edit it, publish it, and view it live', async () => {
  const c = makeClient();
  await c.post('/signup', { email: 'carol@example.com', password: 'password1' });

  const create = await c.post('/sites', { name: 'Carol Consulting' });
  assert.equal(create.status, 302);
  const editPath = create.headers.get('location');
  assert.match(editPath, /^\/sites\/\d+\/edit$/);
  const siteId = editPath.match(/\/sites\/(\d+)\//)[1];

  const editRes = await c.get(editPath);
  assert.equal(editRes.status, 200);
  const editHtml = await editRes.text();
  assert.match(editHtml, /Carol Consulting/);
  assert.match(editHtml, /Page sections/);

  const save = await c.post(editPath, {
    name: 'Carol Consulting',
    hero_headline: 'Consulting That Delivers',
    hero_subheadline: 'Strategy for growing teams.',
    about_heading: 'About',
    about_body: 'We help teams grow.',
    about_imageUrl: 'https://images.example.com/team.jpg',
    services_heading: 'Services',
    service_title: 'Strategy',
    service_description: 'We plan.',
    contact_heading: 'Contact',
    contact_email: 'hello@carolconsulting.com',
    layout_order: 'hero,about,services,testimonials,gallery,faq,hours,contact'
  });
  assert.equal(save.status, 302);

  const publish = await c.post(`/sites/${siteId}/publish`, { published: '1' });
  assert.equal(publish.status, 302);

  const live = await fetch(`${BASE}/site/carol-consulting`);
  assert.equal(live.status, 200);
  const liveHtml = await live.text();
  assert.match(liveHtml, /Consulting That Delivers/);
  // closing CTA band is present on the home page
  assert.match(liveHtml, /cta-band/);

  // about has its own page; the photo was set, so it renders as the
  // two-column layout
  const aboutHtml = await (await fetch(`${BASE}/site/carol-consulting/about`)).text();
  assert.match(aboutHtml, /about-split/);
  assert.match(aboutHtml, /team\.jpg/);

  // contact has its own page too
  const contactHtml = await (await fetch(`${BASE}/site/carol-consulting/contact`)).text();
  assert.match(contactHtml, /hello@carolconsulting.com/);

  // no testimonials were added, so that page (and its old fake-quote
  // fallback) doesn't exist at all — visiting it 404s
  assert.doesNotMatch(liveHtml + aboutHtml + contactHtml, /A Happy Customer/);
  const testimonialsRes = await fetch(`${BASE}/site/carol-consulting/testimonials`);
  assert.equal(testimonialsRes.status, 404);
});

test('editorial theme style and hero trust line render correctly', async () => {
  const c = makeClient();
  await c.post('/signup', { email: 'francesca@example.com', password: 'password1' });

  const create = await c.post('/sites', { name: 'Frank Law' });
  const editPath = create.headers.get('location');
  const siteId = editPath.match(/\/sites\/(\d+)\//)[1];

  await c.post(editPath, {
    name: 'Frank Law',
    hero_headline: 'Real help, real fast.',
    hero_subheadline: 'A firm that actually calls you back.',
    hero_trustText: 'Free consultation • No hidden fees • Available 24/7',
    about_heading: 'About',
    about_body: 'We fight for our clients.',
    services_heading: 'Services',
    theme_style: 'editorial',
    theme_primaryColor: '#2f6f52',
    theme_accentColor: '#1c2a3a',
    layout_order: 'hero,about,services,testimonials,gallery,faq,hours,contact'
  });

  await c.post(`/sites/${siteId}/publish`, { published: '1' });

  const live = await fetch(`${BASE}/site/frank-law`);
  const html = await live.text();
  assert.match(html, /style-editorial/);
  assert.match(html, /Playfair\+Display/);
  assert.match(html, /hero-trust/);
  assert.match(html, /Free consultation/);
  assert.match(html, /No hidden fees/);
  assert.match(html, /Available 24\/7/);
});

test('minimal and warm theme styles render correctly', async () => {
  const c = makeClient();
  await c.post('/signup', { email: 'min@example.com', password: 'password1' });

  const create1 = await c.post('/sites', { name: 'Quiet Studio' });
  const editPath1 = create1.headers.get('location');
  const siteId1 = editPath1.match(/\/sites\/(\d+)\//)[1];
  await c.post(editPath1, {
    name: 'Quiet Studio',
    hero_headline: 'Design that gets out of the way.',
    about_heading: 'About', about_body: 'A small studio.',
    services_heading: 'Services',
    theme_style: 'minimal',
    layout_order: 'hero,about,services,testimonials,gallery,faq,hours,contact'
  });
  await c.post(`/sites/${siteId1}/publish`, { published: '1' });
  const live1 = await fetch(`${BASE}/site/quiet-studio`);
  const html1 = await live1.text();
  assert.match(html1, /<body class="style-minimal[ "]/);

  const create2 = await c.post('/sites', { name: 'Hearth and Home' });
  const editPath2 = create2.headers.get('location');
  const siteId2 = editPath2.match(/\/sites\/(\d+)\//)[1];
  await c.post(editPath2, {
    name: 'Hearth and Home',
    hero_headline: 'A cozy space, cared for like your own.',
    about_heading: 'About', about_body: 'Family-run home cleaning.',
    services_heading: 'Services',
    theme_style: 'warm',
    layout_order: 'hero,about,services,testimonials,gallery,faq,hours,contact'
  });
  await c.post(`/sites/${siteId2}/publish`, { published: '1' });
  const live2 = await fetch(`${BASE}/site/hearth-and-home`);
  const html2 = await live2.text();
  assert.match(html2, /<body class="style-warm[ "]/);
  assert.match(html2, /Fraunces/);
});

test('why choose us, top bar, featured photos, and star ratings render correctly', async () => {
  const c = makeClient();
  await c.post('/signup', { email: 'lawnref@example.com', password: 'password1' });

  const create = await c.post('/sites', { name: 'LSG Lawn Care' });
  const editPath = create.headers.get('location');
  const siteId = editPath.match(/\/sites\/(\d+)\//)[1];

  await c.post(editPath, {
    name: 'LSG Lawn Care',
    hero_headline: 'Residential Lawn Care In Poinciana',
    about_heading: 'About Us', about_body: 'We take pride in our reputation.',
    services_heading: 'Services',
    testimonials_heading: 'What Our Customers Say',
    testimonial_quote: 'They did a fantastic job on my yard.',
    testimonial_author: 'Carmin Castro',
    testimonial_rating: '5',
    testimonial_date: 'April 2026',
    whyChoose_heading: 'Why Choose Us',
    whyChoose_icon: 'check', whyChoose_title: 'Free Quote', whyChoose_text: 'No obligation.',
    gallery_image: ['https://images.example.com/yard1.jpg', 'https://images.example.com/yard2.jpg'],
    contact_heading: 'Contact Us',
    contact_phone: '407-431-6795',
    contact_social_facebook: 'https://facebook.com/lsglawncare',
    contact_acceptSubmissions: '1',
    layout_order: 'hero,about,services,testimonials,whyChoose,gallery,faq,hours,contact'
  });
  await c.post(`/sites/${siteId}/publish`, { published: '1' });

  const live = await fetch(`${BASE}/site/lsg-lawn-care`);
  const html = await live.text();
  // top phone/social bar and the featured photo row both live on the home page
  assert.match(html, /top-bar-phone/);
  assert.match(html, /407-431-6795/);
  assert.match(html, /facebook\.com\/lsglawncare/);
  assert.match(html, /featured-frame/);
  assert.match(html, /yard1\.jpg/);
  assert.match(html, /yard2\.jpg/);
  // the nav links to each section's own page
  assert.match(html, /href="\/site\/lsg-lawn-care\/whyChoose"/);
  assert.match(html, /href="\/site\/lsg-lawn-care\/contact"/);

  // why choose us has its own page, with its icon cards
  const whyChooseHtml = await (await fetch(`${BASE}/site/lsg-lawn-care/whyChoose`)).text();
  assert.match(whyChooseHtml, /id="whyChoose"/);
  assert.match(whyChooseHtml, /why-card/);
  assert.match(whyChooseHtml, /Free Quote/);

  // testimonials has its own page; a real 5-star rating renders as 5 filled
  // stars, not a hardcoded row
  const testimonialsHtml = await (await fetch(`${BASE}/site/lsg-lawn-care/testimonials`)).text();
  assert.match(testimonialsHtml, /★★★★★/);
  assert.doesNotMatch(testimonialsHtml, /★★★★★★/); // never more than 5
  assert.match(testimonialsHtml, /April 2026/);

  // the contact page has the form itself, with its spam honeypot field
  const contactHtml = await (await fetch(`${BASE}/site/lsg-lawn-care/contact`)).text();
  assert.match(contactHtml, /Send us a message/);
  assert.match(contactHtml, /name="website" class="hp-field"/);

  // a page for a section that was never added (gallery headings/images
  // exist, but e.g. the faq page has no items) 404s rather than showing empty
  const faqRes = await fetch(`${BASE}/site/lsg-lawn-care/faq`);
  assert.equal(faqRes.status, 404);
});

test('public contact form stores a submission and shows a thanks banner, while the honeypot silently drops spam', async () => {
  const c = makeClient();
  await c.post('/signup', { email: 'leads@example.com', password: 'password1' });
  const create = await c.post('/sites', { name: 'Leads Test Co' });
  const editPath = create.headers.get('location');
  const siteId = editPath.match(/\/sites\/(\d+)\//)[1];
  await c.post(editPath, {
    name: 'Leads Test Co',
    hero_headline: 'Hello',
    about_heading: 'About', about_body: 'x',
    services_heading: 'Services',
    contact_heading: 'Contact',
    contact_acceptSubmissions: '1',
    layout_order: 'hero,about,services,testimonials,whyChoose,gallery,faq,hours,contact'
  });
  await c.post(`/sites/${siteId}/publish`, { published: '1' });

  const form = new FormData();
  form.append('name', 'Jane Visitor');
  form.append('email', 'jane@example.com');
  form.append('phone', '555-1234');
  form.append('message', 'Can you quote my yard?');
  form.append('website', ''); // honeypot left blank, like a real visitor

  const submit = await fetch(`${BASE}/site/leads-test-co/contact`, { method: 'POST', body: form, redirect: 'manual' });
  assert.equal(submit.status, 302);
  assert.equal(submit.headers.get('location'), '/site/leads-test-co/thank-you');

  const leadsPage = await c.get(`/sites/${siteId}/leads`);
  const leadsHtml = await leadsPage.text();
  assert.match(leadsHtml, /Jane Visitor/);
  assert.match(leadsHtml, /jane@example\.com/);
  assert.match(leadsHtml, /Can you quote my yard/);

  // the submitter lands on the thank-you page
  const confirmPage = await fetch(`${BASE}${submit.headers.get('location')}`);
  const confirmHtml = await confirmPage.text();
  assert.match(confirmHtml, /Thank you!/);
  assert.match(confirmHtml, /noindex/);
  // the flash-style banner still works for the bot-trap path
  const flash = await fetch(`${BASE}/site/leads-test-co/contact?contact_sent=1`);
  assert.match(await flash.text(), /your message has been sent/);

  // but a plain, cached visit to the contact page right after should NOT
  // show the submitter's flash banner to anyone else
  const otherVisitor = await fetch(`${BASE}/site/leads-test-co/contact`);
  const otherHtml = await otherVisitor.text();
  assert.doesNotMatch(otherHtml, /your message has been sent/);

  // honeypot filled in => silently dropped, no new row, still looks like success
  const spamForm = new FormData();
  spamForm.append('name', 'Bot');
  spamForm.append('website', 'http://spam.example');
  const spamSubmit = await fetch(`${BASE}/site/leads-test-co/contact`, { method: 'POST', body: spamForm, redirect: 'manual' });
  assert.equal(spamSubmit.status, 302);
  const leadsPage2 = await c.get(`/sites/${siteId}/leads`);
  const leadsHtml2 = await leadsPage2.text();
  assert.doesNotMatch(leadsHtml2, /Bot</);
});

async function waitForMail(count, tries = 40) {
  for (let i = 0; i < tries; i++) {
    const lines = fs.existsSync(MAIL_FILE) ? fs.readFileSync(MAIL_FILE, 'utf8').split('\n').filter(Boolean) : [];
    if (lines.length >= count) return lines.map(l => JSON.parse(l));
    await new Promise(r => setTimeout(r, 100));
  }
  throw new Error('expected mail was not sent');
}

test('new contact-form messages are emailed to the notify address (falling back to the contact email)', async () => {
  const c = makeClient();
  await c.post('/signup', { email: 'mailer@example.com', password: 'password1' });
  const base = fs.existsSync(MAIL_FILE) ? fs.readFileSync(MAIL_FILE, 'utf8').split('\n').filter(Boolean).length : 0;

  async function makeSite(name, extra) {
    const create = await c.post('/sites', { name });
    const editPath = create.headers.get('location');
    const siteId = editPath.match(/\/sites\/(\d+)\//)[1];
    await c.post(editPath, {
      name, hero_headline: 'Hi', about_heading: 'About', about_body: 'x', services_heading: 'Services',
      contact_heading: 'Contact', contact_acceptSubmissions: '1', ...extra,
      layout_order: 'hero,about,services,testimonials,whyChoose,gallery,faq,hours,contact'
    });
    await c.post(`/sites/${siteId}/publish`, { published: '1' });
  }
  await makeSite('Mail Co One', { contact_email: 'public@mailco.com', contact_notifyEmail: 'private@mailco.com' });
  await makeSite('Mail Co Two', { contact_email: 'only@mailco.com' });

  const f1 = new FormData();
  f1.append('name', 'Jane\nBcc: attacker@evil.com');
  f1.append('email', 'jane@example.com');
  f1.append('message', 'Please call me');
  await fetch(`${BASE}/site/mail-co-one/contact`, { method: 'POST', body: f1, redirect: 'manual' });
  const f2 = new FormData();
  f2.append('name', 'Sam');
  f2.append('phone', '555-0000');
  await fetch(`${BASE}/site/mail-co-two/contact`, { method: 'POST', body: f2, redirect: 'manual' });

  const mails = (await waitForMail(base + 2)).slice(base);
  const one = mails.find(m => /Mail Co One/.test(m.subject));
  const two = mails.find(m => /Mail Co Two/.test(m.subject));
  assert.equal(one.to[0].address, 'private@mailco.com');
  assert.equal(one.replyTo[0].address, 'jane@example.com');
  assert.match(one.text, /Please call me/);
  assert.doesNotMatch(one.subject, /[\r\n]/);
  assert.equal(two.to[0].address, 'only@mailco.com');
});

test('intake details fill in a generated site; checklist flags what is missing; duplicate copies it', async () => {
  const c = makeClient();
  await c.post('/signup', { email: 'intake@example.com', password: 'password1' });

  // with full client details
  const gen = await c.post('/sites/generate', {
    business_type: 'plumbing company', business_name: 'Intake Plumbing',
    phone: '555-0199', email: 'office@intakeplumbing.com', address: '1 Main St, Orlando, FL',
    weekday_hours: '8:00 AM – 6:00 PM', saturday_hours: '9:00 AM – 1:00 PM',
    facebook: 'https://facebook.com/intakeplumbing', use_brand_color: '1', brand_color: '#ff6600'
  });
  assert.equal(gen.status, 302);
  const editPath = gen.headers.get('location').split('?')[0];
  const siteId = editPath.match(/\/sites\/(\d+)\//)[1];
  const editHtml = await (await c.get(editPath)).text();
  assert.match(editHtml, /value="555-0199"/);
  assert.match(editHtml, /office@intakeplumbing\.com/);
  assert.match(editHtml, /8:00 AM – 6:00 PM/);
  assert.match(editHtml, /#ff6600/i);

  const full = await (await c.get(`/sites/${siteId}/checklist`)).json();
  assert.ok(!full.items.some(i => /Hours page still shows the default/.test(i.text)), 'real hours supplied');
  assert.ok(!full.items.some(i => /No phone number or email/.test(i.text)));

  // without details: placeholder hours and missing contact info are flagged
  const gen2 = await c.post('/sites/generate', { business_type: 'hair salon', business_name: 'Bare Salon' });
  const id2 = gen2.headers.get('location').match(/\/sites\/(\d+)\//)[1];
  const bare = await (await c.get(`/sites/${id2}/checklist`)).json();
  assert.ok(bare.items.some(i => i.level === 'warn' && /default Mon–Fri/.test(i.text)));
  assert.ok(bare.items.some(i => i.level === 'warn' && /No phone number or email/.test(i.text)));

  // bad colors / junk are ignored rather than saved
  const gen3 = await c.post('/sites/generate', { business_type: 'plumber', business_name: 'Junk Co', use_brand_color: '1', brand_color: 'red;}</style>', email: 'nope', facebook: 'javascript:alert(1)' });
  const id3 = gen3.headers.get('location').match(/\/sites\/(\d+)\//)[1];
  const junkHtml = await (await c.get(`/sites/${id3}/edit`)).text();
  assert.doesNotMatch(junkHtml, /javascript:alert/);
  assert.doesNotMatch(junkHtml, /red;\}/);

  // duplicate: new draft site with the same content, original untouched
  const dup = await c.post(`/sites/${siteId}/duplicate`);
  assert.equal(dup.status, 302);
  const dupHtml = await (await c.get(dup.headers.get('location'))).text();
  assert.match(dupHtml, /Intake Plumbing \(copy\)/);
  assert.match(dupHtml, /555-0199/);

  // someone else cannot duplicate or read the checklist of this site
  const other = makeClient();
  await other.post('/signup', { email: 'intake-other@example.com', password: 'password1' });
  assert.equal((await other.post(`/sites/${siteId}/duplicate`)).status, 404);
  assert.equal((await other.get(`/sites/${siteId}/checklist`)).status, 404);
});

test('published pages carry canonical, share, favicon and structured data; sitemap lists every page', async () => {
  const c = makeClient();
  await c.post('/signup', { email: 'seo@example.com', password: 'password1' });
  const create = await c.post('/sites', { name: 'Seo Plumbing' });
  const editPath = create.headers.get('location');
  const siteId = editPath.match(/\/sites\/(\d+)\//)[1];
  await c.post(editPath, {
    name: 'Seo Plumbing', hero_headline: 'Fast fixes', hero_imageUrl: '/uploads/hero-test.jpg',
    about_heading: 'About', about_body: 'We fix pipes.', services_heading: 'Services',
    contact_heading: 'Contact', contact_phone: '555-0123', contact_email: 'hi@seoplumbing.com',
    contact_address: '9 Pipe St, Tampa, FL', contact_social_facebook: 'https://facebook.com/seoplumbing',
    seo_title: 'Seo Plumbing | Tampa', seo_description: 'Plumbers in Tampa.',
    layout_order: 'hero,about,services,testimonials,whyChoose,gallery,faq,hours,contact'
  });
  await c.post(`/sites/${siteId}/publish`, { published: '1', force: '1' });

  const html = await (await fetch(`${BASE}/site/seo-plumbing/about`)).text();
  assert.match(html, /<link rel="canonical" href="http:\/\/localhost:3999\/site\/seo-plumbing\/about">/);
  assert.match(html, /og:image" content="http:\/\/localhost:3999\/uploads\/hero-test\.jpg"/);
  assert.match(html, /rel="icon" type="image\/svg\+xml"/);
  const ld = JSON.parse(html.match(/<script type="application\/ld\+json">(.*?)<\/script>/s)[1]);
  assert.equal(ld['@type'], 'LocalBusiness');
  assert.equal(ld.telephone, '555-0123');
  assert.equal(ld.address.streetAddress, '9 Pipe St, Tampa, FL');
  assert.deepEqual(ld.sameAs, ['https://facebook.com/seoplumbing']);
  assert.doesNotMatch(html, /name="robots"/);

  // the editor's preview must not be indexable
  const preview = await (await c.get(`/sites/${siteId}/preview`)).text();
  assert.match(preview, /name="robots" content="noindex"/);

  const xml = await (await fetch(`${BASE}/sitemap.xml`)).text();
  assert.match(xml, /\/site\/seo-plumbing<\/loc>/);
  assert.match(xml, /\/site\/seo-plumbing\/about<\/loc>/);
  assert.match(xml, /\/site\/seo-plumbing\/contact<\/loc>/);
  assert.doesNotMatch(xml, /\/site\/seo-plumbing\/faq<\/loc>/); // no FAQ items, so no page
  const robots = await (await fetch(`${BASE}/robots.txt`)).text();
  assert.match(robots, /Sitemap: http:\/\/localhost:3999\/sitemap\.xml/);
});

test('uploaded photos are shrunk and rotated, and photos from rejected contact submissions are deleted', async (t) => {
  let sharp;
  try { sharp = require('sharp'); } catch { return t.skip('sharp not installed'); }
  const c = makeClient();
  await c.post('/signup', { email: 'imgs@example.com', password: 'password1' });
  const create = await c.post('/sites', { name: 'Img Co' });
  const siteId = create.headers.get('location').match(/\/sites\/(\d+)\//)[1];

  const big = await sharp({ create: { width: 3200, height: 2400, channels: 3, background: { r: 200, g: 90, b: 30 } } })
    .jpeg({ quality: 100 }).toBuffer();
  const form = new FormData();
  form.append('image', new Blob([big], { type: 'image/jpeg' }), 'big.jpg');
  const up = await c.post(`/sites/${siteId}/upload`, form);
  const { ok, url } = await up.json();
  assert.ok(ok);
  const meta = await sharp(Buffer.from(await (await fetch(BASE + url)).arrayBuffer())).metadata();
  assert.equal(meta.width, 1920);
  assert.equal(meta.height, 1440);

  // a spam submission (honeypot filled) with a photo must not leave the file behind
  await c.post(`/sites/${siteId}/edit`, { name: 'Img Co', contact_acceptSubmissions: '1', layout_order: 'hero,about,services,testimonials,whyChoose,gallery,faq,hours,contact' });
  await c.post(`/sites/${siteId}/publish`, { published: '1' });
  const before = fs.readdirSync(path.join(__dirname, '..', 'public', 'uploads')).length;
  const spam = new FormData();
  spam.append('website', 'http://spam.example');
  spam.append('name', 'Bot');
  spam.append('photo', new Blob([big], { type: 'image/jpeg' }), 'spam.jpg');
  await fetch(`${BASE}/site/img-co/contact`, { method: 'POST', body: spam, redirect: 'manual' });
  await new Promise(r => setTimeout(r, 200));
  const after = fs.readdirSync(path.join(__dirname, '..', 'public', 'uploads')).length;
  assert.equal(after, before);
});

// Minimal zip reader (central directory + inflate) so the export test can
// inspect real file contents without any extra dependency.
function readZip(buf) {
  const zlib = require('node:zlib');
  let eocd = buf.length - 22;
  while (eocd >= 0 && buf.readUInt32LE(eocd) !== 0x06054b50) eocd--;
  const count = buf.readUInt16LE(eocd + 10);
  let p = buf.readUInt32LE(eocd + 16);
  const out = {};
  for (let i = 0; i < count; i++) {
    const method = buf.readUInt16LE(p + 10);
    const compSize = buf.readUInt32LE(p + 20);
    const nameLen = buf.readUInt16LE(p + 28), extraLen = buf.readUInt16LE(p + 30), commentLen = buf.readUInt16LE(p + 32);
    const localOffset = buf.readUInt32LE(p + 42);
    const name = buf.toString('utf8', p + 46, p + 46 + nameLen);
    const lNameLen = buf.readUInt16LE(localOffset + 26), lExtraLen = buf.readUInt16LE(localOffset + 28);
    const data = buf.subarray(localOffset + 30 + lNameLen + lExtraLen, localOffset + 30 + lNameLen + lExtraLen + compSize);
    out[name] = method === 8 ? zlib.inflateRawSync(data) : Buffer.from(data);
    p += 46 + nameLen + extraLen + commentLen;
  }
  return out;
}

test('a site exports as a static zip with rewritten links and bundled photos', async () => {
  const c = makeClient();
  await c.post('/signup', { email: 'export@example.com', password: 'password1' });
  const create = await c.post('/sites', { name: 'Export Co' });
  const editPath = create.headers.get('location');
  const siteId = editPath.match(/\/sites\/(\d+)\//)[1];

  // a real uploaded photo to use as the hero
  const up = new FormData();
  up.append('image', new Blob([Buffer.from('/9j/4AAQSkZJRgABAQEASABIAAD/2wBDAP//////////////////////////////////////////////////////////////////////////////////////wgALCAABAAEBAREA/8QAFBABAAAAAAAAAAAAAAAAAAAAAP/aAAgBAQABPxA=', 'base64')], { type: 'image/jpeg' }), 'tiny.jpg');
  const { url } = await (await c.post(`/sites/${siteId}/upload`, up)).json();

  await c.post(editPath, {
    name: 'Export Co', hero_headline: 'Static and sturdy', hero_imageUrl: url,
    about_heading: 'About', about_body: 'We build things.', services_heading: 'Services',
    contact_heading: 'Contact', contact_phone: '555-7777', contact_acceptSubmissions: '1',
    layout_order: 'hero,about,services,testimonials,whyChoose,gallery,faq,hours,contact'
  });

  const res = await c.get(`/sites/${siteId}/export`);
  assert.equal(res.status, 200);
  assert.match(res.headers.get('content-type'), /zip/);
  assert.match(res.headers.get('content-disposition'), /export-co-website\.zip/);
  const files = readZip(Buffer.from(await res.arrayBuffer()));
  const names = Object.keys(files);
  for (const n of ['index.html', 'about.html', 'services.html', 'contact.html', 'README.txt']) {
    assert.ok(names.includes(n), `${n} should be in the zip (got ${names.join(', ')})`);
  }
  assert.ok(!names.includes('faq.html'), 'empty sections are not exported');

  const index = files['index.html'].toString();
  assert.match(index, /Static and sturdy/);
  assert.match(index, /href="about\.html"/);
  assert.match(index, /href="contact\.html"/);
  assert.doesNotMatch(index, /href="\/(about|contact)?"/);
  assert.ok(index.includes(`uploads/${url.split('/').pop()}`));
  assert.ok(!index.includes(`"/uploads/`), 'photo paths are relative');
  assert.ok(names.includes(`uploads/${url.split('/').pop()}`), 'hero photo is bundled');
  assert.doesNotMatch(index, /rel="canonical"/);
  JSON.parse(index.match(/<script type="application\/ld\+json">(.*?)<\/script>/s)[1]); // still valid JSON

  // the form needs a server, so it is left out of the export (phone stays)
  const contact = files['contact.html'].toString();
  assert.doesNotMatch(contact, /<form/);
  assert.match(contact, /555-7777/);

  // other users can't export it
  const other = makeClient();
  await other.post('/signup', { email: 'export-other@example.com', password: 'password1' });
  assert.equal((await other.get(`/sites/${siteId}/export`)).status, 404);
});

test('AI writes the copy from the owner\'s real details; failures fall back to templates; rewrite saves history', async () => {
  const c = makeClient();
  await c.post('/signup', { email: 'ai@example.com', password: 'password1' });

  aiRequests.length = 0;
  const gen = await c.post('/sites/generate', {
    business_type: 'roofing company', business_name: 'Test Roofing',
    address: '5 Shingle Ln, Kissimmee, FL', phone: '555-0111', years_in_business: '12',
    badges: 'Licensed & Insured', service_areas: 'Kissimmee, St. Cloud',
    specialties: 'ZZ-AI-TEST family run, tile roofs'
  });
  assert.equal(gen.status, 302);
  assert.match(gen.headers.get('location'), /generated=ai/);
  const editPath = gen.headers.get('location').split('?')[0];
  const siteId = editPath.match(/\/sites\/(\d+)\//)[1];

  // what was sent: real facts in, "never invent" rules in the system prompt, key in the header
  assert.equal(aiRequests.length, 1);
  const sent = aiRequests[0];
  assert.equal(sent.headers['x-api-key'], 'test-anthropic-key');
  assert.match(sent.body.system, /Never invent/);
  const prompt = sent.body.messages[0].content;
  assert.match(prompt, /Test Roofing/);
  assert.match(prompt, /Years in business \(stated by the owner\): 12/);
  assert.match(prompt, /Licensed & Insured/);
  assert.match(prompt, /Kissimmee, St\. Cloud/);
  assert.match(prompt, /5 Shingle Ln/);

  const html = await (await c.get(gen.headers.get('location'))).text();
  assert.match(html, /Roofs that last, in Kissimmee/);
  assert.match(html, /wrote the text with AI/);
  assert.match(html, /Roof Replacement/);
  assert.match(html, /Roofing in Kissimmee \| Test Roofing/);      // AI SEO title
  assert.match(html, /name="meta_businessType"[^>]*value="roofing company"/);
  assert.match(html, /name="trust_stat_value" value="12"/);
  assert.match(html, /Licensed &amp; Insured/);
  assert.match(html, /value="555-0111"/);                           // intake data kept

  // AI unavailable/failing for this request (no marker => fake returns 500): templates take over
  const gen2 = await c.post('/sites/generate', { business_type: 'plumbing company', business_name: 'Fallback Plumbing' });
  assert.equal(gen2.status, 302);
  assert.doesNotMatch(gen2.headers.get('location'), /generated=ai/);
  const html2 = await (await c.get(gen2.headers.get('location'))).text();
  assert.match(html2, /built-in templates/);
  assert.match(html2, /Drain Cleaning/);

  // rewrite: failure leaves the site untouched
  const before = await (await c.get(editPath)).text();
  const failed = await c.post(`/sites/${siteId}/rewrite-copy`, { instruction: 'make it fancier' });
  assert.match(failed.headers.get('location'), /rewrite=failed/);
  assert.match(await (await c.get(`/sites/${siteId}/edit`)).text(), /Roofs that last, in Kissimmee/);

  // rewrite: success replaces text only, keeps contact info, and snapshots history first
  await c.post(editPath, {
    name: 'Test Roofing', hero_headline: 'My own headline', about_heading: 'About', about_body: 'My own about.',
    services_heading: 'Services', contact_heading: 'Contact', contact_phone: '555-0111', contact_acceptSubmissions: '1',
    meta_businessType: 'roofing company', trust_badges: 'Licensed & Insured',
    layout_order: 'hero,about,services,testimonials,whyChoose,gallery,faq,hours,contact'
  });
  const ok = await c.post(`/sites/${siteId}/rewrite-copy`, { instruction: 'ZZ-AI-TEST more premium' });
  assert.match(ok.headers.get('location'), /rewrite=done/);
  assert.match(aiRequests[aiRequests.length - 1].body.messages[0].content, /Extra direction from the owner: ZZ-AI-TEST more premium/);
  const after = await (await c.get(`/sites/${siteId}/edit?rewrite=done`)).text();
  assert.match(after, /Roofs that last, in Kissimmee/);
  assert.doesNotMatch(after, /My own headline/);
  assert.match(after, /value="555-0111"/);
  assert.match(after, /Before AI rewrite/);

  // other users cannot rewrite someone else's site
  const other = makeClient();
  await other.post('/signup', { email: 'ai-other@example.com', password: 'password1' });
  assert.equal((await other.post(`/sites/${siteId}/rewrite-copy`, {})).status, 404);
});

test('trust section: badges, numbers, service areas, Google link and before/after pairs render on the right pages', async () => {
  const c = makeClient();
  await c.post('/signup', { email: 'trust@example.com', password: 'password1' });
  const create = await c.post('/sites', { name: 'Trust Co' });
  const editPath = create.headers.get('location');
  const siteId = editPath.match(/\/sites\/(\d+)\//)[1];
  await c.post(editPath, {
    name: 'Trust Co', hero_headline: 'Trusted', about_heading: 'About', about_body: 'We do the work.',
    services_heading: 'Services', contact_heading: 'Contact', contact_phone: '555-0199', contact_address: '1 Main St, Orlando, FL',
    testimonials_heading: 'Reviews', testimonial_quote: 'Great job', testimonial_author: 'Pat', testimonial_rating: '5', testimonial_date: '',
    gallery_heading: 'Gallery',
    ba_before: ['https://img.test/b1.jpg', 'https://img.test/b2.jpg'], ba_after: ['https://img.test/a1.jpg', ''], ba_caption: ['Kitchen refresh', 'half pair'],
    trust_badges: 'Licensed & Insured\nBBB A+, Licensed & Insured', trust_stat_value: ['15', '', '300+'], trust_stat_label: ['Years in business', 'no value', 'Roofs installed'],
    trust_serviceAreas: 'Orlando, Kissimmee\nSt. Cloud',
    trust_googleReviewsUrl: 'https://g.page/r/trust-co',
    layout_order: 'hero,about,services,testimonials,whyChoose,gallery,faq,hours,contact'
  });
  await c.post(`/sites/${siteId}/publish`, { published: '1' });

  const home = await (await fetch(`${BASE}/site/trust-co`)).text();
  assert.match(home, /class="trust-strip"/);
  assert.match(home, /<strong data-count="15">15<\/strong><span>Years in business<\/span>/);
  assert.match(home, /<strong data-count="300" data-suffix="\+">300\+<\/strong><span>Roofs installed<\/span>/);
  assert.doesNotMatch(home, /no value/);                              // stat without a value is dropped
  assert.match(home, /Licensed &amp; Insured/);
  assert.equal((home.match(/class="trust-badge"/g) || []).length, 2); // de-duplicated: Licensed & Insured, BBB A+
  assert.match(home, /href="https:\/\/g\.page\/r\/trust-co"/);

  const about = await (await fetch(`${BASE}/site/trust-co/about`)).text();
  assert.match(about, /Areas We Serve/);
  for (const area of ['Orlando', 'Kissimmee', 'St. Cloud']) assert.match(about, new RegExp(`area-chip">${area.replace('.', '\\.')}<`));

  const reviews = await (await fetch(`${BASE}/site/trust-co/testimonials`)).text();
  assert.match(reviews, /Read more on Google/);

  // gallery page exists thanks to a complete before/after pair, even with no regular photos
  const gallery = await fetch(`${BASE}/site/trust-co/gallery`);
  assert.equal(gallery.status, 200);
  const galleryHtml = await gallery.text();
  assert.match(galleryHtml, /class="ba-pair"/);
  assert.match(galleryHtml, /Kitchen refresh/);
  assert.doesNotMatch(galleryHtml, /half pair/);                      // pair missing its "after" photo is dropped
  assert.equal((galleryHtml.match(/class="ba-pair"/g) || []).length, 1);
  assert.match(home, /href="\/site\/trust-co\/gallery"/);

  // structured data lists the service area
  const ld = JSON.parse(home.match(/<script type="application\/ld\+json">(.*?)<\/script>/s)[1]);
  assert.deepEqual(ld.areaServed.map(a => a.name), ['Orlando', 'Kissimmee', 'St. Cloud']);

  // unsafe / non-http review links are discarded; nothing shows without data
  await c.post(editPath, {
    name: 'Trust Co', hero_headline: 'Trusted', about_heading: 'About', about_body: 'x', services_heading: 'Services',
    contact_heading: 'Contact', trust_googleReviewsUrl: 'javascript:alert(1)',
    layout_order: 'hero,about,services,testimonials,whyChoose,gallery,faq,hours,contact'
  });
  const bare = await (await fetch(`${BASE}/site/trust-co`)).text();
  assert.doesNotMatch(bare, /javascript:alert/);
  assert.doesNotMatch(bare, /class="trust-strip"/);
  assert.equal((await fetch(`${BASE}/site/trust-co/gallery`)).status, 404);
});

test('photo picker searches Pexels, pages through results, and is private to the site owner', async () => {
  const c = makeClient();
  await c.post('/signup', { email: 'picker@example.com', password: 'password1' });
  const create = await c.post('/sites', { name: 'Picker Co' });
  const siteId = create.headers.get('location').match(/\/sites\/(\d+)\//)[1];

  const r1 = await (await c.get(`/sites/${siteId}/photos?q=zzroof`)).json();
  assert.equal(r1.configured, true);
  assert.equal(r1.photos.length, 3);
  assert.equal(r1.photos[0].url, 'https://img.test/large-1-1.jpg');
  assert.equal(r1.photos[0].thumb, 'https://img.test/medium-1-1.jpg');
  assert.equal(r1.photographer === undefined, true);
  assert.equal(r1.photos[0].photographer, 'Pat');
  assert.equal(r1.hasMore, true);

  const r2 = await (await c.get(`/sites/${siteId}/photos?q=zzroof&page=2`)).json();
  assert.equal(r2.photos[0].url, 'https://img.test/large-2-1.jpg');
  assert.equal(r2.hasMore, false);

  const none = await (await c.get(`/sites/${siteId}/photos?q=nothing-matches`)).json();
  assert.deepEqual(none.photos, []);

  // the editor wires the picker up
  const editor = await (await c.get(`/sites/${siteId}/edit`)).text();
  assert.match(editor, /id="pickerOverlay"/);
  assert.ok((editor.match(/class="btn-secondary pick-btn"/g) || []).length >= 3); // hero, about, gallery (+ template)

  const other = makeClient();
  await other.post('/signup', { email: 'picker-other@example.com', password: 'password1' });
  assert.equal((await other.get(`/sites/${siteId}/photos?q=zzroof`)).status, 404);
  const anon = makeClient();
  const anonRes = await anon.get(`/sites/${siteId}/photos?q=zzroof`);
  assert.equal(anonRes.status, 302);
});

test('client edit link: limited self-service editing, revocable, private', async () => {
  const c = makeClient();
  await c.post('/signup', { email: 'agency@example.com', password: 'password1' });
  const create = await c.post('/sites', { name: 'Client Roofing' });
  const editPath = create.headers.get('location');
  const siteId = editPath.match(/\/sites\/(\d+)\//)[1];
  await c.post(editPath, {
    name: 'Client Roofing', hero_headline: 'Original headline', hero_subheadline: 'Original sub', about_heading: 'About', about_body: 'Original about',
    services_heading: 'Services', service_title: ['Old service'], service_description: ['Old description'],
    hours_heading: 'Hours', hours_day: ['Monday'], hours_time: ['9-5'],
    testimonials_heading: 'Reviews', testimonial_quote: 'Great work', testimonial_author: 'Sam', testimonial_rating: '5', testimonial_date: '',
    contact_heading: 'Contact', contact_phone: '555-0000', contact_acceptSubmissions: '1',
    trust_badges: 'Licensed & Insured', theme_primaryColor: '#123456', theme_style: 'editorial',
    layout_order: 'hero,about,services,testimonials,whyChoose,gallery,faq,hours,contact'
  });
  await c.post(`/sites/${siteId}/publish`, { published: '1' });

  // the link is shown once, right after creating it
  const made = await c.post(`/sites/${siteId}/client-link`);
  assert.match(made.headers.get('location'), /clientlink=1/);
  const shown = await (await c.get(made.headers.get('location'))).text();
  const link = shown.match(/<strong id="clientLinkText">(http[^<]+)<\/strong>/)[1];
  const token = link.split('/client/')[1];
  assert.match(token, /^[A-Za-z0-9_-]{32}$/);
  const again = await (await c.get(`/sites/${siteId}/edit?clientlink=1`)).text();
  assert.doesNotMatch(again, new RegExp(token), 'link must not be shown a second time');
  assert.match(again, /A client link is active/);

  // anyone with the link (no login) gets the limited editor, with privacy headers
  const page = await fetch(`${BASE}/client/${token}`);
  assert.equal(page.status, 200);
  assert.equal(page.headers.get('referrer-policy'), 'no-referrer');
  assert.match(page.headers.get('x-robots-tag'), /noindex/);
  const pageHtml = await page.text();
  assert.match(pageHtml, /Original headline/);
  assert.doesNotMatch(pageHtml, /theme_primaryColor|layout_order|custom_domain|trust_badges/, 'owner-only controls are not offered');

  // saving changes only the allowed fields
  const save = await fetch(`${BASE}/client/${token}`, {
    method: 'POST', redirect: 'manual',
    headers: { 'content-type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams([
      ['hero_headline', 'Client-written headline'], ['hero_subheadline', 'New sub'], ['about_body', 'Client about text'],
      ['services_present', '1'], ['service_title', 'New service'], ['service_description', 'New description'],
      ['hours_present', '1'], ['hours_day', 'Monday'], ['hours_time', '8-6'],
      ['contact_phone', '555-9999'], ['contact_email', 'client@roofing.test'], ['contact_address', '2 Tile Rd'],
      ['gallery_present', '1'], ['gallery_image', 'https://img.test/c1.jpg'], ['gallery_image', 'javascript:alert(1)'],
      // attempts to change things clients must not touch:
      ['theme_primaryColor', '#ff0000'], ['trust_badges', 'Fake Badge'], ['published', '0'], ['name', 'Hacked']
    ]).toString()
  });
  assert.equal(save.status, 302);
  assert.match(save.headers.get('location'), /saved=1/);

  const live = await (await fetch(`${BASE}/site/client-roofing`)).text();
  assert.match(live, /Client-written headline/);
  assert.match(live, /555-9999/);
  assert.match(live, /Licensed &amp; Insured/);                      // credentials untouched
  assert.doesNotMatch(live, /Fake Badge/);
  assert.match(live, /#123456/);                                      // theme untouched
  assert.doesNotMatch(live, /#ff0000/);
  const about = await (await fetch(`${BASE}/site/client-roofing/about`)).text();
  assert.match(about, /Client about text/);
  assert.match(await (await fetch(`${BASE}/site/client-roofing/services`)).text(), /New service/);
  assert.match(await (await fetch(`${BASE}/site/client-roofing/hours`)).text(), /8-6/);
  const galleryHtml = await (await fetch(`${BASE}/site/client-roofing/gallery`)).text();
  assert.match(galleryHtml, /c1\.jpg/);
  assert.doesNotMatch(galleryHtml, /javascript:alert/);
  assert.match(await (await fetch(`${BASE}/site/client-roofing/testimonials`)).text(), /Great work/); // reviews untouched

  const ownerView = await (await c.get(`/sites/${siteId}/edit`)).text();
  assert.match(ownerView, /value="Client Roofing"/);                 // name untouched
  assert.match(ownerView, /Before client edit/);                      // undoable from version history
  assert.match(ownerView, /last used/);

  // a partial form (e.g. only the headline) never wipes other content
  await fetch(`${BASE}/client/${token}`, {
    method: 'POST', redirect: 'manual', headers: { 'content-type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams([['hero_headline', 'Only the headline']]).toString()
  });
  assert.match(await (await fetch(`${BASE}/site/client-roofing/services`)).text(), /New service/);

  // clients can upload photos through the link; nothing works without a valid one
  const up = new FormData();
  up.append('image', new Blob([Buffer.from('/9j/4AAQSkZJRgABAQEASABIAAD/2wBDAP//////////////////////////////////////////////////////////////////////////////////////wgALCAABAAEBAREA/8QAFBABAAAAAAAAAAAAAAAAAAAAAP/aAAgBAQABPxA=', 'base64')], { type: 'image/jpeg' }), 'tiny.jpg');
  const upRes = await (await fetch(`${BASE}/client/${token}/upload`, { method: 'POST', body: up })).json();
  assert.ok(upRes.ok);
  assert.match(upRes.url, /^\/uploads\//);
  assert.equal((await fetch(`${BASE}/client/${'x'.repeat(32)}/upload`, { method: 'POST', body: new FormData() })).status, 404);
  const anonEditor = await fetch(`${BASE}/sites/${siteId}/edit`, { redirect: 'manual' });
  assert.equal(anonEditor.status, 302);
  assert.equal((await fetch(`${BASE}/client/not-a-real-token`)).status, 404);
  assert.equal((await fetch(`${BASE}/client/${'a'.repeat(32)}`)).status, 404);

  // replacing the link kills the old one; revoking kills the new one
  const made2 = await c.post(`/sites/${siteId}/client-link`);
  const token2 = (await (await c.get(made2.headers.get('location'))).text()).match(/\/client\/([A-Za-z0-9_-]{32})</)[1];
  assert.notEqual(token2, token);
  assert.equal((await fetch(`${BASE}/client/${token}`)).status, 404);
  assert.equal((await fetch(`${BASE}/client/${token2}`)).status, 200);
  await c.post(`/sites/${siteId}/client-link/revoke`);
  assert.equal((await fetch(`${BASE}/client/${token2}`)).status, 404);

  // someone else can't create or revoke links for this site
  const other = makeClient();
  await other.post('/signup', { email: 'agency-other@example.com', password: 'password1' });
  assert.equal((await other.post(`/sites/${siteId}/client-link`)).status, 404);
  assert.equal((await other.post(`/sites/${siteId}/client-link/revoke`)).status, 404);
});

test('full backup is admin-only and contains the database and uploads', async () => {
  // the very first account created in this suite (alice) is the admin
  const admin = makeClient();
  const login = await admin.post('/login', { email: 'alice@example.com', password: 'password1' });
  assert.equal(login.status, 302);
  assert.match(await (await admin.get('/dashboard')).text(), /href="\/admin\/backup"/);

  const res = await admin.get('/admin/backup');
  assert.equal(res.status, 200);
  assert.match(res.headers.get('content-type'), /zip/);
  assert.match(res.headers.get('content-disposition'), /sitegen-backup-\d{4}-\d{2}-\d{2}\.zip/);
  const files = readZip(Buffer.from(await res.arrayBuffer()));
  assert.ok(files['sitegen.db'], 'database snapshot is included');
  assert.equal(files['sitegen.db'].subarray(0, 15).toString(), 'SQLite format 3');
  assert.ok(files['RESTORE.txt']);
  assert.ok(Object.keys(files).some(n => n.startsWith('uploads/')), 'uploaded photos are included');

  const other = makeClient();
  await other.post('/signup', { email: 'not-admin@example.com', password: 'password1' });
  assert.doesNotMatch(await (await other.get('/dashboard')).text(), /admin\/backup/);
  assert.equal((await other.get('/admin/backup')).status, 404);
  const anon = makeClient();
  assert.equal((await anon.get('/admin/backup')).status, 302);
});

test('domain-check only approves published custom domains, and only for the local proxy', async () => {
  const c = makeClient();
  await c.post('/signup', { email: 'domains@example.com', password: 'password1' });
  const create = await c.post('/sites', { name: 'Domain Co' });
  const editPath = create.headers.get('location');
  const siteId = editPath.match(/\/sites\/(\d+)\//)[1];
  await c.post(editPath, {
    name: 'Domain Co', custom_domain: 'www.domainco.test', hero_headline: 'Hi', about_heading: 'About', about_body: 'x',
    services_heading: 'Services', contact_heading: 'Contact',
    layout_order: 'hero,about,services,testimonials,whyChoose,gallery,faq,hours,contact'
  });
  const check = (domain, headers) => fetch(`${BASE}/internal/domain-check?domain=${encodeURIComponent(domain)}`, { headers });

  assert.equal((await check('www.domainco.test')).status, 404, 'unpublished sites are not approved');
  await c.post(`/sites/${siteId}/publish`, { published: '1' });
  assert.equal((await check('www.domainco.test')).status, 200);
  assert.equal((await check('WWW.DomainCo.test')).status, 200, 'case-insensitive');
  assert.equal((await check('unknown.example')).status, 404);
  assert.equal((await check('not a host!')).status, 404);
  assert.equal((await check('')).status, 404);
  // requests that came through the public proxy carry X-Forwarded-For and are refused
  assert.equal((await check('www.domainco.test', { 'x-forwarded-for': '203.0.113.9' })).status, 404);
});

test('a site saved before \"Why Choose Us\" / contact.social existed still loads fine', async () => {
  const c = makeClient();
  await c.post('/signup', { email: 'oldsite@example.com', password: 'password1' });
  const create = await c.post('/sites', { name: 'Old Timer Co' });
  const editPath = create.headers.get('location');
  const siteId = editPath.match(/\/sites\/(\d+)\//)[1];
  await c.post(editPath, {
    name: 'Old Timer Co',
    hero_headline: 'Hello',
    about_heading: 'About', about_body: 'x',
    services_heading: 'Services',
    layout_order: 'hero,about,services,testimonials,whyChoose,gallery,faq,hours,contact'
  });

  // simulate a row written before this update: strip the new section/field
  // straight out of the stored JSON, the way an old site's row really looks
  const Database = require('better-sqlite3');
  const rawDb = new Database(TEST_DB);
  const row = rawDb.prepare('SELECT sections FROM sites WHERE id = ?').get(siteId);
  const oldSections = JSON.parse(row.sections);
  delete oldSections.whyChoose;
  delete oldSections.contact.social;
  delete oldSections.contact.acceptSubmissions;
  rawDb.prepare('UPDATE sites SET sections = ? WHERE id = ?').run(JSON.stringify(oldSections), siteId);
  rawDb.close();

  const editRes = await c.get(`/sites/${siteId}/edit`);
  assert.equal(editRes.status, 200);
  const editHtml = await editRes.text();
  assert.match(editHtml, /Why Choose Us/);

  await c.post(`/sites/${siteId}/publish`, { published: '1' });
  const live = await fetch(`${BASE}/site/old-timer-co`);
  assert.equal(live.status, 200);
});

test('unpublished and unknown slugs 404', async () => {
  const res1 = await fetch(`${BASE}/site/does-not-exist`);
  assert.equal(res1.status, 404);
});

test('a user cannot edit another user\'s site', async () => {
  const owner = makeClient();
  await owner.post('/signup', { email: 'dave@example.com', password: 'password1' });
  const create = await owner.post('/sites', { name: 'Dave Only' });
  const editPath = create.headers.get('location');
  const siteId = editPath.match(/\/sites\/(\d+)\//)[1];

  const intruder = makeClient();
  await intruder.post('/signup', { email: 'eve@example.com', password: 'password1' });
  const res = await intruder.get(`/sites/${siteId}/edit`);
  assert.equal(res.status, 404);
});

test('hidden sections are excluded from the public page', async () => {
  const c = makeClient();
  await c.post('/signup', { email: 'frank@example.com', password: 'password1' });
  const create = await c.post('/sites', { name: 'Frank Plumbing' });
  const editPath = create.headers.get('location');
  const siteId = editPath.match(/\/sites\/(\d+)\//)[1];

  await c.post(editPath, {
    name: 'Frank Plumbing',
    hero_headline: 'Frank Plumbing',
    about_heading: 'About',
    about_body: 'x',
    services_heading: 'Services',
    faq_heading: 'FAQ',
    faq_question: 'Do you visible?',
    faq_answer: 'Should be hidden',
    layout_order: 'hero,about,services,testimonials,gallery,faq,hours,contact',
    hidden_sections: 'faq'
  });
  await c.post(`/sites/${siteId}/publish`, { published: '1' });

  const live = await fetch(`${BASE}/site/frank-plumbing`);
  const html = await live.text();
  // the home page's nav doesn't link to a hidden section's page
  assert.doesNotMatch(html, /\/site\/frank-plumbing\/faq/);

  // and visiting that page directly 404s rather than showing its content
  const faqRes = await fetch(`${BASE}/site/frank-plumbing/faq`);
  assert.equal(faqRes.status, 404);
  assert.doesNotMatch(await faqRes.text(), /Should be hidden/);
});

test('version history: editing saves a version, and restore reverts content', async () => {
  const c = makeClient();
  await c.post('/signup', { email: 'grace@example.com', password: 'password1' });
  const create = await c.post('/sites', { name: 'Grace Design' });
  const editPath = create.headers.get('location');
  const siteId = editPath.match(/\/sites\/(\d+)\//)[1];

  await c.post(editPath, {
    name: 'Grace Design', hero_headline: 'First Headline', about_heading: 'About', about_body: 'x',
    services_heading: 'Services', layout_order: 'hero,about,services,testimonials,gallery,faq,hours,contact'
  });
  await c.post(editPath, {
    name: 'Grace Design', hero_headline: 'Second Headline', about_heading: 'About', about_body: 'x',
    services_heading: 'Services', layout_order: 'hero,about,services,testimonials,gallery,faq,hours,contact'
  });

  const editHtml = await (await c.get(editPath)).text();
  assert.match(editHtml, /Version history/);
  const versionIdMatch = editHtml.match(/\/versions\/(\d+)\/restore/);
  assert.ok(versionIdMatch, 'expected at least one restorable version');

  await c.post(`/sites/${siteId}/versions/${versionIdMatch[1]}/restore`);
  const afterRestore = await (await c.get(editPath)).text();
  assert.match(afterRestore, /value="First Headline"/);
});

test('modernize import pulls content from a live URL into a new site', async () => {
  const c = makeClient();
  await c.post('/signup', { email: 'henry@example.com', password: 'password1' });

  const res = await c.post('/sites/import', { url: `http://localhost:${OLD_SITE_PORT}/` });
  assert.equal(res.status, 302);
  const editPath = res.headers.get('location');
  assert.match(editPath, /imported=1/);

  const html = await (await c.get(editPath)).text();
  assert.match(html, /Old Biz - Original Headline/);
  assert.match(html, /Cleaning/);
  assert.match(html, /owner@oldbiz.example/);
});

test('refresh-from-source pulls updated content and keeps history', async () => {
  const c = makeClient();
  await c.post('/signup', { email: 'ivy@example.com', password: 'password1' });
  const importRes = await c.post('/sites/import', { url: `http://localhost:${OLD_SITE_PORT}/` });
  const editPath = importRes.headers.get('location').replace('?imported=1', '');
  const siteId = editPath.match(/\/sites\/(\d+)\//)[1];

  global.__setOldHeadline('Old Biz - Headline After Update');
  const refresh = await c.post(`/sites/${siteId}/refresh`);
  assert.equal(refresh.status, 302);

  const html = await (await c.get(editPath)).text();
  assert.match(html, /Headline After Update/);
});

test('import rejects a URL pointing at a private/internal address', async () => {
  const c = makeClient();
  await c.post('/signup', { email: 'jack@example.com', password: 'password1' });
  // bypass the ALLOW_PRIVATE_IMPORT_HOSTS escape hatch by hitting the
  // scraper's guard directly is covered in scraper.test.js; here we confirm
  // the route surfaces a friendly error rather than crashing on garbage input
  const res = await c.post('/sites/import', { url: 'not a url at all' });
  assert.equal(res.status, 200);
  const html = await res.text();
  assert.match(html, /could not import|could not reach|valid url/i);
});

test('generate a site from a business type matches a known template', async () => {
  const c = makeClient();
  await c.post('/signup', { email: 'karen@example.com', password: 'password1' });

  const res = await c.post('/sites/generate', { business_type: 'plumbing company', business_name: 'Karen\'s Plumbing' });
  assert.equal(res.status, 302);
  const editPath = res.headers.get('location');
  assert.match(editPath, /generated=1/);

  const html = await (await c.get(editPath)).text();
  assert.match(html, /Karen&#39;s Plumbing|Karen's Plumbing/);
  assert.match(html, /Drain Cleaning/); // a known plumbing-template service
});

test('generate falls back to a generic template for an unmatched business type', async () => {
  const c = makeClient();
  await c.post('/signup', { email: 'liam@example.com', password: 'password1' });

  const res = await c.post('/sites/generate', { business_type: 'artisanal llama grooming' });
  assert.equal(res.status, 302);
  const html = await (await c.get(res.headers.get('location'))).text();
  assert.match(html, /artisanal llama grooming/i);
});

test('generate requires a business type', async () => {
  const c = makeClient();
  await c.post('/signup', { email: 'mia@example.com', password: 'password1' });

  const res = await c.post('/sites/generate', { business_type: '' });
  assert.equal(res.status, 200);
  assert.match(await res.text(), /describe the type of business/i);
});

test('sitemap.xml only lists published sites', async () => {
  const res = await fetch(`${BASE}/sitemap.xml`);
  assert.equal(res.status, 200);
  const xml = await res.text();
  assert.match(xml, /carol-consulting/);
  assert.doesNotMatch(xml, /grace-design/); // never published in this suite
});

test('robots.txt is served', async () => {
  const res = await fetch(`${BASE}/robots.txt`);
  assert.equal(res.status, 200);
  assert.match(await res.text(), /User-agent/);
});

// ---- local SEO + conversion ----
async function makeLocalSite(c, email, extra = {}) {
  await c.post('/signup', { email, password: 'password1' });
  const create = await c.post('/sites', { name: extra.name || 'Orlando Roofing' });
  const editPath = create.headers.get('location');
  const siteId = editPath.match(/\/sites\/(\d+)\//)[1];
  await c.post(editPath, {
    name: extra.name || 'Orlando Roofing', hero_headline: 'Roofs done right', hero_subheadline: 'Local roofers',
    about_heading: 'About', about_body: 'We fix roofs.',
    services_heading: 'Services',
    service_title: ['Roof Repair', 'Roof Repair', 'Gutter Cleaning'],
    service_description: ['Fix leaks', 'Second copy', 'Clean gutters'],
    service_detail: ['Repairs usually start with finding the source of a leak.\n\nThen the damaged area is replaced.', '', ''],
    contact_heading: 'Contact', contact_phone: '(407) 555-0100', contact_acceptSubmissions: '1',
    meta_businessType: 'roofer', meta_city: 'Orlando, FL',
    meta_gaId: extra.gaId === undefined ? 'G-ABC123XYZ9' : extra.gaId,
    meta_metaPixelId: extra.pixel === undefined ? '123456789012345' : extra.pixel,
    seo_title: '', seo_description: '',
    layout_order: 'hero,about,services,testimonials,whyChoose,gallery,faq,hours,contact'
  });
  await c.post(`/sites/${siteId}/publish`, { published: '1' });
  return { siteId, editPath };
}

test('local SEO: city in titles/headings and one page per service', async () => {
  const c = makeClient();
  const { siteId } = await makeLocalSite(c, 'localseo@example.com', { name: 'Local Seo Roofing' });
  const slug = 'local-seo-roofing';

  const home = await (await fetch(`${BASE}/site/${slug}`)).text();
  assert.match(home, /<title>Local Seo Roofing — Roofer in Orlando, FL<\/title>/);
  assert.match(home, /hero-eyebrow" data-animate="fade-up">Roofer in Orlando, FL</);
  assert.match(home, /"addressLocality":"Orlando"/);
  assert.match(home, /"addressRegion":"FL"/);

  const services = await (await fetch(`${BASE}/site/${slug}/services`)).text();
  assert.match(services, /<title>Services in Orlando, FL — Local Seo Roofing<\/title>/);
  assert.match(services, new RegExp(`href="/site/${slug}/services/roof-repair"`));
  assert.match(services, new RegExp(`href="/site/${slug}/services/roof-repair-2"`), 'duplicate titles get unique slugs');
  assert.match(services, new RegExp(`href="/site/${slug}/services/gutter-cleaning"`));

  const about = await (await fetch(`${BASE}/site/${slug}/about`)).text();
  assert.match(about, /<title>About — Local Seo Roofing \| Orlando, FL<\/title>/);

  // a service with its own text: indexable, city in the heading, quote form preselected
  const page = await fetch(`${BASE}/site/${slug}/services/roof-repair`);
  assert.equal(page.status, 200);
  const html = await page.text();
  assert.match(html, /<h1>Roof Repair in Orlando, FL<\/h1>/);
  assert.match(html, /<title>Roof Repair in Orlando, FL — Local Seo Roofing<\/title>/);
  assert.match(html, /Repairs usually start with finding the source/);
  assert.match(html, /Then the damaged area is replaced/);
  assert.doesNotMatch(html, /noindex/);
  assert.match(html, /<option value="Roof Repair" selected>/);
  assert.match(html, /"@type":"Service"/);
  assert.match(html, new RegExp(`rel="canonical" href="[^"]*/site/${slug}/services/roof-repair"`));
  assert.match(html, /Other services/);

  // a service with no text of its own works but stays out of Google
  const thin = await (await fetch(`${BASE}/site/${slug}/services/gutter-cleaning`)).text();
  assert.match(thin, /<meta name="robots" content="noindex">/);

  assert.equal((await fetch(`${BASE}/site/${slug}/services/not-a-service`)).status, 404);

  const sitemap = await (await fetch(`${BASE}/sitemap.xml`)).text();
  assert.match(sitemap, new RegExp(`/site/${slug}/services/roof-repair<`));
  assert.doesNotMatch(sitemap, new RegExp(`/site/${slug}/services/gutter-cleaning<`));

  // the owner preview serves service pages too
  const prev = await c.get(`/sites/${siteId}/preview/services/roof-repair`);
  assert.equal(prev.status, 200);

  // unpublished sites do not serve service pages
  await c.post(`/sites/${siteId}/publish`, { published: '0' });
  assert.equal((await fetch(`${BASE}/site/${slug}/services/roof-repair`)).status, 404);
});

test('conversion: service dropdown, thank-you page, call bar and tracking IDs', async () => {
  const c = makeClient();
  const { siteId } = await makeLocalSite(c, 'convert@example.com', { name: 'Convert Roofing' });
  const slug = 'convert-roofing';

  const contact = await (await fetch(`${BASE}/site/${slug}/contact`)).text();
  assert.match(contact, /<select name="service">/);
  assert.match(contact, /<option value="Gutter Cleaning"/);
  assert.match(contact, /Request a quote/);

  // sticky call bar (phones) + tracking snippets on the live site
  const home = await (await fetch(`${BASE}/site/${slug}`)).text();
  assert.match(home, /class="mobile-bar"/);
  assert.match(home, /class="mb-call" href="tel:\+?4075550100"/);
  assert.match(home, /googletagmanager\.com\/gtag\/js\?id=/);
  assert.match(home, /"G-ABC123XYZ9"/);
  assert.match(home, /PX = "123456789012345", MODE = "ask"/, 'default: tracking waits for consent');
  assert.match(home, /id="cookieBar"/);
  const preview = await (await c.get(`/sites/${siteId}/preview`)).text();
  assert.doesNotMatch(preview, /googletagmanager|fbq\('init'/, 'no tracking in the owner preview');

  // submit with a listed service, and with a made-up one
  const f1 = new FormData();
  f1.append('name', 'Pat Roofer'); f1.append('phone', '555-2222'); f1.append('service', 'Gutter Cleaning');
  const r1 = await fetch(`${BASE}/site/${slug}/contact`, { method: 'POST', body: f1, redirect: 'manual' });
  assert.equal(r1.headers.get('location'), `/site/${slug}/thank-you`);
  const f2 = new FormData();
  f2.append('name', 'Sam Faker'); f2.append('phone', '555-3333'); f2.append('service', '<script>x</script>');
  await fetch(`${BASE}/site/${slug}/contact`, { method: 'POST', body: f2, redirect: 'manual' });
  const leads = await (await c.get(`/sites/${siteId}/leads`)).text();
  assert.match(leads, /Pat Roofer/);
  assert.match(leads, />Gutter Cleaning</);
  assert.match(leads, /Sam Faker/);
  assert.doesNotMatch(leads, /&lt;script&gt;x/, 'unknown services are dropped, not stored');

  // submitting from a service page uses the same endpoint
  const svcPage = await (await fetch(`${BASE}/site/${slug}/services/roof-repair`)).text();
  assert.match(svcPage, new RegExp(`<form method="POST" action="/site/${slug}/contact"`));

  const thanks = await (await fetch(`${BASE}/site/${slug}/thank-you`)).text();
  assert.match(thanks, /Thank you!/);
  assert.match(thanks, /fbq\('track', 'Lead'\)/);
  assert.match(thanks, /generate_lead/);
  assert.doesNotMatch(thanks, /Ready to get started/);

  // invalid tracking IDs are dropped on save
  const { editPath } = await makeLocalSite(makeClient(), 'convert2@example.com', { name: 'Bad Ids Co', gaId: '"><script>', pixel: 'abc' });
  const bad = await (await fetch(`${BASE}/site/bad-ids-co`)).text();
  assert.doesNotMatch(bad, /googletagmanager|fbq\('init'/);
  assert.ok(editPath);
});

test('service pages work on a custom domain and in the static export; client edits keep service text', async () => {
  const c = makeClient();
  const { siteId, editPath } = await makeLocalSite(c, 'svcdomain@example.com', { name: 'Svc Domain Co' });
  const http = require('node:http');
  const getWithHost = (host, urlPath) => new Promise((resolve, reject) => {
    http.get({ host: '127.0.0.1', port: new URL(BASE).port, path: urlPath, headers: { Host: host } }, (res) => {
      let data = ''; res.on('data', d => data += d); res.on('end', () => resolve({ status: res.statusCode, body: data }));
    }).on('error', reject);
  });
  await c.post(editPath, {
    name: 'Svc Domain Co', custom_domain: 'www.svcdomain.test', hero_headline: 'Hi', about_heading: 'About', about_body: 'x',
    services_heading: 'Services', service_title: ['Roof Repair'], service_description: ['Fix leaks'],
    service_detail: ['Detail text that should survive a client edit.'], contact_heading: 'Contact', meta_city: 'Orlando, FL',
    layout_order: 'hero,about,services,testimonials,whyChoose,gallery,faq,hours,contact'
  });
  const dom = await getWithHost('www.svcdomain.test', '/services/roof-repair');
  assert.equal(dom.status, 200);
  assert.match(dom.body, /Roof Repair in Orlando, FL/);
  assert.match(dom.body, /href="\/services\/roof-repair"|href="\/services"/);
  assert.equal((await getWithHost('www.svcdomain.test', '/services/nope')).status, 404);
  assert.equal((await getWithHost('www.svcdomain.test', '/thank-you')).status, 200);

  // static export: one file per service that has text, links rewritten
  const zip = readZip(Buffer.from(await (await c.get(`/sites/${siteId}/export`)).arrayBuffer()));
  assert.ok(zip['service-roof-repair.html'], 'service page file is included');
  assert.match(zip['services.html'].toString(), /href="service-roof-repair\.html"/);
  assert.doesNotMatch(zip['service-roof-repair.html'].toString(), /<form/);

  // a client editing the services list through their link must not wipe the service text
  const made = await c.post(`/sites/${siteId}/client-link`);
  const shown = await (await c.get(made.headers.get('location'))).text();
  const token = shown.match(/\/client\/([A-Za-z0-9_-]{32})</)[1];
  await fetch(`${BASE}/client/${token}`, {
    method: 'POST', redirect: 'manual', headers: { 'content-type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams([['services_present', '1'], ['service_title', 'Roof Repair'], ['service_description', 'Fix leaks fast']]).toString()
  });
  const after = await getWithHost('www.svcdomain.test', '/services/roof-repair');
  assert.match(after.body, /Detail text that should survive a client edit/);
  assert.match(after.body, /Fix leaks fast/);
});

// ---- round 4: leads follow-up, reviews, reports, more page types ----
const FORM = (o) => new URLSearchParams(o).toString();
const mailCount = () => (fs.existsSync(MAIL_FILE) ? fs.readFileSync(MAIL_FILE, 'utf8').split('\n').filter(Boolean).length : 0);
async function basicSite(c, email, name, extra = {}) {
  await c.post('/signup', { email, password: 'password1' });
  const create = await c.post('/sites', { name });
  const editPath = create.headers.get('location');
  const siteId = editPath.match(/\/sites\/(\d+)\//)[1];
  await c.post(editPath, {
    name, hero_headline: 'Hello', about_heading: 'About', about_body: 'About us text',
    services_heading: 'Services', service_title: ['Roof Repair'], service_description: ['Fix leaks'], service_detail: [''],
    contact_heading: 'Contact', contact_email: 'owner@biz.test', contact_phone: '555-0100', contact_acceptSubmissions: '1',
    meta_city: 'Orlando, FL', meta_businessType: 'roofer', testimonials_heading: 'Reviews',
    layout_order: 'hero,about,services,testimonials,whyChoose,gallery,faq,blog,extraPages,hours,contact',
    ...extra
  });
  await c.post(`/sites/${siteId}/publish`, { published: '1' });
  return { siteId, editPath, slug: name.toLowerCase().replace(/[^a-z0-9]+/g, '-') };
}

test('leads: statuses, notes, filter, CSV (formula-safe), and the optional visitor auto-reply', async () => {
  const c = makeClient();
  const { siteId, slug } = await basicSite(c, 'leadflow@example.com', 'Leadflow Co', { contact_autoReply: '1', contact_autoReplyText: 'Got it, thanks!' });
  const before = mailCount();
  const f = new FormData();
  f.append('name', '=HYPERLINK("http://evil")'); f.append('email', 'visitor@example.com'); f.append('phone', '555-7777'); f.append('message', 'hi');
  await fetch(`${BASE}/site/${slug}/contact`, { method: 'POST', body: f, redirect: 'manual' });
  const mails = await waitForMail(before + 2);
  const sent = mails.slice(before);
  assert.ok(sent.some(m => m.to[0].address === 'visitor@example.com' && /Got it, thanks!/.test(m.text)), 'visitor gets the auto-reply');
  assert.ok(sent.some(m => m.to[0].address === 'owner@biz.test'), 'owner still gets the alert');

  let html = await (await c.get(`/sites/${siteId}/leads`)).text();
  assert.match(html, /New \(1\)/);
  const leadId = html.match(/id="lead-(\d+)"/)[1];
  const upd = await c.post(`/sites/${siteId}/leads/${leadId}`, { status: 'won', notes: 'quoted 4200', filter: 'all' });
  assert.equal(upd.status, 302);
  html = await (await c.get(`/sites/${siteId}/leads`)).text();
  assert.match(html, /Won \(1\)/);
  assert.match(html, /value="quoted 4200"/);
  assert.doesNotMatch(await (await c.get(`/sites/${siteId}/leads?status=new`)).text(), /id="lead-/);
  assert.equal((await c.post(`/sites/${siteId}/leads/${leadId}`, { status: 'bogus' })).status, 400);

  const csv = await c.get(`/sites/${siteId}/leads.csv`);
  assert.match(csv.headers.get('content-type'), /csv/);
  const csvText = await csv.text();
  assert.match(csvText, /"Date","Name","Email","Phone","Service","Message","Answers","Status","Follow up","Source","Notes"/);
  assert.match(csvText, /"'=HYPERLINK/, 'formula-looking cells are defused');
  assert.match(csvText, /"won","","form","quoted 4200"/);

  const other = makeClient();
  await other.post('/signup', { email: 'leadflow-other@example.com', password: 'password1' });
  assert.equal((await other.post(`/sites/${siteId}/leads/${leadId}`, { status: 'lost' })).status, 404);
  assert.equal((await other.get(`/sites/${siteId}/leads.csv`)).status, 404);
});

test('reviews: public form, approval queue, publishing, email request', async () => {
  const c = makeClient();
  const { siteId, slug } = await basicSite(c, 'reviewer@example.com', 'Review Roofing', { trust_googleReviewsUrl: 'https://g.page/r/abc' });
  const page = await (await fetch(`${BASE}/site/${slug}/review`)).text();
  assert.match(page, /name="quote"/);
  assert.match(page, /noindex/);
  assert.doesNotMatch(await (await fetch(`${BASE}/site/${slug}`)).text(), /Review Roofing — .*reviews/i);

  const post = (body) => fetch(`${BASE}/site/${slug}/review`, { method: 'POST', redirect: 'manual', headers: { 'content-type': 'application/x-www-form-urlencoded' }, body: FORM(body) });
  const ok = await post({ name: 'Dana K.', rating: '5', quote: 'They fixed our roof in a day and cleaned up.' });
  assert.equal(ok.headers.get('location'), `/site/${slug}/review?thanks=1`);
  assert.match(ok.headers.get('location'), /thanks=1/);
  assert.match(await (await fetch(`${BASE}/site/${slug}/review?thanks=1`)).text(), /Review us on Google/);
  assert.match((await post({ name: 'x', rating: '9', quote: 'long enough text here' })).headers.get('location'), /error=1/);
  assert.match((await post({ name: 'x', rating: '4', quote: 'short' })).headers.get('location'), /error=1/);
  await post({ name: 'Bot', rating: '5', quote: 'spam spam spam spam', website: 'http://spam' }); // honeypot

  // nothing is public until approved
  assert.equal((await fetch(`${BASE}/site/${slug}/testimonials`)).status, 404);
  let html = await (await c.get(`/sites/${siteId}/reviews`)).text();
  assert.match(html, /fixed our roof in a day/);
  assert.doesNotMatch(html, /spam spam/);
  assert.match(await (await c.get(`/sites/${siteId}/edit`)).text(), /Reviews \(1 new\)/);
  const rid = html.match(/\/reviews\/(\d+)"/)[1];

  const other = makeClient();
  await other.post('/signup', { email: 'reviewer-other@example.com', password: 'password1' });
  assert.equal((await other.post(`/sites/${siteId}/reviews/${rid}`, { action: 'approve' })).status, 404);

  assert.match((await c.post(`/sites/${siteId}/reviews/${rid}`, { action: 'approve' })).headers.get('location'), /m=approved/);
  const live = await (await fetch(`${BASE}/site/${slug}/testimonials`)).text();
  assert.match(live, /fixed our roof in a day/);
  assert.match(live, /Dana K\./);
  assert.match(await (await c.get(`/sites/${siteId}/edit`)).text(), /fixed our roof in a day/, 'it is also in the editor so a later save keeps it');
  // approving twice does nothing
  await c.post(`/sites/${siteId}/reviews/${rid}`, { action: 'approve' });
  assert.equal((await (await fetch(`${BASE}/site/${slug}/testimonials`)).text()).split('fixed our roof in a day').length, 2);

  await post({ name: 'Lee', rating: '2', quote: 'Not happy with the scheduling at all.' });
  html = await (await c.get(`/sites/${siteId}/reviews`)).text();
  const rid2 = html.match(/\/reviews\/(\d+)"/)[1];
  await c.post(`/sites/${siteId}/reviews/${rid2}`, { action: 'reject' });
  assert.doesNotMatch(await (await fetch(`${BASE}/site/${slug}/testimonials`)).text(), /Not happy with the scheduling/);

  // owner emails a request
  const before = mailCount();
  assert.match((await c.post(`/sites/${siteId}/reviews/request`, { email: 'customer@example.com', name: 'Pat' })).headers.get('location'), /m=sent/);
  const mails = await waitForMail(before + 1);
  const m = mails[mails.length - 1];
  assert.equal(m.to[0].address, 'customer@example.com');
  assert.match(m.text, new RegExp(`/site/${slug}/review`));
  assert.match((await c.post(`/sites/${siteId}/reviews/request`, { email: 'nope' })).headers.get('location'), /m=bademail/);
});

test('reports: cookie-free page views (no bots, no preview), report page, client-link report', async () => {
  const c = makeClient();
  const { siteId, slug } = await basicSite(c, 'reporter@example.com', 'Report Roofing');
  const human = { 'user-agent': 'Mozilla/5.0 (iPhone) Safari' };
  await fetch(`${BASE}/site/${slug}`, { headers: human });
  await fetch(`${BASE}/site/${slug}`, { headers: human });
  await fetch(`${BASE}/site/${slug}/about`, { headers: human });
  await fetch(`${BASE}/site/${slug}`, { headers: { 'user-agent': 'Googlebot/2.1' } });
  await c.get(`/sites/${siteId}/preview`, { headers: human });
  const f = new FormData(); f.append('name', 'Quote Person'); f.append('phone', '555-1'); f.append('service', 'Roof Repair');
  await fetch(`${BASE}/site/${slug}/contact`, { method: 'POST', body: f, redirect: 'manual' });

  const html = await (await c.get(`/sites/${siteId}/report`)).text();
  assert.match(html, /<div class="n">3<\/div><div class="l">Page views<\/div>/);
  assert.match(html, /<div class="n">1<\/div><div class="l">Messages &amp; quote requests/);
  assert.match(html, /Roof Repair/);
  assert.match(html, /Most viewed pages/);
  assert.match(await (await c.get(`/sites/${siteId}/report?days=7`)).text(), /last 7 days/);

  const other = makeClient();
  await other.post('/signup', { email: 'reporter-other@example.com', password: 'password1' });
  assert.equal((await other.get(`/sites/${siteId}/report`)).status, 404);
  assert.equal((await fetch(`${BASE}/sites/${siteId}/report`, { redirect: 'manual' })).status, 302);

  const made = await c.post(`/sites/${siteId}/client-link`);
  const token = (await (await c.get(made.headers.get('location'))).text()).match(/\/client\/([A-Za-z0-9_-]{32})</)[1];
  const clientReport = await fetch(`${BASE}/client/${token}/report`);
  assert.equal(clientReport.status, 200);
  assert.match(clientReport.headers.get('x-robots-tag'), /noindex/);
  assert.match(await clientReport.text(), /Page views/);
  assert.match(await (await fetch(`${BASE}/client/${token}`)).text(), /See how your website is doing/);
  assert.equal((await fetch(`${BASE}/client/${'z'.repeat(32)}/report`)).status, 404);

  // email the report
  await c.post(`/sites/${siteId}/edit`, { name: 'Report Roofing', meta_reportEmail: 'owner@biz.test', contact_heading: 'Contact', about_heading: 'About', services_heading: 'Services', hero_headline: 'Hello' });
  const before = mailCount();
  assert.match((await c.post(`/sites/${siteId}/report/send`, { days: '30' })).headers.get('location'), /m=sent/);
  const mails = await waitForMail(before + 1);
  assert.match(mails[mails.length - 1].text, /Page views:\s+3/);
});

test('reports module: date helpers and aggregation', () => {
  const reports = require('../reports');
  const prev = reports.previousMonth(new Date(Date.UTC(2026, 0, 15)));
  assert.equal(prev.from, '2025-12-01');
  assert.equal(prev.to, '2025-12-31');
  assert.equal(prev.period, '2025-12');
  assert.deepEqual(reports.rangeForDays(3, new Date(Date.UTC(2026, 2, 10))), { from: '2026-03-08', to: '2026-03-10' });
  assert.equal(reports.isBot('Mozilla/5.0 (compatible; bingbot/2.0)'), true);
  assert.equal(reports.isBot(''), true);
  assert.equal(reports.isBot('Mozilla/5.0 (Windows NT 10.0) Chrome/120'), false);
});

test('more pages: town pages, blog posts and extra pages (financing etc.)', async () => {
  const c = makeClient();
  const { siteId, slug, editPath } = await basicSite(c, 'pages@example.com', 'Pages Roofing');
  await c.post(editPath, {
    name: 'Pages Roofing', hero_headline: 'Hello', about_heading: 'About', about_body: 'x', services_heading: 'Services',
    service_title: ['Roof Repair'], service_description: ['Fix'], service_detail: [''],
    contact_heading: 'Contact', contact_acceptSubmissions: '1', contact_phone: '555-0100', meta_city: 'Orlando, FL', meta_businessType: 'roofer',
    trust_serviceAreas: 'Kissimmee, St. Cloud',
    area_name: ['Kissimmee', 'St. Cloud'], area_text: ['We know the HOA rules in Kissimmee neighborhoods.', ''],
    blog_heading: 'News & Tips', blog_title: ['How to spot roof damage'], blog_date: ['March 3, 2026'], blog_body: ['First paragraph.\n\nSecond paragraph.'],
    extraPages_heading: 'Extra pages', extra_title: ['Financing'], extra_body: ['We can talk through payment options.'],
    testimonials_heading: 'Reviews',
    layout_order: 'hero,about,services,testimonials,whyChoose,gallery,faq,blog,extraPages,hours,contact'
  });

  const get = (p, h) => fetch(`${BASE}/site/${slug}${p}`, h ? { headers: h } : undefined);
  // town page with text: indexable, city/town in heading, quote form
  const k = await (await get('/areas/kissimmee')).text();
  assert.match(k, /<h1>Roofer in Kissimmee<\/h1>/);
  assert.match(k, /HOA rules in Kissimmee/);
  assert.doesNotMatch(k, /noindex/);
  assert.match(k, /<title>Roofer in Kissimmee — Pages Roofing<\/title>/);
  assert.match(k, /<select name="service">/);
  // town without text: works but noindex
  const sc = await (await get('/areas/st-cloud')).text();
  assert.match(sc, /Pages Roofing serves St\. Cloud\./);
  assert.match(sc, /<meta name="robots" content="noindex">/);
  assert.equal((await get('/areas/nowhere')).status, 404);
  // About page links only the town that has text
  const about = await (await get('/about')).text();
  assert.match(about, new RegExp(`<a class="area-chip" href="/site/${slug}/areas/kissimmee">Kissimmee</a>`));
  assert.match(about, /<span class="area-chip">St\. Cloud<\/span>/);

  // blog
  const blog = await (await get('/blog')).text();
  assert.match(blog, /How to spot roof damage/);
  assert.match(blog, new RegExp(`href="/site/${slug}/blog/how-to-spot-roof-damage"`));
  const post = await (await get('/blog/how-to-spot-roof-damage')).text();
  assert.match(post, /<h1>How to spot roof damage<\/h1>/);
  assert.match(post, /<p>First paragraph\.<\/p>/);
  assert.match(post, /<p>Second paragraph\.<\/p>/);
  assert.match(post, /"@type":"BlogPosting"/);
  assert.match(post, /"datePublished":"2026-03-0\d"/);
  assert.equal((await get('/blog/nope')).status, 404);

  // extra page: its own address and a nav link
  const fin = await get('/p/financing');
  assert.equal(fin.status, 200);
  assert.match(await fin.text(), /payment options/);
  const home = await (await get('')).text();
  assert.match(home, new RegExp(`href="/site/${slug}/p/financing"[^>]*>Financing<`));
  assert.match(home, new RegExp(`href="/site/${slug}/blog"`));
  assert.equal((await get('/p/nope')).status, 404);
  assert.equal((await get('/extraPages')).status, 404, 'the editor block itself is not a page');
  assert.equal((await get('/bogus/x')).status, 404);

  // sitemap lists what has real text
  const sitemap = await (await fetch(`${BASE}/sitemap.xml`)).text();
  assert.match(sitemap, new RegExp(`/site/${slug}/areas/kissimmee<`));
  assert.doesNotMatch(sitemap, new RegExp(`/site/${slug}/areas/st-cloud<`));
  assert.match(sitemap, new RegExp(`/site/${slug}/blog/how-to-spot-roof-damage<`));
  assert.match(sitemap, new RegExp(`/site/${slug}/p/financing<`));

  // static export has a file for each, with links rewritten
  const zip = readZip(Buffer.from(await (await c.get(`/sites/${siteId}/export`)).arrayBuffer()));
  assert.ok(zip['area-kissimmee.html'] && zip['blog-how-to-spot-roof-damage.html'] && zip['p-financing.html'] && zip['blog.html']);
  assert.ok(!zip['area-st-cloud.html'], 'no file for a town without text');
  assert.match(zip['blog.html'].toString(), /href="blog-how-to-spot-roof-damage\.html"/);
  assert.match(zip['index.html'].toString(), /href="p-financing\.html"/);

  // hiding the extra-pages block removes those pages
  await c.post(editPath, {
    name: 'Pages Roofing', hero_headline: 'Hello', about_heading: 'About', about_body: 'x', services_heading: 'Services',
    contact_heading: 'Contact', extra_title: ['Financing'], extra_body: ['We can talk through payment options.'], hidden_sections: ['extraPages'],
    layout_order: 'hero,about,services,testimonials,whyChoose,gallery,faq,blog,extraPages,hours,contact'
  });
  assert.equal((await get('/p/financing')).status, 404);

  // custom domain serves them at clean addresses
  await c.post(editPath, {
    name: 'Pages Roofing', custom_domain: 'www.pagesroof.test', hero_headline: 'Hello', about_heading: 'About', about_body: 'x', services_heading: 'Services',
    contact_heading: 'Contact', meta_city: 'Orlando, FL', trust_serviceAreas: 'Kissimmee', area_name: ['Kissimmee'], area_text: ['Local text here.'],
    blog_title: ['Post one'], blog_body: ['Body one.'], layout_order: 'hero,about,services,testimonials,whyChoose,gallery,faq,blog,extraPages,hours,contact'
  });
  const http = require('node:http');
  const viaHost = (p) => new Promise((resolve, reject) => {
    http.get({ host: '127.0.0.1', port: new URL(BASE).port, path: p, headers: { Host: 'www.pagesroof.test' } }, (res) => {
      let d = ''; res.on('data', x => d += x); res.on('end', () => resolve({ status: res.statusCode, body: d }));
    }).on('error', reject);
  });
  assert.equal((await viaHost('/areas/kissimmee')).status, 200);
  assert.equal((await viaHost('/blog/post-one')).status, 200);
  assert.equal((await viaHost('/blog')).status, 200);
  assert.equal((await viaHost('/review')).status, 200);
  assert.equal((await viaHost('/areas/zzz')).status, 404);
});

test('round 5: cookie banner modes, legal note, gzip, upload caching', async () => {
  const c = makeClient();
  const { siteId, editPath } = await makeLocalSite(c, 'round5@example.com', { name: 'Round Five Roofing' });
  const slug = 'round-five-roofing';
  const base = {
    name: 'Round Five Roofing', hero_headline: 'Roofs', about_heading: 'About', about_body: 'x', services_heading: 'Services',
    contact_heading: 'Contact', meta_gaId: 'G-ABC123XYZ9', meta_city: 'Orlando, FL',
    layout_order: 'hero,about,services,testimonials,whyChoose,gallery,faq,blog,extraPages,hours,contact'
  };

  // always-on mode: no banner, tracking not gated
  await c.post(editPath, { ...base, meta_trackingMode: 'always' });
  let home = await (await fetch(`${BASE}/site/${slug}`)).text();
  assert.match(home, /MODE = "always"/);
  assert.doesNotMatch(home, /id="cookieBar"/);

  // ask mode with a legal note in the footer
  await c.post(editPath, { ...base, meta_trackingMode: 'ask', trust_legalNote: 'Licensed in Florida. Lic. #TEST-123' });
  home = await (await fetch(`${BASE}/site/${slug}`)).text();
  assert.match(home, /MODE = "ask"/);
  assert.match(home, /id="cookieBar"/);
  assert.match(home, /class="footer-legal">Licensed in Florida\. Lic\. #TEST-123</);

  // an invalid mode falls back to ask
  await c.post(editPath, { ...base, meta_trackingMode: 'nonsense' });
  assert.match(await (await fetch(`${BASE}/site/${slug}`)).text(), /MODE = "ask"/);

  // gzip: smaller on the wire, identical once decoded
  const zlib = require('node:zlib');
  const raw = await new Promise((resolve, reject) => {
    http.get({ host: '127.0.0.1', port: PORT, path: `/site/${slug}`, headers: { 'Accept-Encoding': 'gzip' } }, (res) => {
      const chunks = []; res.on('data', d => chunks.push(d));
      res.on('end', () => resolve({ headers: res.headers, body: Buffer.concat(chunks) }));
    }).on('error', reject);
  });
  assert.equal(raw.headers['content-encoding'], 'gzip');
  const plain = zlib.gunzipSync(raw.body).toString();
  assert.match(plain, /<main id="main">/);
  assert.ok(raw.body.length < plain.length / 2, 'gzip should shrink the page a lot');

  // uploads are cached for a long time
  fs.writeFileSync(path.join(__dirname, '..', 'public', 'uploads', 'cache-test.txt'), 'hi');
  const up = await fetch(`${BASE}/uploads/cache-test.txt`);
  assert.match(up.headers.get('cache-control') || '', /max-age=\d{6,}/);
  fs.unlinkSync(path.join(__dirname, '..', 'public', 'uploads', 'cache-test.txt'));
});

test('create-site script builds a site from examples/sankara.json', async () => {
  const { execFileSync } = require('node:child_process');
  const c = makeClient();
  await c.post('/signup', { email: 'script@example.com', password: 'password1' });
  const out = execFileSync(process.execPath, [path.join(__dirname, '..', 'scripts', 'create-site.js'), path.join(__dirname, '..', 'examples', 'sankara.json'), 'script@example.com'],
    { env: { ...process.env, DB_PATH: TEST_DB }, encoding: 'utf8' });
  const id = out.match(/\/sites\/(\d+)\/edit/)[1];
  const edit = await c.get(`/sites/${id}/edit`);
  assert.equal(edit.status, 200);
  const page = await (await c.get(`/sites/${id}/preview/services/auto-insurance`)).text();
  assert.match(page, /Auto Insurance in\s+Kissimmee, FL/);
  assert.doesNotMatch(page, /licensed|lowest|guarantee|best rates/i, 'starter copy makes no unverifiable claims');
});

test('billing: checkout link, webhook activates, lapsed subscriptions take the site offline', async () => {
  const billing = require('../billing');
  const Database = require('better-sqlite3');
  const c = makeClient();
  const { siteId } = await makeLocalSite(c, 'billing@example.com', { name: 'Billing Roofing' });
  const slug = 'billing-roofing';
  const live = async () => (await fetch(`${BASE}/site/${slug}`)).status;
  const hook = (event, sig) => {
    const raw = JSON.stringify(event);
    return fetch(`${BASE}/stripe/webhook`, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Stripe-Signature': sig || billing.signForTest(raw, STRIPE_WHSEC) }, body: raw });
  };

  // private to the owner
  assert.equal((await fetch(`${BASE}/sites/${siteId}/billing`, { redirect: 'manual' })).status, 302);
  const other = makeClient();
  await other.post('/signup', { email: 'billing-other@example.com', password: 'password1' });
  assert.equal((await other.get(`/sites/${siteId}/billing`)).status, 404);
  const page = await (await c.get(`/sites/${siteId}/billing`)).text();
  assert.match(page, /Not started/);
  assert.match(page, /Start the hosting subscription/);

  // not required by default: site is live with no subscription
  assert.equal(await live(), 200);

  // checkout link goes to Stripe with the site tagged on it
  const co = await c.post(`/sites/${siteId}/billing/checkout`, { billing_email: 'client@example.com' });
  assert.equal(co.status, 200);
  assert.match(await co.text(), /https:\/\/checkout\.stripe\.test\/c\/pay_abc/);
  const sent = stripeRequests.find(r => r.url === '/v1/checkout/sessions');
  assert.equal(sent.auth, 'Bearer sk_test_fake');
  assert.equal(sent.params.get('mode'), 'subscription');
  assert.equal(sent.params.get('line_items[0][price]'), 'price_test_123');
  assert.equal(sent.params.get('client_reference_id'), String(siteId));
  assert.equal(sent.params.get('customer_email'), 'client@example.com');

  // require a subscription: offline until paid
  await c.post(`/sites/${siteId}/billing/settings`, { billing_required: '1', billing_email: 'client@example.com' });
  assert.equal(await live(), 503);
  assert.match(await (await fetch(`${BASE}/site/${slug}`)).text(), /temporarily unavailable/);
  assert.equal((await fetch(`${BASE}/site/${slug}/contact`, { method: 'POST', body: new FormData() })).status, 503);
  assert.equal((await c.get(`/sites/${siteId}/preview`)).status, 200, 'owner preview still works');

  // bad or missing signatures are rejected, and change nothing
  const evt = { type: 'checkout.session.completed', data: { object: { mode: 'subscription', client_reference_id: String(siteId), customer: 'cus_1', subscription: 'sub_1', payment_status: 'paid' } } };
  assert.equal((await hook(evt, 't=1,v1=deadbeef')).status, 400);
  assert.equal((await fetch(`${BASE}/stripe/webhook`, { method: 'POST', body: JSON.stringify(evt) })).status, 400);
  assert.equal(await live(), 503);

  // a signed payment event brings it live
  assert.equal((await hook(evt)).status, 200);
  assert.equal(await live(), 200);
  assert.match(await (await c.get(`/sites/${siteId}/billing`)).text(), /Active/);

  // manage subscription -> Stripe portal
  const portal = await c.post(`/sites/${siteId}/billing/portal`, {});
  assert.equal(portal.status, 302);
  assert.equal(portal.headers.get('location'), 'https://billing.stripe.test/p/session_xyz');
  assert.equal(stripeRequests.filter(r => r.url === '/v1/billing_portal/sessions').pop().params.get('customer'), 'cus_1');

  // failed payment: still live during the grace period, offline after it
  assert.equal((await hook({ type: 'invoice.payment_failed', data: { object: { subscription: 'sub_1', customer: 'cus_1' } } })).status, 200);
  assert.equal(await live(), 200);
  const dbh = new Database(TEST_DB);
  dbh.prepare("UPDATE sites SET past_due_since = datetime('now', '-8 days') WHERE id = ?").run(siteId);
  assert.equal(await live(), 503);
  // paying the invoice restores it
  await hook({ type: 'invoice.paid', data: { object: { subscription: 'sub_1', customer: 'cus_1' } } });
  assert.equal(await live(), 200);
  assert.equal(dbh.prepare('SELECT past_due_since FROM sites WHERE id = ?').get(siteId).past_due_since, null);

  // cancelling takes it offline; turning the requirement off puts it back
  await hook({ type: 'customer.subscription.deleted', data: { object: { id: 'sub_1', customer: 'cus_1' } } });
  assert.equal(await live(), 503);
  assert.equal(dbh.prepare('SELECT billing_status FROM sites WHERE id = ?').get(siteId).billing_status, 'canceled');
  await c.post(`/sites/${siteId}/billing/settings`, { billing_email: 'client@example.com' });
  assert.equal(await live(), 200);
  dbh.close();
});

test('billing: signature check is strict about the secret, age and body', () => {
  const billing = require('../billing');
  const body = '{"a":1}';
  const now = Date.now();
  const good = billing.signForTest(body, 'whsec_x', Math.floor(now / 1000));
  assert.equal(billing.verifyWebhook(body, good, 'whsec_x', now), true);
  assert.equal(billing.verifyWebhook(body + ' ', good, 'whsec_x', now), false, 'body changed');
  assert.equal(billing.verifyWebhook(body, good, 'whsec_y', now), false, 'wrong secret');
  assert.equal(billing.verifyWebhook(body, good, 'whsec_x', now + 10 * 60 * 1000), false, 'too old');
  assert.equal(billing.isSuspended({ billing_required: 0, billing_status: 'canceled' }), false);
  assert.equal(billing.isSuspended({ billing_required: 1, billing_status: 'none' }), true);
  assert.equal(billing.isSuspended({ billing_required: 1, billing_status: 'trialing' }), false);
});

test('new theme styles render and unknown styles fall back to modern', async () => {
  const c = makeClient();
  const { siteId, editPath } = await makeLocalSite(c, 'styles@example.com', { name: 'Styles Roofing' });
  const base = { name: 'Styles Roofing', hero_headline: 'Roofs', about_heading: 'About', about_body: 'x', services_heading: 'Services', contact_heading: 'Contact', layout_order: 'hero,about,services,testimonials,whyChoose,gallery,faq,blog,extraPages,hours,contact' };
  for (const st of ['midnight', 'split', 'poster']) {
    await c.post(editPath, { ...base, theme_style: st });
    const html = await (await fetch(`${BASE}/site/styles-roofing`)).text();
    assert.match(html, new RegExp(`<body class="style-${st}`));
  }
  await c.post(editPath, { ...base, theme_style: 'neon' });
  assert.match(await (await fetch(`${BASE}/site/styles-roofing`)).text(), /<body class="style-modern/);
  assert.match(await (await c.get(editPath)).text(), /value="midnight"/);
});

test('custom fonts: heading/body overrides load from Google, single-weight display fonts, safe input', async () => {
  const c = makeClient();
  const { editPath } = await makeLocalSite(c, 'fonts@example.com', { name: 'Ink Tattoo' });
  const slug = 'ink-tattoo';
  const base = { name: 'Ink Tattoo', hero_headline: 'Ink', about_heading: 'About', about_body: 'x', services_heading: 'Services', contact_heading: 'Contact', layout_order: 'hero,about,services,testimonials,whyChoose,gallery,faq,blog,extraPages,hours,contact' };

  // default: no overrides, no extra families
  let html = await (await fetch(`${BASE}/site/${slug}`)).text();
  assert.doesNotMatch(html, /Pirata/);

  // eccentric heading font + readable body font + normal capitalization
  await c.post(editPath, { ...base, theme_headingFont: 'Pirata One', theme_bodyFont: 'Lora', theme_headingCase: 'none' });
  html = await (await fetch(`${BASE}/site/${slug}`)).text();
  assert.match(html, /family=Pirata\+One&amp;family=Lora:wght@400;500;600;700|family=Pirata\+One&family=Lora:wght@400;500;600;700/);
  assert.match(html, /--heading-font: 'Pirata One', Georgia, serif/);
  assert.match(html, /--body-font: 'Lora', system-ui, sans-serif/);
  assert.match(html, /h1, h2, h3, nav\.site-nav \.brand \{ text-transform: none !important/);
  assert.match(html, /font-weight: 400 !important/, 'single-weight display font is not faux-bolded');

  // any other Google Font by name works, and the editor shows it back
  await c.post(editPath, { ...base, theme_headingFont: 'Pirata One', theme_headingFontCustom: 'Fascinate Inline', theme_headingCase: 'uppercase' });
  html = await (await fetch(`${BASE}/site/${slug}`)).text();
  assert.match(html, /family=Fascinate\+Inline/);
  assert.match(html, /--heading-font: 'Fascinate Inline'/);
  assert.match(html, /text-transform: uppercase !important/);
  assert.match(await (await c.get(editPath)).text(), /name="theme_headingFontCustom" value="Fascinate Inline"/);

  // hostile input is dropped, not echoed into the page's CSS or URLs
  await c.post(editPath, { ...base, theme_headingFontCustom: "x'};</style><script>alert(1)</script>", theme_bodyFontCustom: 'a'.repeat(80) });
  html = await (await fetch(`${BASE}/site/${slug}`)).text();
  assert.doesNotMatch(html, /alert\(1\)/);
  assert.doesNotMatch(html, /Fascinate/);
  assert.match(html, /--body-font: Inter/);
});

test('generating from a template that has its own look applies its style, colors and fonts', async () => {
  const c = makeClient();
  await c.post('/signup', { email: 'look@example.com', password: 'password1' });
  const gen = await c.post('/sites/generate', { business_type: 'tattoo shop', business_name: 'Ink & Iron' });
  const editPath = gen.headers.get('location');
  assert.match(editPath, /\/sites\/\d+\/edit/);
  const html = await (await c.get(editPath)).text();
  assert.match(html, /<option value="midnight" selected>/);
  assert.match(html, /<option value="Pirata One" selected>/);
  assert.match(html, /name="theme_primaryColor" value="#b91c1c"/);
  assert.match(html, /Custom Tattoos/);
  // a type with no look keeps the normal defaults
  const gen2 = await c.post('/sites/generate', { business_type: 'widget factory', business_name: 'Plain Widgets' });
  const html2 = await (await c.get(gen2.headers.get('location'))).text();
  assert.match(html2, /<option value="modern" selected>/);
});

test('editor: the save form is not cut short by nested forms (headline must stay inside it)', async () => {
  const c = makeClient();
  const { siteId, editPath } = await makeLocalSite(c, 'nested@example.com', { name: 'Nested Form Co' });
  // a couple of saves so Version history has entries (that is what used to break the form)
  for (const h of ['First headline', 'Second headline']) {
    await c.post(editPath, { name: 'Nested Form Co', hero_headline: h, about_heading: 'About', about_body: 'x', services_heading: 'Services', contact_heading: 'Contact', layout_order: 'hero,about,services,testimonials,whyChoose,gallery,faq,blog,extraPages,hours,contact' });
  }
  const html = await (await c.get(editPath)).text();
  assert.match(html, /Version history/);
  const start = html.indexOf('id="editorForm"');
  const end = html.indexOf('</form>', start);
  const formHtml = html.slice(start, end);
  assert.doesNotMatch(formHtml, /<form\b/, 'no form may be nested inside the editor form');
  for (const field of ['hero_headline', 'about_body', 'service_title', 'contact_phone', 'theme_style', 'layout_order']) {
    assert.ok(formHtml.includes(`name="${field}"`), `${field} must be inside the editor form`);
  }
  // restore buttons still work through their own forms
  assert.match(html, /<button type="submit" form="restore-\d+"/);
});

test('agency look: tiles, service photo cards, review summary, offices and blog in the footer, help bar', async () => {
  const c = makeClient();
  const { siteId, editPath } = await makeLocalSite(c, 'agency-look@example.com', { name: 'Agency Co' });
  const slug = 'agency-co';
  const base = {
    name: 'Agency Co', hero_headline: 'Coverage', about_heading: 'About Agency Co', about_body: 'We help local families understand their coverage options.',
    services_heading: 'Insurance we offer', contact_heading: 'Contact', contact_phone: '(407) 555-0100', contact_email: 'hi@agency.test', contact_acceptSubmissions: '1',
    service_title: ['Auto Insurance', 'Flood Cover', 'Pet Plan'], service_description: ['Cars', 'Water', 'Pets'], service_detail: ['', '', ''],
    service_image: ['/uploads/auto.jpg', '', ''], service_icon: ['', '', 'star'],
    testimonial_quote: ['Great help.', 'Clear answers.'], testimonial_author: ['Pat', 'Sam'], testimonial_rating: ['5', '4'], testimonial_date: ['', ''],
    blog_title: ['Reading your policy'], blog_date: ['Oct 1, 2026'], blog_body: ['Some real advice.'],
    loc_name: ['Orlando office'], loc_address: ['45 Oak Ave, Orlando, FL'], loc_phone: ['(407) 555-0145'],
    layout_order: 'hero,about,services,testimonials,whyChoose,gallery,faq,blog,extraPages,hours,contact'
  };

  // default style: no tiles
  await c.post(editPath, { ...base, theme_style: 'modern' });
  let home = await (await fetch(`${BASE}/site/${slug}`)).text();
  assert.doesNotMatch(home, /class="home-tiles"/);
  assert.doesNotMatch(home, /class="help-bar"/);

  // agency style: the full home page
  await c.post(editPath, { ...base, theme_style: 'agency' });
  home = await (await fetch(`${BASE}/site/${slug}`)).text();
  assert.match(home, /<body class="style-agency/);
  assert.match(home, /class="home-tiles"/);
  assert.equal((home.match(/class="home-tile"/g) || []).length, 3);
  assert.match(home, /href="\/site\/agency-co\/services\/auto-insurance"/);
  assert.match(home, /class="home-services"/);
  assert.match(home, /<img src="\/uploads\/auto\.jpg"/, 'service photo shows on its card');
  assert.match(home, /4\.5 out of 5 stars/, 'average of the two real ratings');
  assert.match(home, /2 reviews shown on this site/);
  assert.match(home, /class="review-card"/);
  assert.match(home, /class="footer-grid wide"/);
  assert.match(home, /Reading your policy/);
  assert.match(home, /Orlando office/);
  assert.match(home, /\(407\) 555-0145/);
  assert.match(home, /Email an agent/);
  assert.match(home, /id="helpBar"/);
  assert.match(home, /family="?|family=Oswald/);

  // other pages: no home-only blocks, but the help bar stays (not on the contact page)
  const svc = await (await fetch(`${BASE}/site/${slug}/services`)).text();
  assert.doesNotMatch(svc, /class="home-tiles"/);
  assert.match(svc, /id="helpBar"/);
  assert.doesNotMatch(await (await fetch(`${BASE}/site/${slug}/contact`)).text(), /id="helpBar"/);

  // the home page is also available in any style with the checkbox
  await c.post(editPath, { ...base, theme_style: 'minimal', theme_homeFull: '1' });
  home = await (await fetch(`${BASE}/site/${slug}`)).text();
  assert.match(home, /class="home-tiles"/);
  assert.doesNotMatch(home, /id="helpBar"/);

  // editor round-trips the new fields, and rejects junk icons / URLs
  await c.post(editPath, { ...base, theme_style: 'agency', service_icon: ['nonsense', '', 'star'], service_image: ['javascript:alert(1)', '', ''] });
  const ed = await (await c.get(editPath)).text();
  assert.match(ed, /name="loc_name" value="Orlando office"/);
  assert.match(ed, /<option value="agency" selected>/);
  assert.doesNotMatch(ed, /javascript:alert/);
  const home2 = await (await fetch(`${BASE}/site/${slug}`)).text();
  assert.doesNotMatch(home2, /javascript:alert/);
  assert.match(home2, /href="\/site\/agency-co\/services\/pet-plan"[\s\S]*?<path d="M12 3l2\.7/, 'chosen icon is used');
});

test('service icons are picked from the title unless chosen', () => {
  const { iconKeyFor } = require('../icons');
  assert.equal(iconKeyFor('Auto Insurance'), 'auto');
  assert.equal(iconKeyFor('Home Insurance'), 'home');
  assert.equal(iconKeyFor('Flood Insurance'), 'water');
  assert.equal(iconKeyFor('Motorcycle Insurance'), 'motorcycle');
  assert.equal(iconKeyFor('Life Insurance'), 'heart');
  assert.equal(iconKeyFor('Health Insurance'), 'health');
  assert.equal(iconKeyFor('Something unusual'), 'shield');
  assert.equal(iconKeyFor('Auto Insurance', 'boat'), 'boat');
  assert.equal(iconKeyFor('Auto Insurance', 'bogus'), 'auto');
});

test('hero slideshow and office maps: only render when set, junk URLs dropped', async () => {
  const c = makeClient();
  const { editPath } = await makeLocalSite(c, 'slides-maps@example.com', { name: 'Slide Co' });
  const slug = 'slide-co';
  const base = {
    name: 'Slide Co', hero_headline: 'Hello', about_heading: 'About', about_body: 'Text here for the page.',
    contact_phone: '(407) 555-0100', contact_email: 'hi@slide.test', contact_address: '1 Main St, Kissimmee, FL',
    theme_style: 'agency'
  };
  // none set: no slideshow controls, no office section
  await c.post(editPath, base);
  let home = await (await fetch(`${BASE}/site/${slug}`)).text();
  assert.doesNotMatch(home, /class="hero-controls"/);
  assert.doesNotMatch(home, /class="hero-slide"/);
  let contact = await (await fetch(`${BASE}/site/${slug}/contact`)).text();
  assert.doesNotMatch(contact, /class="office-card"/);

  await c.post(editPath, { ...base, hero_imageUrl: '/uploads/main.jpg', hero_slide: ['/uploads/a.jpg', 'javascript:alert(1)', 'https://example.com/b.jpg'],
    loc_name: ['Orlando office'], loc_address: ['45 Oak Ave, Orlando, FL'], loc_phone: ['(407) 555-0145'] });
  home = await (await fetch(`${BASE}/site/${slug}`)).text();
  assert.match(home, /hero-controls/);
  assert.equal((home.match(/hero-slide"? data-photo|data-photo=/g) || []).length >= 2, true);
  assert.doesNotMatch(home, /javascript:alert/);
  assert.match(home, /maps\.google\.com\/maps\?q=/, 'footer map for agency home');
  contact = await (await fetch(`${BASE}/site/${slug}/contact`)).text();
  assert.match(contact, /office-card/);
  assert.match(contact, /Orlando office/);
  assert.match(contact, /maps\.google\.com\/maps\?q=45/);

  const ed = await (await c.get(editPath)).text();
  assert.match(ed, /name="hero_slide" value="\/uploads\/a\.jpg"/);
});

test('content blocks: add, order, render, junk dropped, editor round-trip', async () => {
  const c = makeClient();
  const { editPath } = await makeLocalSite(c, 'blocks@example.com', { name: 'Block Co' });
  const slug = 'block-co';
  const base = { name: 'Block Co', hero_headline: 'Hi', about_heading: 'About', about_body: 'Some text for the about page.', contact_email: 'a@b.test' };

  let home = await (await fetch(`${BASE}/site/${slug}`)).text();
  assert.doesNotMatch(home, /class="blk /);

  const rr = await c.post(editPath, { ...base,
    block_type: ['photoText', 'photoText', 'steps', 'bogus'],
    block_heading: ['First story', 'Second story', 'How it works', 'x'],
    block_body: ['Para one.\n\nPara two.', 'More words.', 'Book online | Pick a time\nWe arrive | On schedule\nJust a title', 'x'],
    block_image: ['/uploads/a.jpg', 'javascript:alert(1)', '', ''],
    block_buttonText: ['Book now', '', '', ''], block_buttonUrl: ['/site/block-co/contact', '', '', ''],
    block_side: ['auto', 'auto', 'auto', 'auto'], block_bg: ['none', 'brand', 'none', 'none'], block_place: ['bottom', 'bottom', 'bottom', 'bottom'] });
  home = await (await fetch(`${BASE}/site/${slug}`)).text();
  assert.equal((home.match(/<section class="blk /g) || []).length, 3, 'bogus type dropped');
  assert.match(home, /First story/);
  assert.ok(home.indexOf('First story') < home.indexOf('Second story') && home.indexOf('Second story') < home.indexOf('How it works'), 'kept in order');
  assert.match(home, /<p>Para one\.<\/p>\s*<p>Para two\.<\/p>/);
  assert.match(home, /class="blk-img"><img src="\/uploads\/a\.jpg"/);
  assert.doesNotMatch(home, /javascript:alert/);
  assert.match(home, /blk-bg-brand/);
  assert.equal((home.match(/class="step-card"/g) || []).length, 3);
  assert.match(home, /photo-right/, "first photo block puts the photo on the right");
  assert.match(home, /href="\/site\/block-co\/contact">Book now/);

  // other pages never show blocks
  assert.doesNotMatch(await (await fetch(`${BASE}/site/${slug}/about`)).text(), /First story/);

  // editor round-trip + no nested forms regression stays intact
  const ed = await (await c.get(editPath)).text();
  assert.match(ed, /name="block_heading" maxlength="120" value="First story"/);
  assert.match(ed, /data-newblock="steps"/);
  const form = ed.slice(ed.indexOf('id="editorForm"'));
  assert.doesNotMatch(form.slice(0, form.indexOf('</form>')), /<form/);

  // saving with no blocks clears them; top placement renders before the footer area still on home
  await c.post(editPath, { ...base, block_type: ['photoText'], block_heading: ['Up top'], block_body: ['t'], block_image: [''], block_buttonText: [''], block_buttonUrl: [''], block_side: ['left'], block_bg: ['tint'], block_place: ['top'] });
  home = await (await fetch(`${BASE}/site/${slug}`)).text();
  assert.match(home, /Up top/);
  assert.doesNotMatch(home, /First story/);
  await c.post(editPath, { ...base });
  assert.doesNotMatch(await (await fetch(`${BASE}/site/${slug}`)).text(), /<section class="blk /);
});

test('more content blocks: feature cards, call-to-action band, area chips', async () => {
  const c = makeClient();
  const { editPath } = await makeLocalSite(c, 'blocks2@example.com', { name: 'Block Two' });
  const base = { name: 'Block Two', hero_headline: 'Hi', about_heading: 'About', about_body: 'Some text for the about page.', contact_email: 'a@b.test' };
  const n = 4;
  const arr = (...v) => v;
  await c.post(editPath, { ...base,
    block_type: arr('features', 'cta', 'chips', 'chips'),
    block_heading: arr('Why us', 'Book today', 'Where we work', ''),
    block_body: arr('Local team | We live here\nFast reply | We answer quickly', 'Ready when you are.', 'Kissimmee, FL | /site/block-two/contact\nSt. Cloud, FL\nBad | javascript:alert(1)', ''),
    block_image: arr('', '/uploads/band.jpg', '', ''), block_buttonText: arr('', 'Book now', '', ''), block_buttonUrl: arr('', '/site/block-two/contact', '', ''),
    block_side: arr('auto', 'auto', 'auto', 'auto'), block_bg: arr('none', 'none', 'tint', 'none'), block_place: arr('bottom', 'bottom', 'bottom', 'bottom') });
  const home = await (await fetch(`${BASE}/site/block-two`)).text();
  assert.equal((home.match(/class="feat-card"/g) || []).length, 2);
  assert.match(home, /class="blk blk-cta-band has-photo"[^>]*band\.jpg/);
  assert.match(home, /href="\/site\/block-two\/contact">Book now/);
  assert.match(home, /<a class="chip" href="\/site\/block-two\/contact">Kissimmee, FL/);
  assert.match(home, /<span class="chip">St\. Cloud, FL/);
  assert.doesNotMatch(home, /javascript:alert/);
  assert.equal((home.match(/class="chip-grid"/g) || []).length, 1, 'fully empty block dropped');
  const ed = await (await c.get(editPath)).text();
  assert.match(ed, /data-newblock="cta"/);
  assert.match(ed, /Closing call-to-action band/);
});

test('generating a pet template brings its look and content blocks', async () => {
  const c = makeClient();
  await c.post('/signup', { email: 'pets@example.com', password: 'password1' });
  const gen = await c.post('/sites/generate', { business_type: 'mobile pet grooming', business_name: 'Paws On Wheels' });
  const editPath = gen.headers.get('location');
  const ed = await (await c.get(editPath)).text();
  assert.match(ed, /<option value="studio" selected>/);
  assert.equal((ed.match(/<input type="hidden" name="block_type"/g) || []).length >= 4, true);
  assert.match(ed, /Grooming that comes to you/);
  assert.match(ed, /Paws On Wheels turns your driveway/);
  assert.doesNotMatch(ed, /\{name\}/);
  const gen2 = await c.post('/sites/generate', { business_type: 'dog training', business_name: 'Good Dog Co' });
  assert.match(await (await c.get(gen2.headers.get('location'))).text(), /Training built around your dog/);
  // a template with no blocks gets none
  const gen3 = await c.post('/sites/generate', { business_type: 'plumbing company', business_name: 'Plain Pipes 2' });
  assert.doesNotMatch(await (await c.get(gen3.headers.get('location'))).text(), /name="block_heading" maxlength="120" value="[^"]/);
});

test('extra themes: selectable, applied as body class + variables, custom font still wins, junk rejected', async () => {
  const c = makeClient();
  const { editPath } = await makeLocalSite(c, 'themes@example.com', { name: 'Theme Co' });
  const base = { name: 'Theme Co', hero_headline: 'Hi', about_heading: 'About', about_body: 'Some text for about.', contact_email: 'a@b.test' };
  const { IDS } = require('../themes');
  assert.ok(IDS.length >= 6);
  for (const id of IDS) {
    await c.post(editPath, { ...base, theme_style: id });
    const home = await (await fetch(`${BASE}/site/theme-co`)).text();
    assert.match(home, new RegExp(`<body class="style-${id}`), id);
    assert.match(home, new RegExp(`body\\.style-${id} \\{[^}]*--page-bg`), `${id} variables`);
    const ed = await (await c.get(editPath)).text();
    assert.match(ed, new RegExp(`<option value="${id}" selected>`), `${id} stays selected`);
  }
  // heading font from the theme, unless the owner picked their own
  await c.post(editPath, { ...base, theme_style: 'luxe' });
  let home = await (await fetch(`${BASE}/site/theme-co`)).text();
  assert.match(home, /--heading-font: 'Cormorant Garamond'/);
  assert.match(home, /Cormorant\+Garamond/);
  await c.post(editPath, { ...base, theme_style: 'luxe', theme_headingFont: 'Bebas Neue' });
  home = await (await fetch(`${BASE}/site/theme-co`)).text();
  assert.doesNotMatch(home, /body\.style-luxe \{[^}]*--heading-font/);
  // junk style falls back to modern
  await c.post(editPath, { ...base, theme_style: 'luxe;}</style><script>alert(1)</script>' });
  home = await (await fetch(`${BASE}/site/theme-co`)).text();
  assert.match(home, /<body class="style-modern/);
});

test('home page layouts: basic, full, story, tiles, list; styles bring a default; junk ignored', async () => {
  const c = makeClient();
  const { editPath } = await makeLocalSite(c, 'layouts@example.com', { name: 'Layout Co' });
  const base = { name: 'Layout Co', hero_headline: 'Hi', about_heading: 'About Layout Co', about_body: 'Some real text about the business.', about_imageUrl: '/uploads/about.jpg',
    services_heading: 'What we do', service_title: ['Alpha', 'Beta'], service_description: ['First', 'Second'], service_detail: ['', ''], service_image: ['/uploads/a.jpg', ''], service_icon: ['', ''],
    contact_email: 'a@b.test', layout_order: 'hero,about,services,testimonials,whyChoose,gallery,faq,blog,extraPages,hours,contact' };
  const home = async () => (await fetch(`${BASE}/site/layout-co`)).text();
  const marks = { full: 'class="home-svc-grid"', story: 'class="svc-rows"', tiles: 'class="svc-tiles ', list: 'class="svc-list"' };
  const only = (html, key) => { for (const [k, m] of Object.entries(marks)) (k === key ? assert.match : assert.doesNotMatch)(html, new RegExp(m), `${key}: ${k}`); };

  await c.post(editPath, { ...base, theme_style: 'modern', theme_homeLayout: 'basic' });
  let h = await home(); only(h, null); assert.match(h, /<body class="style-modern layout-basic/);
  for (const k of ['full', 'story', 'tiles', 'list']) {
    await c.post(editPath, { ...base, theme_style: 'modern', theme_homeLayout: k });
    h = await home(); only(h, k); assert.match(h, new RegExp(`layout-${k}`));
  }
  await c.post(editPath, { ...base, theme_style: 'modern', theme_homeLayout: 'story' });
  h = await home();
  assert.match(h, /class="intro-photo"/, 'story shows the about photo');
  assert.match(h, /class="svc-row"/); assert.match(h, /class="svc-row flip"/);
  // a style brings its default; an explicit choice beats it
  await c.post(editPath, { ...base, theme_style: 'luxe', theme_homeLayout: '' });
  only(await home(), 'list');
  await c.post(editPath, { ...base, theme_style: 'luxe', theme_homeLayout: 'tiles' });
  only(await home(), 'tiles');
  // legacy tick-box, agency default, junk value
  await c.post(editPath, { ...base, theme_style: 'minimal', theme_homeFull: '1' });
  only(await home(), 'full');
  await c.post(editPath, { ...base, theme_style: 'agency' });
  only(await home(), 'full');
  await c.post(editPath, { ...base, theme_style: 'modern', theme_homeLayout: 'x"><script>' });
  only(await home(), null);
  // hero variants come from the style
  await c.post(editPath, { ...base, theme_style: 'earthy' });
  assert.match(await home(), /hero-boxed/);
  // the editor offers the chips and the layout select
  const ed = await (await c.get(editPath)).text();
  assert.match(ed, /data-style="gallery"/); assert.match(ed, /name="theme_homeLayout"/);
});

test('per-page styles and inner-page service layouts', async () => {
  const c = makeClient();
  const { editPath } = await makeLocalSite(c, 'pagestyle@example.com', { name: 'Page Style Co' });
  const base = { name: 'Page Style Co', hero_headline: 'Hi', about_heading: 'About', about_body: 'Some text for about.', about_imageUrl: '',
    services_heading: 'What we do', service_title: ['Alpha', 'Beta'], service_description: ['First', 'Second'], service_detail: ['More about alpha.', ''], service_image: ['/uploads/a.jpg', ''], service_icon: ['', ''],
    contact_email: 'a@b.test', contact_phone: '(407) 555-0100', layout_order: 'hero,about,services,testimonials,whyChoose,gallery,faq,blog,extraPages,hours,contact' };
  const get = async (p) => (await fetch(`${BASE}/site/page-style-co${p}`)).text();

  // site style everywhere by default
  await c.post(editPath, { ...base, theme_style: 'modern', theme_homeLayout: 'basic' });
  assert.match(await get(''), /<body class="style-modern /);
  assert.match(await get('/services'), /<body class="style-modern /);

  // a different style only on the services pages (list and detail), nothing else
  await c.post(editPath, { ...base, theme_style: 'modern', theme_homeLayout: 'basic', pagestyle_services: 'gallery', pagestyle_contact: 'nonsense' });
  assert.match(await get(''), /<body class="style-modern /);
  assert.match(await get('/services'), /<body class="style-gallery /);
  assert.match(await get('/services/alpha'), /<body class="style-gallery /);
  assert.match(await get('/contact'), /<body class="style-modern /, 'junk page style ignored');
  const ed = await (await c.get(editPath)).text();
  assert.match(ed, /name="pagestyle_services"/);
  assert.match(ed, /<option value="gallery" selected>/);

  // inner services page follows the layout
  const layouts = { story: 'class="svc-rows"', tiles: 'class="svc-tiles ', list: 'class="svc-list"', full: 'class="grid"', basic: 'class="grid"' };
  for (const [k, marker] of Object.entries(layouts)) {
    await c.post(editPath, { ...base, theme_style: 'modern', theme_homeLayout: k });
    assert.match(await get('/services'), new RegExp(marker), k);
  }
  // a style's default layout reaches the services page too
  await c.post(editPath, { ...base, theme_style: 'luxe' });
  assert.match(await get('/services'), /class="svc-list"/);
});

test('generator gives industries their own style; editor shows style hints', async () => {
  const c = makeClient();
  await c.post('/signup', { email: 'looks2@example.com', password: 'password1' });
  const g1 = await c.post('/sites/generate', { business_type: 'hair salon', business_name: 'Velvet Hair' });
  const ed1 = await (await c.get(g1.headers.get('location'))).text();
  assert.match(ed1, /<option value="luxe" selected>/);
  assert.match(ed1, /id="styleHint"[^>]*>[^<]*salons/);
  const g2 = await c.post('/sites/generate', { business_type: 'accounting firm', business_name: 'Ledger Co' });
  const ed2 = await (await c.get(g2.headers.get('location'))).text();
  assert.match(ed2, /<option value="corporate" selected>/);
  assert.match(ed2, /<option value="list" selected>/);
  const g3 = await c.post('/sites/generate', { business_type: 'plumbing company', business_name: 'Pipes R Us' });
  assert.match(await (await c.get(g3.headers.get('location'))).text(), /<option value="studio" selected>/);
});

test('hero feature cards and logo strip: only when filled in, safe, round-trip', async () => {
  const c = makeClient();
  const { editPath } = await makeLocalSite(c, 'cards-logos@example.com', { name: 'Card Co' });
  const base = { name: 'Card Co', hero_headline: 'Hi', about_heading: 'About', about_body: 'Some text for about.', contact_email: 'a@b.test', theme_style: 'modern', theme_homeLayout: 'basic' };
  const get = async () => (await fetch(`${BASE}/site/card-co`)).text();
  let h = await get();
  assert.doesNotMatch(h, /class="hero-cards/); assert.doesNotMatch(h, /class="logo-strip"/);

  await c.post(editPath, { ...base,
    hero_card_title: ['Local team', '', 'Plain answers', 'Easy booking', 'Fourth one', 'Fifth card'], hero_card_text: ['We live here', 'ignored', 'No jargon', '', 'More', 'ignored'],
    trust_logosHeading: 'Our memberships', trust_logo_url: ['/uploads/l1.png', 'javascript:alert(1)', '', 'https://example.com/l2.png'], trust_logo_label: ['Chamber', 'Bad', '', 'Assoc'] });
  h = await get();
  assert.match(h, /class="hero-cards n4"/, 'blank title dropped, max four');
  assert.match(h, /<strong>Local team<\/strong>\s*<p>We live here<\/p>/);
  assert.match(h, /<strong>Easy booking<\/strong>\s*<\/div>/, 'card without text has no empty paragraph');
  assert.doesNotMatch(h, /Fifth card/);
  assert.match(h, /class="logo-strip"/); assert.match(h, /<h2>Our memberships<\/h2>/);
  assert.equal((h.match(/<img src="[^"]*" alt="(Chamber|Assoc)"/g) || []).length, 2, 'junk logo URL dropped');
  assert.doesNotMatch(h, /javascript:alert/);
  // other pages never show them
  assert.doesNotMatch(await (await fetch(`${BASE}/site/card-co/about`)).text(), /class="hero-cards |class="logo-strip"/);
  const ed = await (await c.get(editPath)).text();
  assert.match(ed, /name="hero_card_title" value="Local team"/);
  assert.match(ed, /name="trust_logo_url" value="\/uploads\/l1\.png"/);
  assert.match(ed, /name="trust_logosHeading" value="Our memberships"/);
  const form = ed.slice(ed.indexOf('id="editorForm"'));
  assert.doesNotMatch(form.slice(0, form.indexOf('</form>')), /<form/);
});

test('photo strip, split block, dark band, shaped edges', async () => {
  const c = makeClient();
  const { editPath } = await makeLocalSite(c, 'strip@example.com', { name: 'Strip Co' });
  const base = { name: 'Strip Co', hero_headline: 'Hi', about_heading: 'About', about_body: 'Some text for about.', contact_email: 'a@b.test', theme_style: 'modern', theme_homeLayout: 'basic' };
  const home = async () => (await fetch(`${BASE}/site/strip-co`)).text();
  const arr = (...v) => v;
  assert.doesNotMatch(await home(), /class="strip"/);

  await c.post(editPath, { ...base, hero_edge: 'wave',
    block_type: arr('strip', 'split', 'strip'),
    block_heading: arr('Our work', 'A small sample of our work', 'Empty strip'),
    block_body: arr('/uploads/a.jpg\njavascript:alert(1)\nhttps://example.com/b.jpg\n\n/uploads/c.jpg', 'First paragraph.\n\nSecond paragraph.', ''),
    block_image: arr('', '', ''), block_buttonText: arr('Follow us', 'See more', ''), block_buttonUrl: arr('https://instagram.com/strip', '/site/strip-co/contact', ''),
    block_side: arr('auto', 'auto', 'auto'), block_bg: arr('none', 'dark', 'none'), block_edge: arr('scallop', 'wave', 'none'), block_place: arr('bottom', 'bottom', 'bottom') });
  const h = await home();
  assert.equal((h.match(/<div class="strip"/g) || []).length, 1, 'empty strip is dropped');
  assert.equal((h.match(/<img src="[^"]*" alt="Our work"/g) || []).length, 3, 'junk URL and blank line removed');
  assert.match(h, /class="strip-btn prev"/); assert.match(h, /class="strip-btn next"/);
  assert.match(h, /href="https:\/\/instagram\.com\/strip" target="_blank" rel="noopener">Follow us/);
  assert.doesNotMatch(h, /javascript:alert/);
  assert.match(h, /class="blk blk-strip blk-bg-none edge-scallop"/);
  assert.match(h, /class="blk blk-bg-dark edge-wave"/);
  assert.match(h, /class="blk-inner blk-split"/); assert.match(h, /<p>First paragraph\.<\/p>\s*<p>Second paragraph\.<\/p>/);
  assert.match(h, /class="hero edge-wave"/);

  const ed = await (await c.get(editPath)).text();
  assert.equal((ed.match(/class="strip-url" value="/g) || []).length >= 3, true);
  assert.match(ed, /<textarea name="block_body" class="strip-body" hidden>\/uploads\/a\.jpg/);
  assert.match(ed, /<option value="wave" selected>/);
  assert.match(ed, /name="hero_edge"/);
  const form = ed.slice(ed.indexOf('id="editorForm"'));
  assert.doesNotMatch(form.slice(0, form.indexOf('</form>')), /<form/);
  // straight edges and no hero edge by default
  await c.post(editPath, { ...base });
  const h2 = await home();
  assert.doesNotMatch(h2, /class="hero edge-/); assert.doesNotMatch(h2, /class="blk blk-strip/);
});

// ---------- online booking ----------
const bookingFields = (o = {}) => {
  const f = {
    bk_enabled: '1', bk_kind: 'grooming', bk_heading: 'Book a Grooming', bk_intro: 'Tell us about your pet.',
    bk_timezone: 'America/New_York', bk_step: '60', bk_lead: '0', bk_window: '30', bk_capacity: '1',
    bk_service_name: ['Full groom', 'Bath only'], bk_service_minutes: ['120', '60'], bk_service_price: ['from $70', ''], bk_service_desc: ['Bath, cut and style', ''],
    bk_addon_name: ['Nail trim'], bk_addon_price: [''], bk_addon_minutes: ['0'],
    bk_field_label: ['Pet name', 'Size'], bk_field_type: ['text', 'select'], bk_field_options: ['', 'Small, Medium, Large'], bk_field_required: ['1', '1'],
    bk_policy: 'Please give 24 hours notice to cancel.', ...o
  };
  for (const d of ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat']) { f[`bk_open_${d}`] = '09:00'; f[`bk_close_${d}`] = '13:00'; }
  return f;
};
const daysAhead = (n) => { const d = new Date(Date.now() + n * 86400000); return d.toISOString().slice(0, 10); };

test('booking: setup, open times, request, double-booking guard, owner confirm/decline, customer cancel', async () => {
  const c = makeClient();
  const { siteId, slug } = await basicSite(c, 'booker@example.com', 'Paws Booking', bookingFields());
  const date = daysAhead(5);

  // page is live with the owner's industry questions and a Book Now button
  const page = await (await fetch(`${BASE}/site/${slug}/book`)).text();
  assert.match(page, /Book a Grooming/);
  assert.match(page, /name="service" value="Full groom"/);
  assert.match(page, /Pet name/);
  assert.match(page, /<option value="Medium"/);
  assert.match(page, /Please give 24 hours notice/);
  assert.match(page, /class="nav-cta" href="\/site\/paws-booking\/book">Book Now</);
  assert.match(await (await fetch(`${BASE}/site/${slug}`)).text(), /Book Now/);
  const form = page.match(/<form[^>]*id="bookForm"[\s\S]*?<\/form>/)[0];
  assert.doesNotMatch(form.slice(10), /<form/, 'no nested forms');

  // open times: 09:00-13:00, hourly; a two hour service leaves 09, 10, 11
  const slots = async (q) => (await (await fetch(`${BASE}/site/${slug}/book/slots?${new URLSearchParams(q)}`)).json()).slots.map(s => s.time);
  assert.deepEqual(await slots({ service: 'Full groom', date }), ['09:00', '10:00', '11:00']);
  assert.deepEqual(await slots({ service: 'Bath only', date }), ['09:00', '10:00', '11:00', '12:00']);
  assert.deepEqual(await slots({ service: 'Nope', date }), []);
  assert.deepEqual(await slots({ service: 'Full groom', date: daysAhead(200) }), [], 'beyond the booking window');
  assert.deepEqual(await slots({ service: 'Full groom', date: daysAhead(-1) }), [], 'in the past');

  const post = (body, p = 'book') => fetch(`${BASE}/site/${slug}/${p}`, { method: 'POST', redirect: 'manual', headers: { 'content-type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams(body).toString() });
  const good = { service: 'Full groom', date, time: '10:00', name: 'Dana Pet', email: 'dana@example.com', phone: '555-0199', f_0: 'Biscuit', f_1: 'Medium', notes: 'Nervous around dryers', addon: 'Nail trim' };

  // validation
  for (const [bad, msg] of [[{ name: '' }, /enter your name/], [{ email: 'nope' }, /valid email/], [{ service: 'Bogus' }, /choose a service/], [{ f_0: '' }, /highlighted/], [{ time: '' }, /date and time/], [{ time: '10:30' }, /no longer available/]]) {
    const r = await post({ ...good, ...bad });
    assert.equal(r.status, 422, JSON.stringify(bad));
    const html = await r.text();
    assert.match(html, msg);
    assert.match(html, /value="Dana Pet"|value=""/); // form is re-shown
  }
  assert.equal((await post({ ...good, f_1: 'Giant' })).status, 422, 'a dropdown answer must be one of the choices');
  const bot = await post({ ...good, website: 'http://spam' });
  assert.match(bot.headers.get('location'), /done=1/);

  // a real request: stored pending, owner and customer emailed
  const m0 = mailCount();
  const ok = await post(good);
  assert.equal(ok.status, 302);
  const loc = ok.headers.get('location');
  assert.match(loc, new RegExp(`^/site/${slug}/book\\?t=[\\w-]+&new=1$`));
  const status = await (await fetch(`${BASE}${loc}`)).text();
  assert.match(status, /not confirmed yet/);
  assert.match(status, /Full groom \+ Nail trim/);
  assert.match(status, /Biscuit/);
  assert.match(status, /noindex/);
  const mails = await waitForMail(m0 + 2);
  const to = mails.slice(m0).map(m => m.to[0].address).sort();
  assert.deepEqual(to, ['dana@example.com', 'owner@biz.test']);
  const ownerMail = mails.slice(m0).find(m => m.to[0].address === 'owner@biz.test');
  assert.match(ownerMail.text, /Biscuit/);
  assert.match(ownerMail.text, /\/sites\/\d+\/bookings/);

  // the time is now held: the same start and anything overlapping it are gone
  assert.deepEqual(await slots({ service: 'Full groom', date }), [], 'a 2h groom at 10:00 leaves no room for another 2h groom (09:00 and 11:00 overlap it, 12:00 runs past closing)');
  assert.deepEqual(await slots({ service: 'Bath only', date }), ['09:00', '12:00']);
  const dup = await post({ ...good, name: 'Someone Else', email: 'else@example.com', time: '11:00' });
  assert.equal(dup.status, 422);
  assert.match(await dup.text(), /no longer available/);

  // owner sees it, other users cannot
  let html = await (await c.get(`/sites/${siteId}/bookings`)).text();
  assert.match(html, /Dana Pet/);
  assert.match(html, /Nervous around dryers/);
  assert.match(await (await c.get(`/sites/${siteId}/edit`)).text(), /Bookings \(1 new\)/);
  const bid = html.match(/\/bookings\/(\d+)"/)[1];
  const other = makeClient();
  await other.post('/signup', { email: 'booker-other@example.com', password: 'password1' });
  assert.equal((await other.get(`/sites/${siteId}/bookings`)).status, 404);
  assert.equal((await other.post(`/sites/${siteId}/bookings/${bid}`, { action: 'confirm' })).status, 404);

  const m1 = mailCount();
  assert.match((await c.post(`/sites/${siteId}/bookings/${bid}`, { action: 'confirm', message: 'See you then!' })).headers.get('location'), /m=confirmed/);
  const cm = (await waitForMail(m1 + 1)).slice(m1)[0];
  assert.equal(cm.to[0].address, 'dana@example.com');
  assert.match(cm.text, /confirmed/);
  assert.match(cm.text, /See you then!/);
  assert.match(await (await fetch(`${BASE}${loc}`)).text(), /Your appointment is confirmed|You are booked/);
  // confirming twice is refused
  assert.match((await c.post(`/sites/${siteId}/bookings/${bid}`, { action: 'confirm' })).headers.get('location'), /m=bad/);

  // second request, owner declines -> the time is freed
  const r2 = await post({ ...good, time: '12:00', service: 'Bath only', name: 'Lee', email: 'lee@example.com', addon: '' });
  assert.equal(r2.status, 302);
  html = await (await c.get(`/sites/${siteId}/bookings`)).text();
  const bid2 = [...html.matchAll(/\/bookings\/(\d+)"/g)].map(x => x[1]).find(x => x !== bid);
  assert.deepEqual(await slots({ service: 'Bath only', date }), ['09:00']);
  await c.post(`/sites/${siteId}/bookings/${bid2}`, { action: 'decline' });
  assert.deepEqual(await slots({ service: 'Bath only', date }), ['09:00', '12:00']);

  // customer cancels the confirmed one with their private link -> time freed again
  const token = loc.match(/t=([\w-]+)/)[1];
  const cancel = await post({ token }, 'book/cancel');
  assert.match(cancel.headers.get('location'), /book\?t=/);
  assert.match(await (await fetch(`${BASE}${loc}`)).text(), /was cancelled/);
  assert.deepEqual(await slots({ service: 'Full groom', date }), ['09:00', '10:00', '11:00']);
  // a made-up token shows the plain form, not someone's booking
  assert.doesNotMatch(await (await fetch(`${BASE}/site/${slug}/book?t=nope`)).text(), /Dana Pet/);
});

test('booking: switched off by default, auto-confirm, mobile address, preview and presets', async () => {
  const c = makeClient();
  const { siteId, slug } = await basicSite(c, 'booker2@example.com', 'Van Groomers');
  assert.equal((await fetch(`${BASE}/site/${slug}/book`)).status, 404, 'off until the owner turns it on');
  assert.equal((await fetch(`${BASE}/site/${slug}/book/slots?service=x&date=2030-01-01`)).status, 404);
  assert.doesNotMatch(await (await fetch(`${BASE}/site/${slug}`)).text(), /Book Now/);
  assert.match(await (await c.get(`/sites/${siteId}/edit`)).text(), /Online booking/);

  // loading a preset fills services from the site's own services and keeps booking off
  assert.match((await c.post(`/sites/${siteId}/booking/preset`, { kind: 'mobile-grooming' })).headers.get('location'), /booking=1/);
  let edit = await (await c.get(`/sites/${siteId}/edit`)).text();
  assert.match(edit, /name="bk_service_name" value="Roof Repair"/);
  assert.match(edit, /Parking or access notes/);
  assert.match(edit, /name="bk_askAddress"[^>]*checked/);
  assert.doesNotMatch(edit, /name="bk_enabled"[^>]*checked/);

  // a save from the editor keeps everything (the editor posts the whole form)
  const f = bookingFields({ bk_kind: 'mobile-grooming', bk_autoConfirm: '1', bk_askAddress: '1', bk_field_label: ['Pet name'], bk_field_type: ['text'], bk_field_options: [''], bk_field_required: ['0'] });
  await c.post(`/sites/${siteId}/edit`, { name: 'Van Groomers', hero_headline: 'Hi', about_heading: 'About', about_body: 'x', services_heading: 'S', service_title: ['Roof Repair'], service_description: ['d'], service_detail: [''], contact_heading: 'C', contact_email: 'owner@biz.test', layout_order: 'hero,about,services,testimonials,whyChoose,gallery,faq,blog,extraPages,hours,contact', ...f });
  const date = daysAhead(4);
  const post = (body) => fetch(`${BASE}/site/${slug}/book`, { method: 'POST', redirect: 'manual', headers: { 'content-type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams(body).toString() });
  const base = { service: 'Bath only', date, time: '09:00', name: 'Sam', email: 'sam@example.com' };
  const noAddr = await post(base);
  assert.equal(noAddr.status, 422);
  assert.match(await noAddr.text(), /address where we should come/);
  const m0 = mailCount();
  const ok = await post({ ...base, address: '12 Palm Way, Kissimmee FL' });
  assert.equal(ok.status, 302);
  const st = await (await fetch(`${BASE}${ok.headers.get('location')}`)).text();
  assert.match(st, /You are booked/);
  assert.match(st, /12 Palm Way/);
  const mails = await waitForMail(m0 + 2);
  assert.ok(mails.slice(m0).some(m => m.to[0].address === 'sam@example.com' && /confirmed/i.test(m.text)));

  // the editor preview shows the booking page but cannot submit
  const prev = await (await c.get(`/sites/${siteId}/preview/book`)).text();
  assert.match(prev, /Preview: booking is disabled here/);
  assert.match(prev, /id="bookSubmit"[^>]*disabled/);
  const ps = await (await c.get(`/sites/${siteId}/preview/book/slots?service=Bath%20only&date=${daysAhead(6)}`)).json();
  assert.ok(ps.slots.length > 0);
  assert.equal((await fetch(`${BASE}/sites/${siteId}/preview/book/slots`, { redirect: 'manual' })).status, 302, 'previews are private to the owner');

  // static export still works (booking needs the server, so the export has no Book Now link)
  assert.equal((await c.get(`/sites/${siteId}/export`)).status, 200);
});

test('palette: editor shows the palette panel and serves the script', async () => {
  const c = makeClient();
  const { siteId } = await basicSite(c, 'palette@example.com', 'Palette Pets', { meta_businessType: 'pet grooming' });
  const html = await (await c.get(`/sites/${siteId}/edit`)).text();
  assert.match(html, /id="paletteBox"[^>]*data-biztype="pet grooming"/);
  assert.match(html, /<script src="\/palette\.js"><\/script>/);
  const js = await fetch(`${BASE}/palette.js`);
  assert.equal(js.status, 200);
  assert.match(await js.text(), /suggestions/);
});

test('pricing block, announcement bar, lightbox and search markup', async () => {
  const c = makeClient();
  const fields = {
    block_type: ['pricing'], block_heading: ['Grooming packages'],
    block_body: ['Bath | from $40 | Wash and dry, Brush out, Ear cleaning\n* Full groom | from $70 | Bath, Haircut, Nail trim\n | $5 | no name here'],
    block_image: [''], block_side: ['auto'], block_buttonText: ['Book now'], block_buttonUrl: ['/site/shine-pets/book'], block_edge: ['none'], block_bg: ['none'], block_place: ['bottom'],
    ann_enabled: '1', ann_text: 'Now booking holiday appointments', ann_linkText: 'Book', ann_linkUrl: '/site/shine-pets/book',
    gallery_image: ['https://img.example/a.jpg', 'https://img.example/b.jpg'],
    faq_question: ['Do you take walk-ins?'], faq_answer: ['Please book ahead.'],
    hours_day: ['Monday', 'Tuesday', 'Saturday', 'Sunday', 'Holidays'], hours_time: ['9:00 AM – 5:30 PM', '9am - 5pm', 'Closed', 'Closed', 'Call us']
  };
  const { siteId } = await basicSite(c, 'shine@example.com', 'Shine Pets', fields);
  const home = await (await fetch(`${BASE}/site/shine-pets`)).text();
  // pricing
  assert.match(home, /class="price-grid n2"/, 'junk line without a name is dropped');
  assert.match(home, /<div class="price-card hot">\s*<span class="price-flag">Featured<\/span>\s*<h3>Full groom<\/h3>/);
  assert.match(home, /<div class="price-amt">from \$70<\/div>/);
  assert.match(home, /<li>Nail trim<\/li>/);
  assert.equal((home.match(/class="btn" href="\/site\/shine-pets\/book">Book now/g) || []).length, 2, 'each plan has the button');
  assert.doesNotMatch(home, /Most popular|best value/i, 'no invented claims');
  // announcement
  assert.match(home, /id="annBar"[^>]*>\s*<span>Now booking holiday appointments<\/span><a href="\/site\/shine-pets\/book">Book<\/a>/);
  assert.match(await (await fetch(`${BASE}/site/shine-pets/about`)).text(), /id="annBar"/, 'on every page');
  // lightbox on the gallery
  const gal = await (await fetch(`${BASE}/site/shine-pets/gallery`)).text();
  assert.match(gal, /<div class="gallery-grid" data-lightbox>/);
  assert.match(gal, /class="lb-close|lb-close/);
  // structured data
  const ldOf = (html) => [...html.matchAll(/<script type="application\/ld\+json">([\s\S]*?)<\/script>/g)].map(m => JSON.parse(m[1]));
  const lb = ldOf(home).find(x => x['@type'] === 'LocalBusiness');
  assert.deepEqual(lb.openingHoursSpecification, [
    { '@type': 'OpeningHoursSpecification', dayOfWeek: 'Monday', opens: '09:00', closes: '17:30' },
    { '@type': 'OpeningHoursSpecification', dayOfWeek: 'Tuesday', opens: '09:00', closes: '17:00' }
  ], 'only readable rows; Closed and free text are left out');
  const faq = ldOf(await (await fetch(`${BASE}/site/shine-pets/faq`)).text()).find(x => x['@type'] === 'FAQPage');
  assert.equal(faq.mainEntity[0].name, 'Do you take walk-ins?');
  assert.equal(faq.mainEntity[0].acceptedAnswer.text, 'Please book ahead.');
  assert.ok(!ldOf(home).some(x => x['@type'] === 'FAQPage'), 'FAQ markup only on the FAQ page, where the questions are visible');
  assert.doesNotMatch(JSON.stringify(ldOf(home)), /aggregateRating/);

  // turning things off / junk input
  await c.post(`/sites/${siteId}/edit`, { name: 'Shine Pets', hero_headline: 'Hi', about_heading: 'About', about_body: 'x', services_heading: 'S', service_title: ['A'], service_description: ['d'], service_detail: [''], contact_heading: 'C', contact_email: 'owner@biz.test', layout_order: 'hero,about,services,testimonials,whyChoose,gallery,faq,blog,extraPages,hours,contact', ann_enabled: '1', ann_text: '', ann_linkUrl: 'javascript:alert(1)', ann_linkText: 'x' });
  const off = await (await fetch(`${BASE}/site/shine-pets`)).text();
  assert.doesNotMatch(off, /id="annBar"/, 'no message, no bar');
  assert.doesNotMatch(off, /class="price-grid/);
  // the editor offers all of it
  const edit = await (await c.get(`/sites/${siteId}/edit`)).text();
  assert.match(edit, /name="ann_text"/);
  assert.match(edit, /data-newblock="pricing"/);
  assert.match(edit, /id="tpl-block-pricing"/);
});

test('team, numbers, video, tabs, accordion, review carousel, floating text button, share picture', async () => {
  const c = makeClient();
  const none = ['', '', '', '', ''];
  const fields = {
    block_type: ['team', 'stats', 'video', 'tabs', 'accordion'],
    block_heading: ['Meet the team', 'By the numbers', 'See us at work', 'What we groom', 'Questions'],
    block_body: [
      'Jordan Lee | Lead groomer | Loves big dogs | https://img.example/jordan.jpg\nSam Ortiz | Bather\n | Nobody | no name\nEvil | x | y | javascript:alert(1)',
      '12 | Years in business\n1,500+ | Pets groomed',
      'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
      'Dogs | Baths, trims and full grooms\nCats | Gentle handling',
      'How long does it take? | About two hours.\nDo you take walk-ins? | Please book ahead.'
    ],
    block_image: none, block_side: ['auto', 'auto', 'auto', 'auto', 'auto'], block_buttonText: none, block_buttonUrl: none, block_edge: ['none', 'none', 'none', 'none', 'none'], block_bg: ['none', 'none', 'none', 'none', 'none'], block_place: ['bottom', 'bottom', 'bottom', 'bottom', 'bottom'],
    testimonials_display: 'carousel', testimonial_quote: ['Great groom!', 'Kind and quick.'], testimonial_author: ['Dana', 'Lee'], testimonial_rating: ['5', '4'], testimonial_date: ['', ''],
    contact_phone: '(407) 555-0100', contact_floatButton: 'whatsapp',
    seo_shareImage: 'https://img.example/share.jpg'
  };
  const { siteId } = await basicSite(c, 'extras@example.com', 'Extras Pets', fields);
  const home = await (await fetch(`${BASE}/site/extras-pets`)).text();
  // team
  assert.match(home, /<h3>Jordan Lee<\/h3>\s*<div class="team-role">Lead groomer<\/div>/);
  assert.match(home, /<img src="https:\/\/img\.example\/jordan\.jpg" alt="Jordan Lee"/);
  assert.match(home, /<span class="team-initial"[^>]*>S<\/span>\s*<h3>Sam Ortiz<\/h3>/, 'no photo -> initial');
  assert.doesNotMatch(home, /Nobody/);
  assert.doesNotMatch(home, /javascript:alert/);
  // numbers
  assert.match(home, /<div class="stat-num" data-count="1500" data-suffix="\+" data-comma="1">1,500\+<\/div>\s*<div class="stat-label">Pets groomed<\/div>/);
  // video: click-to-load embed, nothing from YouTube is loaded until then
  assert.match(home, /data-embed="https:\/\/www\.youtube-nocookie\.com\/embed\/dQw4w9WgXcQ\?autoplay=1&amp;rel=0"/);
  assert.doesNotMatch(home, /<iframe/);
  // tabs and accordion
  assert.match(home, /<button type="button" role="tab" class="tab-btn on" aria-selected="true">Dogs<\/button>/);
  assert.match(home, /<div class="tab-panel" role="tabpanel" data-off><p>Gentle handling<\/p>/);
  assert.match(home, /<details class="acc-item" open><summary>How long does it take\?<\/summary><p>About two hours\.<\/p>/);
  assert.match(home, /<details class="acc-item"><summary>Do you take walk-ins\?/);
  // review carousel (home strip and reviews page)
  const rev = await (await fetch(`${BASE}/site/extras-pets/testimonials`)).text();
  assert.match(rev, /<div class="strip t-carousel" tabindex="0">/);
  assert.match(rev, /strip-btn next/);
  // floating button
  assert.match(home, /<a class="float-contact wa" href="https:\/\/wa\.me\/14075550100" target="_blank" rel="noopener">/);
  // share picture
  assert.match(home, /<meta property="og:image" content="https:\/\/img\.example\/share\.jpg">/);

  // editor round-trip: everything is offered and survives another save of the same form
  const edit = await (await c.get(`/sites/${siteId}/edit`)).text();
  for (const t of ['team', 'stats', 'video', 'tabs', 'accordion']) { assert.match(edit, new RegExp(`data-newblock="${t}"`)); assert.match(edit, new RegExp(`id="tpl-block-${t}"`)); }
  assert.match(edit, /name="testimonials_display"[\s\S]*?<option value="carousel" selected>/);
  assert.match(edit, /name="contact_floatButton"[\s\S]*?<option value="whatsapp" selected>/);
  assert.match(edit, /name="seo_shareImage" value="https:\/\/img\.example\/share\.jpg"/);

  // switching things off / junk input
  const base = { name: 'Extras Pets', hero_headline: 'Hi', about_heading: 'About', about_body: 'x', services_heading: 'S', service_title: ['A'], service_description: ['d'], service_detail: [''], contact_heading: 'C', contact_email: 'owner@biz.test', layout_order: 'hero,about,services,testimonials,whyChoose,gallery,faq,blog,extraPages,hours,contact', testimonial_quote: ['Great groom!'], testimonial_author: ['Dana'], testimonial_rating: ['5'], testimonial_date: [''] };
  await c.post(`/sites/${siteId}/edit`, { ...base, testimonials_display: 'weird', contact_phone: '123', contact_floatButton: 'text', block_type: ['video', 'team'], block_heading: ['V', 'T'], block_body: ['https://evil.example/not-a-video', ''], block_image: ['', ''], block_side: ['auto', 'auto'], block_buttonText: ['', ''], block_buttonUrl: ['', ''], block_edge: ['none', 'none'], block_bg: ['none', 'none'], block_place: ['bottom', 'bottom'], seo_shareImage: 'javascript:alert(1)' });
  const off = await (await fetch(`${BASE}/site/extras-pets`)).text();
  assert.doesNotMatch(off, /class="strip t-carousel/, 'unknown display falls back to the grid');
  assert.doesNotMatch(off, /class="float-contact/, 'a too-short phone number gets no button');
  assert.doesNotMatch(off, /class="video-frame|<video/, 'a link that is not a video shows nothing');
  assert.doesNotMatch(off, /javascript:alert/);
  const t2 = await (await c.get(`/sites/${siteId}/edit`)).text();
  assert.match(t2, /name="seo_shareImage" value=""/);
  await c.post(`/sites/${siteId}/edit`, { ...base, contact_phone: '(407) 555-0100', contact_floatButton: 'text' });
  assert.match(await (await fetch(`${BASE}/site/extras-pets`)).text(), /<a class="float-contact" href="sms:\+14075550100">/);
});

test('blocks on any page, hero controls, button/corner/spacing controls, logo favicon', async () => {
  const c = makeClient();
  const none = ['', '', ''];
  const fields = {
    block_type: ['stats', 'pricing', 'accordion'], block_heading: ['Home numbers', 'Our prices', 'Contact FAQ'],
    block_body: ['10 | Years', 'Basic | $10 | One, Two', 'Q? | A.'],
    block_image: none, block_side: ['auto', 'auto', 'auto'], block_buttonText: none, block_buttonUrl: none, block_edge: ['none', 'none', 'none'], block_bg: ['none', 'none', 'none'],
    block_place: ['bottom', 'top', 'bottom'], block_page: ['home', 'services', 'contact'],
    hero_imageUrl: 'https://img.example/hero.jpg', hero_focalX: '20', hero_focalY: '80', hero_overlay: '60', hero_align: 'right', hero_videoUrl: 'https://cdn.example/loop.mp4',
    theme_buttonShape: 'square', theme_corners: 'round', theme_spacing: 'airy', theme_logoUrl: 'https://img.example/logo.png'
  };
  const { siteId } = await basicSite(c, 'feel@example.com', 'Feel Co', fields);
  const get = async (p) => (await fetch(`${BASE}/site/feel-co${p}`)).text();
  const home = await get(''), services = await get('/services'), contact = await get('/contact'), about = await get('/about');
  // blocks follow the page the owner chose
  assert.match(home, /Home numbers/); assert.doesNotMatch(home, /Our prices|Contact FAQ/);
  assert.match(services, /class="price-grid/); assert.doesNotMatch(services, /Home numbers/);
  assert.match(contact, /<details class="acc-item"/); assert.doesNotMatch(contact, /class="price-grid/);
  assert.doesNotMatch(about, /Home numbers|Our prices|Contact FAQ/);
  // 'top' blocks come before the page's own content, 'bottom' ones after
  assert.ok(services.indexOf('Our prices') < services.indexOf('id="services"'), 'top block precedes the section');
  assert.ok(contact.indexOf('id="contact"') < contact.indexOf('Contact FAQ'), 'bottom block follows the section');
  // hero controls
  assert.match(home, /id="hero" style="--fx: 20%; --fy: 80%; --ov-b: 0\.60; --ov-t: 0\.30;"/);
  assert.match(home, /<body class="[^"]*\bhero-ov\b[^"]*\bheroalign-right\b/);
  assert.match(home, /<video class="hero-video" autoplay muted loop playsinline preload="metadata" aria-hidden="true" tabindex="-1" src="https:\/\/cdn\.example\/loop\.mp4">/);
  assert.doesNotMatch(services, /<video class="hero-video"/, 'video is home-only');
  // feel controls and favicon
  assert.match(home, /<body class="[^"]*\bbtn-square\b[^"]*\bcorners-round\b[^"]*\bspace-airy\b/);
  assert.match(home, /<link rel="icon" href="https:\/\/img\.example\/logo\.png">/);
  assert.doesNotMatch(home, /rel="icon" type="image\/svg\+xml"/, "logo replaces the letter favicon");
  // editor round-trip
  const edit = await (await c.get(`/sites/${siteId}/edit`)).text();
  assert.match(edit, /name="hero_focalX" id="focalX" value="20"/);
  assert.match(edit, /name="hero_overlay">[\s\S]*?<option value="60" selected>/);
  assert.match(edit, /name="hero_align">[\s\S]*?<option value="right" selected>/);
  assert.match(edit, /name="theme_buttonShape">[\s\S]*?<option value="square" selected>/);
  assert.match(edit, /name="block_page"[\s\S]*?<option value="services" selected>/);
  assert.match(edit, /name="hero_videoUrl" value="https:\/\/cdn\.example\/loop\.mp4"/);
  // junk is dropped
  const base = { name: 'Feel Co', hero_headline: 'Hi', about_heading: 'About', about_body: 'x', services_heading: 'S', service_title: ['A'], service_description: ['d'], service_detail: [''], contact_heading: 'C', contact_email: 'owner@biz.test', layout_order: 'hero,about,services,testimonials,whyChoose,gallery,faq,blog,extraPages,hours,contact' };
  await c.post(`/sites/${siteId}/edit`, { ...base, hero_imageUrl: 'https://img.example/hero.jpg', hero_focalX: '900', hero_focalY: 'abc', hero_overlay: '99', hero_align: 'diagonal', hero_videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ', theme_buttonShape: 'star', theme_corners: 'x', theme_spacing: 'y', block_type: ['stats'], block_heading: ['Odd'], block_body: ['1 | a'], block_image: [''], block_side: ['auto'], block_buttonText: [''], block_buttonUrl: [''], block_edge: ['none'], block_bg: ['none'], block_place: ['bottom'], block_page: ['nowhere'] });
  const j = await get('');
  assert.match(j, /--fx: 100%; --fy: 50%;"/);
  assert.doesNotMatch(j, /<video class="hero-video"/);
  assert.doesNotMatch(j, /<body class="[^"]*(hero-ov|heroalign-|btn-star|corners-x|space-y)/);
  assert.match(j, /Odd/, 'an unknown page falls back to home');
  assert.match(j, /rel="icon" type="image\/svg\+xml"/, "no logo again -> letter favicon");
});

test('header options: sticky default, shrink, static, centered, transparent only on the home page', async () => {
  const c = makeClient();
  const { siteId } = await basicSite(c, 'hdr@example.com', 'Hdr Co', { theme_header: 'transparent', theme_headerLayout: 'centered' });
  const get = async (p) => (await fetch(`${BASE}/site/hdr-co${p}`)).text();
  const home = await get(''), about = await get('/about');
  assert.match(home, /<body class="[^"]*\bhdr-centered\b[^"]*\bhdr-transparent\b/);
  assert.doesNotMatch(about, /<body class="[^"]*\bhdr-transparent\b/, 'inner pages have no hero to float over');
  assert.match(about, /<body class="[^"]*\bhdr-centered\b/);
  const edit = await (await c.get(`/sites/${siteId}/edit`)).text();
  assert.match(edit, /name="theme_header">[\s\S]*?<option value="transparent" selected>/);
  assert.match(edit, /name="theme_headerLayout">[\s\S]*?<option value="centered" selected>/);
  await c.post(`/sites/${siteId}/edit`, { name: 'Hdr Co', theme_header: 'shrink', theme_headerLayout: 'zigzag', contact_acceptSubmissions: '1', layout_order: 'hero,about,services,testimonials,whyChoose,gallery,faq,blog,extraPages,hours,contact' });
  let h = await get('');
  assert.match(h, /<body class="[^"]*\bhdr-shrink\b/);
  assert.doesNotMatch(h, /<body class="[^"]*\bhdr-(centered|transparent)\b/, 'unknown layout values are ignored');
  await c.post(`/sites/${siteId}/edit`, { name: 'Hdr Co', theme_header: 'static', contact_acceptSubmissions: '1', layout_order: 'hero,about,services,testimonials,whyChoose,gallery,faq,blog,extraPages,hours,contact' });
  h = await get('');
  assert.match(h, /<body class="[^"]*\bhdr-static\b/);
  await c.post(`/sites/${siteId}/edit`, { name: 'Hdr Co', theme_header: 'bogus', contact_acceptSubmissions: '1', layout_order: 'hero,about,services,testimonials,whyChoose,gallery,faq,blog,extraPages,hours,contact' });
  h = await get('');
  assert.doesNotMatch(h, /<body class="[^"]*\bhdr-(static|shrink|transparent|centered)\b/);
});

test('custom contact form: build it, show it as steps, take answers, see them in leads, CSV and the alert email', async () => {
  const c = makeClient();
  const formRows = {
    cf_mode: 'custom', cf_title: 'Request an estimate', cf_intro: 'Quick questions first.', cf_submitText: 'Send it',
    cf_label: ['What do you need?', 'Property', 'Extras', 'Your name', 'Phone', 'Email', 'Photo of the spot'],
    cf_type: ['service', 'radio', 'checkbox', 'name', 'phone', 'email', 'photo'],
    cf_options: ['', 'House, Business', 'Gate, Dog, Stairs', '', '', '', ''],
    cf_step: ['1', '1', '2', '3', '3', '3', '2'], cf_required: ['1', '0', '0', '1', '1', '0', '0']
  };
  const { siteId } = await basicSite(c, 'cform@example.com', 'Cform Co', formRows);
  const page = await (await fetch(`${BASE}/site/cform-co/contact`)).text();
  assert.match(page, /<form[^>]*class="contact-form cform" data-steps="3"/);
  assert.match(page, /Request an estimate/); assert.match(page, /Quick questions first\./);
  assert.match(page, /class="cf-step" data-step="2"/);
  assert.match(page, /type="radio" name="cf_1" value="House"/);
  assert.match(page, /type="checkbox" name="cf_2" value="Stairs"/);
  assert.match(page, /name="cf_0"[\s\S]*?<option value="Roof Repair"/);
  assert.match(page, /type="file" name="photo"/);
  assert.match(page, />Send it</);
  assert.doesNotMatch(page, /name="message"/, 'the standard form is replaced');
  // service pages that carry the quote card use the custom form too
  // editor round-trip
  const edit = await (await c.get(`/sites/${siteId}/edit`)).text();
  assert.match(edit, /id="cfMode">\s*<option value="standard" >Standard form<\/option>\s*<option value="custom" selected>/);
  assert.match(edit, /name="cf_label" value="Property"/);
  assert.match(edit, /<option value="checkbox" selected>/);
  assert.match(edit, /id="cfPresets"/);
  // a visitor submits it
  const before = mailCount();
  const f = new FormData();
  f.append('cf_0', 'Roof Repair'); f.append('cf_1', 'House'); f.append('cf_2', 'Gate'); f.append('cf_2', 'Stairs'); f.append('cf_2', 'Bogus');
  f.append('cf_3', 'Dana Visitor'); f.append('cf_4', '407-555-9999'); f.append('cf_5', 'dana@example.com');
  const res = await fetch(`${BASE}/site/cform-co/contact`, { method: 'POST', body: f, redirect: 'manual' });
  assert.match(res.headers.get('location'), /thank-you$/);
  const leads = await (await c.get(`/sites/${siteId}/leads`)).text();
  assert.match(leads, /Dana Visitor/); assert.match(leads, /Roof Repair/);
  assert.match(leads, /<dt>Property<\/dt><dd>House<\/dd>/);
  assert.match(leads, /<dt>Extras<\/dt><dd>Gate, Stairs<\/dd>/, 'unknown checkbox values are dropped');
  const csv = await (await c.get(`/sites/${siteId}/leads.csv`)).text();
  assert.match(csv, /Answers/); assert.match(csv, /Property: House \| Extras: Gate, Stairs/);
  const mails = (await waitForMail(before + 1)).slice(before);
  assert.match(JSON.stringify(mails), /Property: House/);
  // required answers are enforced on the server too
  const bad = new FormData();
  bad.append('cf_0', 'Roof Repair'); bad.append('cf_5', 'x@y.co'); // no name, no phone
  const rej = await fetch(`${BASE}/site/cform-co/contact`, { method: 'POST', body: bad, redirect: 'manual' });
  assert.match(rej.headers.get('location'), /contact_error=1/);
  const after = await (await c.get(`/sites/${siteId}/leads`)).text();
  assert.equal((after.match(/id="lead-/g) || []).length, 1, 'rejected submission is not stored');
  // switching back to the standard form brings back the standard fields and keeps the questions saved
  await c.post(`/sites/${siteId}/edit`, { name: 'Cform Co', ...formRows, cf_mode: 'standard', contact_acceptSubmissions: '1', layout_order: 'hero,about,services,testimonials,whyChoose,gallery,faq,blog,extraPages,hours,contact' });
  const std = await (await fetch(`${BASE}/site/cform-co/contact`)).text();
  assert.match(std, /name="message"/); assert.doesNotMatch(std, /class="contact-form cform"/);
  assert.match(await (await c.get(`/sites/${siteId}/edit`)).text(), /name="cf_label" value="Property"/);
});

test('custom form on a one-step form shows no wizard controls; no services hides the service question', async () => {
  const c = makeClient();
  const { slug } = await basicSite(c, 'cform1@example.com', 'Onestep Co', {
    service_title: [''], service_description: [''], service_detail: [''],
    cf_mode: 'custom', cf_label: ['Service', 'Phone'], cf_type: ['service', 'phone'], cf_options: ['', ''], cf_step: ['1', '1'], cf_required: ['1', '1']
  });
  const page = await (await fetch(`${BASE}/site/${slug}/contact`)).text();
  assert.match(page, /data-steps="1"/);
  assert.doesNotMatch(page, /class="cf-progress"|class="btn cf-next"/);
  assert.doesNotMatch(page, /Select a service/);
  assert.match(page, /type="tel" name="cf_1"/);
});

test('pre-launch audit: placeholders, links, share picture, photo descriptions, form without a way to reply', async () => {
  const c = makeClient();
  const { siteId } = await basicSite(c, 'audit@example.com', 'Audit Co', {
    about_body: 'Lorem ipsum dolor sit amet', contact_phone: '4075', contact_email: 'info@example.com',
    hero_headline: 'H'.repeat(100), hero_ctaLink: '/pricing', hero_imageUrl: '',
    gallery_image: ['https://img.example/a.jpg', 'https://img.example/b.jpg'], gallery_alt: ['A dog in a tub', ''],
    seo_title: 'T'.repeat(70), seo_description: 'Short one',
    cf_mode: 'custom', cf_label: ['Question'], cf_type: ['text'], cf_options: [''], cf_step: ['1'], cf_required: ['0']
  });
  const items = (await (await c.get(`/sites/${siteId}/checklist`)).json()).items;
  const text = items.map(i => `${i.level}: ${i.text}`).join('\n');
  assert.match(text, /warn: Placeholder text is still on the site: .*Lorem ipsum.*example\.com/);
  assert.match(text, /warn: The phone number "4075" does not look like a full phone number/);
  assert.match(text, /warn: These links point to a page that does not exist or is hidden: \/pricing/);
  assert.match(text, /warn: Your custom contact form has no Phone or Email question/);
  assert.match(text, /tip: 1 of the 2 gallery photos has a description/);
  assert.match(text, /tip: The search title is 70 characters/);
  assert.match(text, /tip: The search description is short/);
  assert.match(text, /tip: No share picture and no hero photo/);
  assert.match(text, /tip: The home page headline is very long/);
  // fixing them clears them
  await c.post(`/sites/${siteId}/edit`, { name: 'Audit Co', about_body: 'We fix things.', contact_phone: '407-555-1234', contact_email: 'info@auditco.test', hero_headline: 'Fixed', hero_ctaLink: '/contact', hero_imageUrl: '/uploads/nothing-here.jpg', contact_acceptSubmissions: '1', layout_order: 'hero,about,services,testimonials,whyChoose,gallery,faq,blog,extraPages,hours,contact', gallery_image: ['https://img.example/a.jpg'], gallery_alt: ['A dog'], seo_title: 'Audit Co | Fixes', seo_description: 'D'.repeat(130) });
  const t2 = (await (await c.get(`/sites/${siteId}/checklist`)).json()).items.map(i => i.text).join('\n');
  assert.doesNotMatch(t2, /Placeholder text|phone number|do not exist|custom contact form|gallery photo|search title|search description is|headline is very long/);
  assert.match(t2, /missing from the uploads folder \(nothing-here\.jpg\)/, 'a photo that is not on disk is flagged');
});

test('gallery photo descriptions become alt text and survive a client edit', async (t) => {
  const c = makeClient();
  const { slug, siteId } = await basicSite(c, 'alts@example.com', 'Alts Co', {
    gallery_image: ['https://img.example/a.jpg', 'https://img.example/b.jpg'], gallery_alt: ['Groomed poodle', ''],
    about_imageUrl: 'https://img.example/team.jpg', about_imageAlt: 'The team outside the shop'
  });
  const gal = await (await fetch(`${BASE}/site/${slug}/gallery`)).text();
  assert.match(gal, /<img src="https:\/\/img\.example\/a\.jpg" alt="Groomed poodle"/);
  assert.match(gal, /<img src="https:\/\/img\.example\/b\.jpg" alt="Alts Co — photo"/, 'blank description falls back');
  const about = await (await fetch(`${BASE}/site/${slug}/about`)).text();
  assert.match(about, /alt="The team outside the shop"/);
  const edit = await (await c.get(`/sites/${siteId}/edit`)).text();
  assert.match(edit, /name="gallery_alt" value="Groomed poodle"/);
  assert.match(edit, /name="about_imageAlt" value="The team outside the shop"/);
});

test('speed pass: an uploaded photo is served with WebP copies, a srcset, a lazy gallery and a preloaded hero', async (t) => {
  let sharp;
  try { sharp = require('sharp'); } catch { return t.skip('sharp not installed'); }
  const c = makeClient();
  const { siteId, slug } = await basicSite(c, 'speed@example.com', 'Speed Co');
  const big = await sharp({ create: { width: 2800, height: 1800, channels: 3, background: { r: 20, g: 140, b: 90 } } }).jpeg({ quality: 95 }).toBuffer();
  const form = new FormData();
  form.append('image', new Blob([big], { type: 'image/jpeg' }), 'speed.jpg');
  const { url } = await (await c.post(`/sites/${siteId}/upload`, form)).json();
  const base = url.replace(/\.jpg$/, '');
  for (const w of [480, 960, 1440, 1920]) {
    const r = await fetch(`${BASE}${base}-${w}.webp`);
    assert.equal(r.status, 200, `${w}px copy is served`);
    assert.equal(r.headers.get('content-type'), 'image/webp');
  }
  await c.post(`/sites/${siteId}/edit`, { name: 'Speed Co', hero_imageUrl: url, gallery_image: [url, url], gallery_alt: ['one', 'two'], contact_acceptSubmissions: '1', layout_order: 'hero,about,services,testimonials,whyChoose,gallery,faq,blog,extraPages,hours,contact' });
  const home = await (await fetch(`${BASE}/site/${slug}`)).text();
  assert.ok(home.includes(`<link rel="preload" as="image" href="${base}-1920.webp" fetchpriority="high">`));
  assert.ok(home.includes(`data-hero-photo="${base}-1920.webp"`));
  const gal = await (await fetch(`${BASE}/site/${slug}/gallery`)).text();
  const tag = gal.match(/<img[^>]*alt="one"[^>]*>/)[0];
  assert.match(tag, /srcset="[^"]*-480\.webp 480w[^"]*-1920\.webp 1920w"/);
  assert.match(tag, /loading="lazy"/);
  assert.ok(tag.includes(`src="${url}"`), 'the original stays as the fallback');
  // the checklist does not call a processed photo large
  const items = (await (await c.get(`/sites/${siteId}/checklist`)).json()).items.map(i => i.text).join('\n');
  assert.doesNotMatch(items, /still large/);
  // static export bundles the copies the page refers to
  const zip = await c.get(`/sites/${siteId}/export`);
  const files = readZip(Buffer.from(await zip.arrayBuffer()));
  const names = Object.keys(files);
  assert.ok(names.includes(`uploads/${url.split('/').pop().replace('.jpg', '-1920.webp')}`), 'export includes the WebP copy');
  const html = files['gallery.html'].toString();
  assert.doesNotMatch(html, /["' ]\/uploads\//, 'all photo paths including srcset are relative');
});

// ---- tier 2: per-page SEO, redirects, 404, event counts, block library ----
const SAVE_BASE = { layout_order: 'hero,about,services,testimonials,whyChoose,gallery,faq,blog,extraPages,hours,contact', contact_acceptSubmissions: '1' };
const httpGetHost = (host, p) => new Promise((resolve, reject) => {
  require('node:http').get({ host: 'localhost', port: PORT, path: p, headers: { Host: host, 'user-agent': 'Mozilla/5.0' } }, (res) => {
    let body = ''; res.on('data', d => { body += d; }); res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, body }));
  }).on('error', reject);
});

test('per-page search settings: own title, description, share picture, hidden-from-Google, per-service title', async () => {
  const c = makeClient();
  const { siteId, slug } = await basicSite(c, 'pageseo@example.com', 'Pageseo Co', {
    seopage_about_title: 'About Our Orlando Roofers | Pageseo', seopage_about_description: 'Meet the crew.', seopage_about_shareImage: 'https://img.example/about.jpg',
    seopage_gallery_noindex: '1', service_detail: ['We fix roofs of all kinds in Orlando.'], service_seoTitle: ['Roof Repair in Orlando | Pageseo'], service_seoDescription: ['Leak and storm repair.'],
    gallery_image: ['https://img.example/a.jpg']
  });
  const about = await (await fetch(`${BASE}/site/${slug}/about`)).text();
  assert.match(about, /<title>About Our Orlando Roofers \| Pageseo<\/title>/);
  assert.match(about, /<meta name="description" content="Meet the crew\.">/);
  assert.match(about, /og:image" content="https:\/\/img\.example\/about\.jpg"/);
  assert.match(about, /<meta property="og:title" content="About Our Orlando Roofers \| Pageseo">/);
  assert.doesNotMatch(about, /<meta name="robots"/);
  const services = await (await fetch(`${BASE}/site/${slug}/services`)).text();
  assert.doesNotMatch(services, /About Our Orlando Roofers/, 'other pages keep their automatic title');
  const gallery = await (await fetch(`${BASE}/site/${slug}/gallery`)).text();
  assert.match(gallery, /<meta name="robots" content="noindex">/);
  const svc = await (await fetch(`${BASE}/site/${slug}/services/roof-repair`)).text();
  assert.match(svc, /<title>Roof Repair in Orlando \| Pageseo<\/title>/);
  assert.match(svc, /<meta name="description" content="Leak and storm repair\.">/);
  const sitemap = await (await fetch(`${BASE}/sitemap.xml`)).text();
  assert.match(sitemap, new RegExp(`/site/${slug}/about<`));
  assert.doesNotMatch(sitemap, new RegExp(`/site/${slug}/gallery<`), 'noindex pages are left out of the sitemap');
  const edit = await (await c.get(`/sites/${siteId}/edit`)).text();
  assert.match(edit, /name="seopage_about_title" value="About Our Orlando Roofers \| Pageseo"/);
  assert.match(edit, /name="seopage_gallery_noindex" value="1" style="width:auto;" checked/);
  assert.match(edit, /name="service_seoTitle" value="Roof Repair in Orlando \| Pageseo"/);
  // clearing a page removes the override
  await c.post(`/sites/${siteId}/edit`, { name: 'Pageseo Co', ...SAVE_BASE, about_body: 'x' });
  assert.doesNotMatch(await (await fetch(`${BASE}/site/${slug}/about`)).text(), /About Our Orlando Roofers/);
});

test('redirects: exact, folder wildcard, temporary, external, query kept; unpublished and own pages handled', async () => {
  const c = makeClient();
  const { siteId, slug } = await basicSite(c, 'redir@example.com', 'Redir Co', {
    rd_from: ['/about-us.html', '/old-blog/*', '/promo', '/gone', '/loop'],
    rd_to: ['/about', '/gallery/*', 'https://elsewhere.example/deal', '/services', '/loop'],
    rd_code: ['301', '302', '301', '301', '301']
  });
  const go = (p) => fetch(`${BASE}/site/${slug}${p}`, { redirect: 'manual' });
  let r = await go('/about-us.html?utm=1');
  assert.equal(r.status, 301); assert.equal(r.headers.get('location'), `/site/${slug}/about?utm=1`);
  r = await go('/About-US.html/');
  assert.equal(r.status, 301, 'case and trailing slash are forgiven');
  r = await go('/old-blog/2019/post');
  assert.equal(r.status, 302); assert.equal(r.headers.get('location'), `/site/${slug}/gallery/2019/post`);
  r = await go('/promo');
  assert.equal(r.headers.get('location'), 'https://elsewhere.example/deal');
  assert.equal((await go('/loop')).status, 404, 'a rule that points at itself is dropped');
  assert.equal((await go('/about')).status, 200, 'real pages are untouched');
  // POSTs are never redirected
  const f = new FormData(); f.append('name', 'x'); f.append('phone', '1');
  assert.notEqual((await fetch(`${BASE}/site/${slug}/contact`, { method: 'POST', body: f, redirect: 'manual' })).status, 301);
  // custom domain: same rules, paths without the /site/<name> prefix
  await c.post(`/sites/${siteId}/edit`, { name: 'Redir Co', ...SAVE_BASE, custom_domain: 'www.redir-example.test', rd_from: ['/about-us.html'], rd_to: ['/about'], rd_code: ['301'] });
  const cd = await httpGetHost('www.redir-example.test', '/about-us.html');
  assert.equal(cd.status, 301); assert.equal(cd.headers.location, '/about');
  // unpublished sites do not redirect
  await c.post(`/sites/${siteId}/publish`, { published: '0' });
  assert.equal((await go('/about-us.html')).status, 404);
  // the editor shows the rules
  const edit = await (await c.get(`/sites/${siteId}/edit`)).text();
  assert.match(edit, /name="rd_from" value="\/about-us\.html"/);
  // checklist warns about a rule that hides a live page and one that leads nowhere
  await c.post(`/sites/${siteId}/edit`, { name: 'Redir Co', ...SAVE_BASE, rd_from: ['/about', '/old'], rd_to: ['/services', '/nowhere'], rd_code: ['301', '301'] });
  const items = (await (await c.get(`/sites/${siteId}/checklist`)).json()).items.map(i => i.text).join('\n');
  assert.match(items, /redirect starts from \/about, which is a live page/);
  assert.match(items, /redirects lead to a page that does not exist or is hidden: \/old → \/nowhere/);
});

test('page not found: the site\'s own styled 404, with the owner\'s wording; plain 404 elsewhere', async () => {
  const c = makeClient();
  const { siteId, slug } = await basicSite(c, 'nf@example.com', 'Nf Co', { nf_heading: 'Oops, wrong turn', nf_text: 'Try the menu above.', theme_style: 'bold' });
  for (const p of ['/nope', '/services/not-a-service', '/a/b/c', '/blog/missing', '/book']) {
    const r = await fetch(`${BASE}/site/${slug}${p}`);
    assert.equal(r.status, 404, p);
    const html = await r.text();
    assert.match(html, /Oops, wrong turn/, p); assert.match(html, /Try the menu above\./);
    assert.match(html, /<nav class="site-nav"/, 'has the site header');
    assert.match(html, /<meta name="robots" content="noindex">/);
    assert.match(html, /<body class="style-bold/);
    assert.match(html, new RegExp(`href="/site/${slug}"`), 'links back to the site home');
  }
  // default wording
  await c.post(`/sites/${siteId}/edit`, { name: 'Nf Co', ...SAVE_BASE });
  assert.match(await (await fetch(`${BASE}/site/${slug}/nope`)).text(), /We can&#39;t find that page/);
  // not-found views are not counted as page views
  const rep = await (await c.get(`/sites/${siteId}/report`)).text();
  assert.doesNotMatch(rep, /notfound/);
  // custom domain: unknown path gets the site's 404; sitemap and robots still work
  await c.post(`/sites/${siteId}/edit`, { name: 'Nf Co', ...SAVE_BASE, custom_domain: 'www.nf-example.test' });
  const cd = await httpGetHost('www.nf-example.test', '/zzz/yyy');
  assert.equal(cd.status, 404); assert.match(cd.body, /We can&#39;t find that page/);
  assert.equal((await httpGetHost('www.nf-example.test', '/sitemap.xml')).status, 200);
  assert.equal((await httpGetHost('www.nf-example.test', '/robots.txt')).status, 200);
  // addresses that belong to no site and no app route get the plain page
  const plain = await fetch(`${BASE}/definitely/not/here`);
  assert.equal(plain.status, 404); assert.match(await plain.text(), /doesn't exist or hasn't been published/);
  const unknownSite = await fetch(`${BASE}/site/no-such-site/x`);
  assert.equal(unknownSite.status, 404);
});

test('visitor actions are counted without cookies and shown in the report', async () => {
  const c = makeClient();
  const { siteId, slug } = await basicSite(c, 'events@example.com', 'Events Co', { contact_phone: '407-555-1234' });
  const human = { 'user-agent': 'Mozilla/5.0 (iPhone) Safari', 'content-type': 'application/x-www-form-urlencoded' };
  const beacon = (e, p, headers = human, base = `/site/${slug}`) => fetch(`${BASE}${base}/e`, { method: 'POST', headers, body: new URLSearchParams({ e, p }).toString() });
  for (let i = 0; i < 3; i++) assert.equal((await beacon('call', 'home')).status, 204);
  await beacon('email', 'contact'); await beacon('text', 'home'); await beacon('cta', 'services/roof-repair');
  await beacon('call', 'home', { ...human, 'user-agent': 'Googlebot/2.1' });          // bots are ignored
  await beacon('hack<script>', 'home'); await beacon('call<b>', '<img>');             // unknown events ignored, paths sanitized
  assert.equal((await fetch(`${BASE}/site/no-such/e`, { method: 'POST', headers: human, body: 'e=call' })).status, 204);
  const f = new FormData(); f.append('name', 'Quote Person'); f.append('phone', '555-1');
  await fetch(`${BASE}/site/${slug}/contact`, { method: 'POST', body: f, redirect: 'manual' });
  const html = await (await c.get(`/sites/${siteId}/report`)).text();
  assert.match(html, /<div class="n">3<\/div><div class="l">Tapped the phone number/);
  assert.match(html, /<div class="n">1<\/div><div class="l">Tapped the email address/);
  assert.match(html, /<div class="n">1<\/div><div class="l">Tapped Text \/ WhatsApp/);
  assert.match(html, /<div class="n">1<\/div><div class="l">Clicked a "Contact \/ Book" button/);
  assert.match(html, /Rates show up once there are at least 20 page views/);
  // the live page carries the counting script; the owner's preview and static export do not
  const live = await (await fetch(`${BASE}/site/${slug}`)).text();
  assert.match(live, new RegExp(`sendBeacon\\('/site/${slug}/e'`));
  const prev = await (await c.get(`/sites/${siteId}/preview`)).text();
  assert.doesNotMatch(prev, /sendBeacon/);
  const files = readZip(Buffer.from(await (await c.get(`/sites/${siteId}/export`)).arrayBuffer()));
  assert.doesNotMatch(files['index.html'].toString(), /sendBeacon/);
  // custom domain endpoint
  await c.post(`/sites/${siteId}/edit`, { name: 'Events Co', ...SAVE_BASE, contact_phone: '407-555-1234', custom_domain: 'www.events-example.test' });
  const cdPost = await new Promise((resolve, reject) => {
    const rq = require('node:http').request({ host: 'localhost', port: PORT, path: '/e', method: 'POST', headers: { Host: 'www.events-example.test', 'user-agent': 'Mozilla/5.0', 'content-type': 'application/x-www-form-urlencoded' } }, (res) => { res.resume(); res.on('end', () => resolve(res.statusCode)); });
    rq.on('error', reject); rq.end('e=call&p=home');
  });
  assert.equal(cdPost, 204);
  assert.match(await (await c.get(`/sites/${siteId}/report`)).text(), /<div class="n">4<\/div><div class="l">Tapped the phone number/);
});

test('block library: save a block, reuse it on another site, private to its owner', async () => {
  const c = makeClient();
  const a = await basicSite(c, 'lib@example.com', 'Lib One', {
    block_type: ['pricing'], block_heading: ['Our prices'], block_body: ['Bath | $40 | Wash, Dry\n* Groom | $70 | Bath, Cut'], block_image: [''], block_side: ['auto'],
    block_buttonText: ['Book'], block_buttonUrl: ['/book'], block_edge: ['wave'], block_bg: ['tint'], block_place: ['top'], block_page: ['services']
  });
  const saveBody = { name: 'Price table', block_type: 'pricing', block_heading: 'Our prices', block_body: 'Bath | $40 | Wash, Dry\n* Groom | $70 | Bath, Cut', block_image: '', block_side: 'auto', block_buttonText: 'Book', block_buttonUrl: '/book', block_edge: 'wave', block_bg: 'tint', block_place: 'top', block_page: 'services' };
  const saved = await (await fetch(`${BASE}/library/blocks`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(saveBody), redirect: 'manual' })).status;
  assert.equal(saved, 302, 'must be signed in');
  const post = async (client, body) => (await client.post('/library/blocks', body));
  let res = await post(c, saveBody);
  const j = await res.json();
  assert.equal(j.ok, true); assert.equal(j.name, 'Price table'); assert.equal(j.block.type, 'pricing'); assert.equal(j.block.edge, 'wave');
  // invalid input is rejected or cleaned
  assert.equal((await post(c, { name: 'x', block_type: 'bogus', block_heading: 'h' })).status, 400);
  assert.equal((await post(c, { name: 'x', block_type: 'cta', block_heading: '', block_body: '' })).status, 400, 'an empty block is not saved');
  const cleaned = await (await post(c, { name: 'Odd', block_type: 'cta', block_heading: 'Hi', block_body: 'b', block_buttonUrl: 'javascript:alert(1)', block_bg: 'neon', block_page: 'nowhere' })).json();
  assert.equal(cleaned.block.buttonUrl, ''); assert.equal(cleaned.block.bg, 'none'); assert.equal(cleaned.block.page, 'home');
  // a second site of the same user can insert it; the editor lists it and embeds the data
  const b = await basicSite(c, 'lib@example.com', 'Lib Two');
  const edit = await (await c.get(`/sites/${b.siteId}/edit`)).text();
  assert.match(edit, /id="libSelect">[\s\S]*?Price table \(pricing\)/);
  assert.match(edit, /id="libData">\[.*"name":"Price table"/);
  assert.match(edit, /data-block="save"/);
  // someone else does not see it and cannot delete it
  const other = makeClient();
  await other.post('/signup', { email: 'lib-other@example.com', password: 'password1' });
  const oc = await other.post('/sites', { name: 'Other Lib' });
  const oid = oc.headers.get('location').match(/\/sites\/(\d+)\//)[1];
  assert.doesNotMatch(await (await other.get(`/sites/${oid}/edit`)).text(), /Price table/);
  assert.equal((await (await other.post(`/library/blocks/${j.id}/delete`)).json()).ok, false);
  // owner deletes it
  assert.equal((await (await c.post(`/library/blocks/${j.id}/delete`)).json()).ok, true);
  assert.doesNotMatch(await (await c.get(`/sites/${b.siteId}/edit`)).text(), /Price table/);
  assert.equal(a.siteId !== b.siteId, true);
});

test('privacy + terms pages: off by default, derived from what the site does, linked, in sitemap and export', async () => {
  const c = makeClient();
  const { siteId } = await basicSite(c, 'lg@example.com', 'Legal Co', { gaId: '', pixel: '' });
  const order = 'hero,about,services,testimonials,whyChoose,gallery,faq,blog,extraPages,hours,contact';
  assert.equal((await fetch(`${BASE}/site/legal-co/privacy`)).status, 404, 'off by default');
  assert.doesNotMatch(await (await fetch(`${BASE}/site/legal-co`)).text(), /Privacy Policy/);
  await c.post(`/sites/${siteId}/edit`, { name: 'Legal Co', legal_enabled: '1', legal_state: 'Florida', legal_email: 'privacy@legalco.test', contact_acceptSubmissions: '1', layout_order: order });
  const p = await (await fetch(`${BASE}/site/legal-co/privacy`)).text();
  assert.match(p, /<h1>Privacy Policy<\/h1>/);
  assert.match(p, /send us a message or request through a form/);
  assert.match(p, /privacy@legalco\.test/);
  const body = p.slice(p.indexOf('<h1>Privacy Policy'), p.indexOf('legal-other'));
  assert.doesNotMatch(body, /Google Analytics|Meta Pixel|photo you choose to attach|When you request a booking/, 'only what applies');
  const t = await (await fetch(`${BASE}/site/legal-co/terms`)).text();
  assert.match(t, /laws of the State of Florida/);
  assert.match(await (await fetch(`${BASE}/site/legal-co`)).text(), /href="\/site\/legal-co\/privacy">Privacy Policy<\/a><a href="\/site\/legal-co\/terms"/);
  assert.match(await (await fetch(`${BASE}/sitemap.xml`)).text(), /legal-co\/privacy/);
  // analytics is mentioned once tracking IDs are set
  await c.post(`/sites/${siteId}/edit`, { name: 'Legal Co', legal_enabled: '1', meta_gaId: 'G-ABC123XYZ', contact_acceptSubmissions: '1', layout_order: order });
  const p2 = await (await fetch(`${BASE}/site/legal-co/privacy`)).text();
  assert.match(p2.slice(p2.indexOf('<h1>Privacy Policy')), /Google Analytics/);
  assert.match(p2, /only after you click Accept/);
  // notice bar on every page when chosen
  await c.post(`/sites/${siteId}/edit`, { name: 'Legal Co', legal_enabled: '1', legal_banner: 'always', contact_acceptSubmissions: '1', layout_order: order });
  assert.match(await (await fetch(`${BASE}/site/legal-co/about`)).text(), /id="cookieBar"/);
  // export contains the pages
  const zip = readZip(Buffer.from(await (await c.get(`/sites/${siteId}/export`)).arrayBuffer()));
  assert.ok(zip['privacy.html'] && zip['terms.html']);
  assert.match(zip['index.html'].toString(), /href="privacy\.html"/);
});

test('backups: snapshot, retention, admin-only pages, site file export/import, template copy', async () => {
  const fsx = require('node:fs'), pathx = require('node:path'), osx = require('node:os'), zlibx = require('node:zlib');
  const backups = require('../backups');
  const Database = require('better-sqlite3');
  const dir = fsx.mkdtempSync(pathx.join(osx.tmpdir(), 'bk-'));
  const tmpDb = new Database(pathx.join(dir, 'src.db'));
  tmpDb.exec('CREATE TABLE t (a)'); tmpDb.prepare('INSERT INTO t VALUES (1)').run();
  const bdir = pathx.join(dir, 'out');
  const n1 = await backups.run(tmpDb, bdir, 2, new Date(2026, 0, 1, 9, 0));
  const n2 = await backups.run(tmpDb, bdir, 2, new Date(2026, 0, 2, 9, 0));
  const n3 = await backups.run(tmpDb, bdir, 2, new Date(2026, 0, 3, 9, 0));
  assert.deepEqual(backups.list(bdir).map(f => f.name), [n3, n2], 'oldest is dropped');
  assert.ok(!fsx.readdirSync(bdir).some(n => n.startsWith('.tmp') || n.endsWith('.part')), 'no temp files left');
  const raw = zlibx.gunzipSync(fsx.readFileSync(pathx.join(bdir, n3)));
  assert.equal(raw.slice(0, 15).toString(), 'SQLite format 3');
  assert.equal(backups.hasToday(bdir, new Date(2026, 0, 3, 20, 0)), true);
  assert.equal(backups.hasToday(bdir, new Date(2026, 0, 4, 1, 0)), false);
  assert.equal(backups.pathFor(bdir, '../../etc/passwd'), null);
  tmpDb.close();

  // admin pages: alice (first account) is the admin
  const admin = makeClient();
  await admin.post('/login', { email: 'alice@example.com', password: 'password1' });
  assert.equal((await admin.get('/admin/backups')).status, 200);
  const runRes = await admin.post('/admin/backups/run', {});
  assert.equal(runRes.status, 302);
  const page = await (await admin.get('/admin/backups?done=1')).text();
  const nm = /href="\/admin\/backups\/(sitegen-[\d-]+\.db\.gz)"/.exec(page);
  assert.ok(nm, 'the new backup is listed');
  const dl = await admin.get(`/admin/backups/${nm[1]}`);
  assert.equal(dl.status, 200);
  assert.equal(Buffer.from(zlibx.gunzipSync(Buffer.from(await dl.arrayBuffer()))).slice(0, 15).toString(), 'SQLite format 3');
  assert.equal((await admin.get('/admin/backups/..%2f..%2fpackage.json')).status, 404);

  const owner = makeClient();
  const { siteId } = await basicSite(owner, 'bkowner@example.com', 'Bk Co', {});
  assert.equal((await owner.get('/admin/backups')).status, 404);
  assert.equal((await owner.post('/admin/backups/run', {})).status, 404);

  // site file round trip
  const exp = await (await owner.get(`/sites/${siteId}/export.json`)).json();
  assert.equal(exp.format, 'sitegen-site');
  exp.sections.hero.ctaLink = 'javascript:alert(1)';
  const fd = new FormData();
  fd.append('sitefile', new Blob([JSON.stringify(exp)], { type: 'application/json' }), 'x.json');
  const imp = await owner.post('/sites/import-file', fd);
  assert.equal(imp.status, 302);
  const id2 = /\/sites\/(\d+)\/edit/.exec(imp.headers.get('location'))[1];
  const rawDb = new Database(TEST_DB);
  const row = rawDb.prepare('SELECT * FROM sites WHERE id = ?').get(id2);
  assert.equal(row.published, 0);
  assert.equal(JSON.parse(row.sections).hero.ctaLink, '', 'script links are dropped on import');
  const bad = new FormData(); bad.append('sitefile', new Blob(['{"nope":1}']), 'y.json');
  assert.match(await (await owner.post('/sites/import-file', bad)).text(), /not a SiteGen site file/);

  // template copy clears client-specific details, plain duplicate keeps them
  await owner.post(`/sites/${siteId}/edit`, { name: 'Bk Co', service_title: ['Roof Repair'], service_description: ['Fix leaks'], contact_phone: '(407) 555-0142', contact_email: 'a@bk.test', meta_gaId: 'G-ABC123XYZ9', contact_acceptSubmissions: '1', layout_order: 'hero,about,services,testimonials,whyChoose,gallery,faq,blog,extraPages,hours,contact' });
  const dup = await owner.post(`/sites/${siteId}/duplicate`, { mode: 'template' });
  const tid = /\/sites\/(\d+)\/edit/.exec(dup.headers.get('location'))[1];
  const t = JSON.parse(rawDb.prepare('SELECT sections FROM sites WHERE id = ?').get(tid).sections);
  assert.equal(t.contact.phone, ''); assert.equal(t.contact.email, ''); assert.equal(t.meta.gaId, '');
  assert.ok(t.services.items.length > 0, 'wording is kept');
  const dup2 = await owner.post(`/sites/${siteId}/duplicate`, {});
  const d2 = JSON.parse(rawDb.prepare('SELECT sections FROM sites WHERE id = ?').get(/\/sites\/(\d+)\/edit/.exec(dup2.headers.get('location'))[1]).sections);
  assert.equal(d2.contact.phone, '(407) 555-0142');
  rawDb.close();
});

test('client logins: invite, set password, edit basics only, separate from owner, revoke', async () => {
  const owner = makeClient();
  const { siteId } = await basicSite(owner, 'cuowner@example.com', 'Cu Co', {});
  const before = mailCount();
  const r = await owner.post(`/sites/${siteId}/client-users`, { email: 'Pat@Client.test', name: 'Pat' });
  assert.equal(r.status, 302);
  let edit = await (await owner.get(`/sites/${siteId}/edit?clientuser=invited`)).text();
  const link = /\/client-invite\/([A-Za-z0-9_-]{20,})/.exec(edit);
  assert.ok(link, 'invite link shown once');
  assert.doesNotMatch(await (await owner.get(`/sites/${siteId}/edit?clientuser=invited`)).text(), /client-invite\/[A-Za-z0-9_-]{20}/, 'not shown twice');
  await waitForMail(before + 1);
  const tok = link[1];
  // invite page
  const page = await fetch(`${BASE}/client-invite/${tok}`);
  assert.equal(page.status, 200);
  const cp = makeClient();
  assert.match(await (await cp.get(`/client-invite/${tok}`)).text(), /pat@client\.test/);
  assert.match(await (await cp.post(`/client-invite/${tok}`, { password: 'short', password2: 'short' })).text(), /at least 8/);
  assert.match(await (await cp.post(`/client-invite/${tok}`, { password: 'longenough1', password2: 'different11' })).text(), /do not match/);
  const done = await cp.post(`/client-invite/${tok}`, { password: 'longenough1', password2: 'longenough1' });
  assert.equal(done.status, 302);
  assert.equal(done.headers.get('location'), `/portal/${siteId}`);
  assert.equal((await fetch(`${BASE}/client-invite/${tok}`)).status, 404, 'invite works once');
  // portal edit
  const portal = await (await cp.get(`/portal/${siteId}`)).text();
  assert.match(portal, /action="\/portal\/\d+"/);
  assert.match(portal, /Log out/);
  const save = await cp.post(`/portal/${siteId}`, { hero_headline: 'Edited by Pat', about_body: 'New about' });
  assert.equal(save.status, 302);
  assert.match(await (await fetch(`${BASE}/site/cu-co`)).text(), /Edited by Pat/);
  // cannot reach owner pages, or another site
  assert.equal((await cp.get(`/sites/${siteId}/edit`)).status, 302);
  assert.match((await cp.get(`/sites/${siteId}/edit`)).headers.get('location'), /login/);
  assert.equal((await cp.get(`/portal/${siteId + 999}`)).headers.get('location'), '/client-login');
  assert.equal((await cp.get(`/portal/${siteId}/report`)).status, 200);
  // login / logout
  const c2 = makeClient();
  assert.equal((await c2.post('/client-login', { email: 'pat@client.test', password: 'wrongwrong' })).status, 401);
  const ok = await c2.post('/client-login', { email: 'pat@client.test', password: 'longenough1' });
  assert.equal(ok.headers.get('location'), `/portal/${siteId}`);
  await c2.post('/client-logout', {});
  assert.equal((await c2.get(`/portal/${siteId}`)).headers.get('location'), '/client-login');
  // other owners can't manage this site's logins
  const other = makeClient();
  await basicSite(other, 'cuother@example.com', 'Cu Other', {});
  assert.equal((await other.post(`/sites/${siteId}/client-users`, { email: 'x@y.test' })).status, 404);
  // reset password signs the old one out; removing deletes access
  const Database = require('better-sqlite3');
  const rawDb = new Database(TEST_DB);
  const uid = rawDb.prepare('SELECT id FROM client_users WHERE site_id = ?').get(siteId).id;
  await owner.post(`/sites/${siteId}/client-users/${uid}/invite`, {});
  assert.equal((await makeClient().post('/client-login', { email: 'pat@client.test', password: 'longenough1' })).status, 401);
  await owner.post(`/sites/${siteId}/client-users/${uid}/delete`, {});
  assert.equal(rawDb.prepare('SELECT COUNT(*) n FROM client_users WHERE site_id = ?').get(siteId).n, 0);
  rawDb.close();
  assert.equal((await cp.get(`/portal/${siteId}`)).headers.get('location'), '/client-login', 'removed user is out');
});

test('lead pipeline: follow-up date, due filter, quoted status, CSV; automatic follow-ups send, stop on contact, opt out', async () => {
  const Database = require('better-sqlite3');
  const c = makeClient();
  const order = 'hero,about,services,testimonials,whyChoose,gallery,faq,blog,extraPages,hours,contact';
  const { siteId } = await basicSite(c, 'pipe@example.com', 'Pipe Co', { contact_email: 'owner@pipeco.test', fu_enabled: '1', fu_hours: ['1', '48', ''], fu_text: ['Hi [name], [business] here[phone].', 'Second try, [name].', ''] });
  const raw = new Database(TEST_DB);
  const lead = async (name, email) => {
    const fd = new URLSearchParams({ name, email, message: 'Need a quote' });
    await fetch(`${BASE}/site/pipe-co/contact`, { method: 'POST', body: fd, redirect: 'manual' });
    return raw.prepare('SELECT * FROM contact_submissions WHERE site_id = ? AND name = ? ORDER BY id DESC').get(siteId, name);
  };
  const a = await lead('Ann Lee', 'ann@x.test'), b = await lead('Bob Ray', 'bob@x.test'), nomail = await lead('Cy NoMail', '');
  const q = (id) => raw.prepare('SELECT * FROM followup_queue WHERE lead_id = ? ORDER BY step').all(id);
  assert.equal(q(a.id).length, 2, 'two steps queued');
  assert.equal(q(nomail.id).length, 0, 'no email, nothing queued');
  // pipeline UI
  const yesterday = new Date(Date.now() - 2 * 86400000).toISOString().slice(0, 10);
  const save = await c.post(`/sites/${siteId}/leads/${b.id}`, { status: 'quoted', notes: 'quoted 4200', follow_up_at: yesterday });
  assert.equal(save.status, 302);
  assert.equal(q(b.id).every(r => r.canceled === 1), true, 'owner contact cancels automatic emails');
  const html = await (await c.get(`/sites/${siteId}/leads`)).text();
  assert.match(html, /Follow up today/); assert.match(html, /Quoted/);
  const due = await (await c.get(`/sites/${siteId}/leads?status=due`)).text();
  assert.match(due, /Bob Ray/); assert.doesNotMatch(due, /Ann Lee/);
  await c.post(`/sites/${siteId}/leads/${b.id}`, { status: 'quoted', follow_up_at: 'junk' });
  assert.equal(raw.prepare('SELECT follow_up_at FROM contact_submissions WHERE id = ?').get(b.id).follow_up_at, '', 'bad dates are dropped');
  await c.post(`/sites/${siteId}/leads/${b.id}`, { status: 'quoted', notes: 'x', follow_up_at: yesterday });
  assert.match(await (await c.get(`/sites/${siteId}/leads.csv`)).text(), /Follow up/);
  // sending: age the queue, run the job
  const before = mailCount();
  await fetch(`${BASE}/__test/age-queue`, { method: 'POST', headers: { 'x-test-key': 'suite' } });
  const run = await (await fetch(`${BASE}/__test/run-jobs`, { method: 'POST', headers: { 'x-test-key': 'suite' } })).json();
  assert.equal(run.followUps, 2, 'only the still-new lead gets both steps');
  const mails = await waitForMail(before + 3); // two follow-ups + the reminder digest
  const fu = mails.slice(before).filter(m => /ann@x\.test/.test(JSON.stringify(m.to)));
  assert.equal(fu.length, 2);
  assert.match(fu[0].text, /Hi Ann, Pipe Co here/);
  const tok = /unsubscribe\/([A-Za-z0-9_-]{10,})/.exec(fu[0].text)[1];
  assert.ok(mails.slice(before).some(m => /Follow up today: 1 lead/.test(m.subject) && /Bob Ray/.test(m.text)), 'reminder digest');
  // running again sends nothing new
  assert.equal((await (await fetch(`${BASE}/__test/run-jobs`, { method: 'POST', headers: { 'x-test-key': 'suite' } })).json()).followUps, 0);
  // opt-out
  const d = await lead('Dee Opt', 'dee@x.test');
  assert.equal(q(d.id).length, 2);
  const dtok = raw.prepare('SELECT optout_token FROM contact_submissions WHERE id = ?').get(d.id).optout_token;
  assert.match(await (await fetch(`${BASE}/unsubscribe/${dtok}`)).text(), /Stop these emails/);
  assert.match(await (await fetch(`${BASE}/unsubscribe/${dtok}`, { method: 'POST' })).text(), /unsubscribed/);
  assert.equal(q(d.id).every(r => r.canceled === 1), true);
  assert.equal((await fetch(`${BASE}/__test/run-jobs`, { method: 'POST' })).status, 404, 'test hook needs the key');
  void tok; raw.close();
});

test('chat assistant: off by default, AI answer, daily cap falls back, lead capture, no widget in preview or export', async () => {
  const Database = require('better-sqlite3');
  const c = makeClient();
  const order = 'hero,about,services,testimonials,whyChoose,gallery,faq,blog,extraPages,hours,contact';
  const { siteId } = await basicSite(c, 'chat@example.com', 'Chat Co', { contact_email: 'owner@chatco.test' });
  const post = (p, body) => fetch(`${BASE}/site/chat-co${p}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
  assert.equal((await post('/chat', { messages: [{ role: 'user', content: 'hi' }] })).status, 404, 'off by default');
  assert.doesNotMatch(await (await fetch(`${BASE}/site/chat-co`)).text(), /id="chatFab"/);
  const base = { name: 'Chat Co', service_title: ['Roof Repair'], service_description: ['Fix leaks'], faq_question: ['Do you repair tile roofs?'], faq_answer: ['Yes, we repair tile and shingle roofs.'], contact_acceptSubmissions: '1', chat_enabled: '1', chat_greeting: 'Welcome in', layout_order: order };
  await c.post(`/sites/${siteId}/edit`, { ...base, chat_dailyCap: '10' });
  const home = await (await fetch(`${BASE}/site/chat-co`)).text();
  assert.match(home, /id="chatFab"/); assert.match(home, /Welcome in/); assert.match(home, /Automated assistant/);
  assert.doesNotMatch(await (await c.get(`/sites/${siteId}/preview`)).text(), /id="chatFab"/, 'not in the editor preview');
  const r = await (await post('/chat', { messages: [{ role: 'user', content: 'What services do you offer?' }] })).json();
  assert.equal(r.ai, true); assert.match(r.reply, /^AI says: What services/);
  assert.equal((await post('/chat', { messages: [] })).status, 400);
  const last = aiRequests[aiRequests.length - 1];
  assert.match(last.body.system, /Roof Repair: Fix leaks/); assert.match(last.body.system, /Do you repair tile roofs/);
  assert.equal(last.headers['x-api-key'], 'test-anthropic-key');
  // cap: 10 per day, then the FAQ answers
  for (let i = 0; i < 12; i++) await post('/chat', { messages: [{ role: 'user', content: 'ping' }] });
  const capped = await (await post('/chat', { messages: [{ role: 'user', content: 'do you repair tile roofs?' }] })).json();
  assert.equal(capped.ai, false); assert.match(capped.reply, /tile and shingle/);
  // lead capture
  const raw = new Database(TEST_DB);
  const bad = await post('/chat/lead', { name: '', phone: '', email: '' });
  assert.equal(bad.status, 400);
  const ok = await (await post('/chat/lead', { name: 'Chat Visitor', phone: '407-555-0111', message: 'Call me', transcript: [{ role: 'user', content: 'How much?' }, { role: 'assistant', content: "I don't have that detail." }, { role: 'user', content: 'ok' }] })).json();
  assert.equal(ok.ok, true);
  const lead = raw.prepare("SELECT * FROM contact_submissions WHERE site_id = ? AND source = 'chat'").get(siteId);
  assert.match(lead.message, /Call me/); assert.match(lead.message, /Visitor: How much\?/);
  assert.equal(JSON.stringify(await (await post('/chat/lead', { name: 'Bot', website: 'x' })).json()), '{"ok":true}');
  assert.equal(raw.prepare("SELECT COUNT(*) n FROM contact_submissions WHERE site_id = ? AND source = 'chat'").get(siteId).n, 1, 'honeypot stores nothing');
  assert.match(await (await c.get(`/sites/${siteId}/leads`)).text(), /From chat/);
  // export has no widget; policy mentions the chat when pages are on
  const zip = readZip(Buffer.from(await (await c.get(`/sites/${siteId}/export`)).arrayBuffer()));
  assert.doesNotMatch(zip['index.html'].toString(), /chatFab/);
  await c.post(`/sites/${siteId}/edit`, { ...base, legal_enabled: '1' });
  assert.match(await (await fetch(`${BASE}/site/chat-co/privacy`)).text(), /chat assistant/);
  raw.close();
});

test('google reviews: place id, pull, badge and reviews shown as returned, escaped, errors explained', async () => {
  const c = makeClient();
  const order = 'hero,about,services,testimonials,whyChoose,gallery,faq,blog,extraPages,hours,contact';
  const { siteId } = await basicSite(c, 'greview@example.com', 'G Co', {});
  const save = (extra) => c.post(`/sites/${siteId}/edit`, { name: 'G Co', service_title: ['Roof Repair'], service_description: ['Fix'], contact_acceptSubmissions: '1', layout_order: order, ...extra });
  // nothing configured: no badge, no testimonials page
  assert.doesNotMatch(await (await fetch(`${BASE}/site/g-co`)).text(), /class="g-badge"/);
  await save({ testimonials_googlePlaceId: 'places/ChIJtestplace12345', testimonials_googleMode: 'reviews' });
  const r = await c.post(`/sites/${siteId}/google-reviews/refresh`, {});
  assert.match(r.headers.get('location'), /google=ok/);
  assert.equal(googleRequests.at(-1).headers['x-goog-api-key'], 'test-google-key');
  assert.match(googleRequests.at(-1).headers['x-goog-fieldmask'], /reviews/);
  const page = await (await fetch(`${BASE}/site/g-co/testimonials`)).text();
  assert.match(page, /4\.7/); assert.match(page, /128 Google reviews/); assert.match(page, /Sam R/); assert.match(page, /a month ago/);
  assert.match(page, /Okay service, a bit slow/, 'lower ratings are shown too, nothing is picked');
  assert.doesNotMatch(page, /<b>Great<\/b>/, 'review text is escaped');
  assert.match(page, /Reviews from Google/);
  assert.doesNotMatch(await (await c.get(`/sites/${siteId}/preview/testimonials`)).text(), /class="g-card"/, 'preview never calls Google');
  // badge only
  await save({ testimonials_googlePlaceId: 'ChIJtestplace12345', testimonials_googleMode: 'badge' });
  const home = await (await fetch(`${BASE}/site/g-co`)).text();
  assert.doesNotMatch(home, /class="g-card"/);
  // a bad id is explained and shows nothing
  await save({ testimonials_googlePlaceId: 'ChIJnotarealplace999', testimonials_googleMode: 'reviews' });
  assert.match((await c.post(`/sites/${siteId}/google-reviews/refresh`, {})).headers.get('location'), /google=fail/);
  assert.match(await (await c.get(`/sites/${siteId}/edit?google=fail`)).text(), /could not find that Place ID/);
  assert.doesNotMatch(await (await fetch(`${BASE}/site/g-co/testimonials`)).text(), /class="g-card"/);
  await save({ testimonials_googlePlaceId: 'bad id!', testimonials_googleMode: 'reviews' });
  assert.match((await c.post(`/sites/${siteId}/google-reviews/refresh`, {})).headers.get('location'), /google=noid/);
});

test('estimate calculator: page, live-math config, server-side price, lead with choices, checklist', async () => {
  const Database = require('better-sqlite3');
  const c = makeClient();
  const order = 'hero,about,services,testimonials,whyChoose,gallery,faq,blog,extraPages,hours,contact';
  const { siteId } = await basicSite(c, 'calc@example.com', 'Calc Co', { contact_email: 'owner@calc.test' });
  const save = (extra) => c.post(`/sites/${siteId}/edit`, { name: 'Calc Co', service_title: ['Cleaning'], service_description: ['Homes'], contact_acceptSubmissions: '1', layout_order: order, ...extra });
  assert.equal((await fetch(`${BASE}/site/calc-co/estimate`)).status, 404, 'off by default');
  const cfg = { calc_enabled: '1', calc_heading: 'Cleaning estimate', calc_showPrice: 'yes', calc_basePrice: '50', calc_spread: '20', calc_minimum: '0',
    calc_label: ['Size', 'Bathrooms', 'Oven'], calc_type: ['select', 'number', 'checkbox'],
    calc_options: ['Small | 10\nBig | 40', '', ''], calc_price: ['', '15', '30'], calc_unit: ['', 'baths', ''], calc_min: ['', '1', ''], calc_max: ['', '5', ''], calc_required: ['yes', 'yes', 'no'] };
  await save(cfg);
  const page = await (await fetch(`${BASE}/site/calc-co/estimate`)).text();
  assert.match(page, /Cleaning estimate/); assert.match(page, /name="ce_0"/); assert.match(page, /Big/);
  assert.match(await (await fetch(`${BASE}/site/calc-co`)).text(), /href="\/site\/calc-co\/estimate"/, 'in the menu');
  assert.match(await (await fetch(`${BASE}/sitemap.xml`)).text(), /calc-co\/estimate/);
  assert.match(page, /not a firm quote/);
  // server computes the price; tampering is ignored
  const raw = new Database(TEST_DB);
  const send = (body) => fetch(`${BASE}/site/calc-co/estimate`, { method: 'POST', body: new URLSearchParams(body), redirect: 'manual' });
  const bad = await send({ ce_0: '', ce_1: '2', email: 'a@b.test' });
  assert.match(bad.headers.get('location'), /error=Please%20answer/);
  const noContact = await send({ ce_0: '1', ce_1: '2' });
  assert.match(noContact.headers.get('location'), /error=Please%20add/);
  const ok = await send({ ce_0: '1', ce_1: '99', ce_2: '1', name: 'Kim', email: 'kim@x.test', total: '1', price: '1' });
  assert.match(ok.headers.get('location'), /thank-you/);
  const lead = raw.prepare("SELECT * FROM contact_submissions WHERE site_id = ? AND source = 'estimate'").get(siteId);
  // 50 + 40 + 5*15 (capped at max 5) + 30 = 195, high end +20% = 234
  assert.match(lead.message, /\$195 to \$234/);
  assert.match(lead.answers, /Big \(\$40\)/); assert.match(lead.answers, /5 baths/);
  assert.match(await (await c.get(`/sites/${siteId}/leads`)).text(), /From estimate/);
  assert.equal((await send({ website: 'x', ce_0: '1', ce_1: '2', email: 'bot@x.test' })).headers.get('location').includes('thank-you'), true);
  assert.equal(raw.prepare("SELECT COUNT(*) n FROM contact_submissions WHERE site_id = ? AND source = 'estimate'").get(siteId).n, 1, 'honeypot stores nothing');
  // all prices zero -> audit warns; hidden-price wizard does not
  await save({ ...cfg, calc_basePrice: '', calc_options: ['Small | 0\nBig | 0', '', ''], calc_price: ['', '', ''] });
  assert.match(await (await c.get(`/sites/${siteId}/edit`)).text(), /every price is zero/);
  await save({ ...cfg, calc_showPrice: 'no', calc_basePrice: '', calc_options: ['Small | 0\nBig | 0', '', ''], calc_price: ['', '', ''] });
  assert.doesNotMatch(await (await c.get(`/sites/${siteId}/edit`)).text(), /every price is zero/);
  const nop = await (await fetch(`${BASE}/site/calc-co/estimate`)).text();
  assert.doesNotMatch(nop, /id="calcResult"/);
  await send({ ce_0: '0', ce_1: '1', email: 'w@x.test' });
  assert.match(raw.prepare("SELECT message FROM contact_submissions WHERE site_id = ? AND source = 'estimate' ORDER BY id DESC").get(siteId).message, /Asked for a quote/);
  // no questions -> page unavailable
  await save({ calc_enabled: '1', calc_heading: 'x' });
  assert.equal((await fetch(`${BASE}/site/calc-co/estimate`)).status, 404);
  // export has no estimate link
  await save(cfg);
  const zip = readZip(Buffer.from(await (await c.get(`/sites/${siteId}/export`)).arrayBuffer()));
  assert.doesNotMatch(zip['index.html'].toString(), /estimate/i);
  raw.close();
});

test('client questionnaire: link, public form, review, one-click build from the client\'s own words', async (t) => {
  let sharp;
  try { sharp = require('sharp'); } catch { return t.skip('sharp not installed'); }
  const Database = require('better-sqlite3');
  const owner = makeClient();
  await owner.post('/signup', { email: 'questionnaire-owner@example.com', password: 'password1' });
  const created = await owner.post('/intake/links', { label: 'Maria' });
  assert.match(created.headers.get('location'), /f=created/);
  const raw = new Database(TEST_DB);
  const link = raw.prepare('SELECT * FROM intake_links ORDER BY id DESC').get();
  const url = `/start/${link.token}`;

  // public page works without login; bad token is a closed page
  const pub = await fetch(BASE + url);
  assert.equal(pub.status, 200);
  assert.match(await pub.text(), /Your business/);
  assert.notEqual((await fetch(BASE + '/start/' + 'x'.repeat(24))).status, 200);

  // upload a logo and a photo
  const png = await sharp({ create: { width: 200, height: 200, channels: 3, background: '#336699' } }).png().toBuffer();
  const up = async () => {
    const f = new FormData(); f.append('image', new Blob([png], { type: 'image/png' }), 'l.png');
    return (await fetch(BASE + url + '/upload', { method: 'POST', body: f })).json();
  };
  const logo = (await up()).url, photo = (await up()).url;
  assert.match(logo, /^\/uploads\//);

  const anon = makeClient();
  // missing required fields -> 400, nothing saved
  const bad = await anon.post(url, { biz_name: 'X' });
  assert.equal(bad.status, 400);
  assert.equal(raw.prepare('SELECT COUNT(*) n FROM intake_submissions').get().n, 0);
  // honeypot -> looks fine, saves nothing
  await anon.post(url, { website: 'spam', biz_name: 'Spam', biz_type: 'x', contact_name: 'a', contact_email: 'a@b.test', agree: '1' });
  assert.equal(raw.prepare('SELECT COUNT(*) n FROM intake_submissions').get().n, 0);

  const mailBefore = mailCount();
  const ok = await anon.post(url, {
    biz_name: 'Maria Bakery', biz_type: 'Bakery', city: 'Orlando', tagline: 'Baked with love ZZ-TAG',
    svc_name: ['Wedding cakes', 'Sourdough'], svc_desc: ['Tiered cakes made to order', 'Baked every morning'],
    about: 'Maria started baking in her grandmother kitchen ZZ-ABOUT.', phone: '407-555-0100', email: 'hello@maria.test',
    mood: 'warm', logo, photos: [photo], features: ['chat'], faq_q: ['Do you deliver?'], faq_a: ['Yes, within 10 miles ZZ-FAQ.'],
    contact_name: 'Maria', contact_email: 'maria@x.test', agree: '1'
  });
  assert.match(ok.headers.get('location'), /\/done$/);
  assert.match(await (await fetch(BASE + url + '/done')).text(), /Thank/i);
  assert.equal(mailCount(), mailBefore + 1, 'owner emailed');

  const sub = raw.prepare('SELECT * FROM intake_submissions').get();
  assert.equal(sub.status, 'new');

  // another account cannot see or build it
  const other = makeClient();
  const su = await other.post('/signup', { email: 'questionnaire-other@example.com', password: 'password1' });
  assert.equal(su.status, 302, 'signup ok');
  assert.equal((await other.get(`/intake/submissions/${sub.id}`)).status, 404);
  assert.equal((await other.post(`/intake/submissions/${sub.id}/build`, {})).status, 404);

  const review = await (await owner.get(`/intake/submissions/${sub.id}`)).text();
  assert.match(review, /Maria Bakery/); assert.match(review, /Build the website/);
  assert.match(review, /Pick a design/); assert.equal((review.match(/name="option"/g) || []).length, 3, 'three design options offered');
  assert.match(review, /name="option" value="0" checked/);
  assert.match(await (await owner.get('/intake')).text(), /Maria Bakery/);

  const built = await owner.post(`/intake/submissions/${sub.id}/build`, { option: '0' });
  const loc = built.headers.get('location');
  assert.match(loc, /\/sites\/\d+\/edit\?.*fromintake=1/);
  const siteId = loc.match(/\/sites\/(\d+)\//)[1];
  const row = raw.prepare('SELECT * FROM sites WHERE id = ?').get(siteId);
  const s = JSON.parse(row.sections), th = JSON.parse(row.theme);
  const all = JSON.stringify(s);
  assert.match(all, /ZZ-TAG/); assert.match(all, /ZZ-ABOUT/); assert.match(all, /ZZ-FAQ/);
  assert.match(all, /Wedding cakes/); assert.match(all, /Sourdough/);
  assert.equal(th.style, 'warm');
  assert.ok(all.includes(photo), 'client photo used');
  assert.ok(JSON.stringify(th).includes(logo) || all.includes(logo), 'logo used');
  assert.equal(raw.prepare('SELECT status, site_id FROM intake_submissions').get().status, 'built');
  assert.match(await (await owner.get(loc)).text(), /questionnaire/);
  assert.match(await (await owner.get(`/intake/submissions/${sub.id}`)).text(), /Open the site/);

  // close the link
  await owner.post(`/intake/links/${link.id}/toggle`, {});
  assert.doesNotMatch(await (await fetch(BASE + url)).text(), /Your business/);
  const closedPost = await anon.post(url, { biz_name: 'Late', biz_type: 'x', contact_name: 'a', contact_email: 'a@b.test', agree: '1' });
  assert.notEqual(closedPost.status, 302);
  raw.close();
});

test('design upgrades: eyebrow labels, heading size, alternating bands, floating button choices', async () => {
  const c = makeClient();
  const order = 'hero,about,services,testimonials,whyChoose,gallery,faq,blog,extraPages,hours,contact';
  const { siteId } = await basicSite(c, 'design-up@example.com', 'Design Up Co', { contact_email: 'o@designup.test' });
  const save = (extra) => c.post(`/sites/${siteId}/edit`, { name: 'Design Up Co', service_title: ['Grooming'], service_description: ['Baths'], contact_acceptSubmissions: '1', contact_phone: '407-555-0101', layout_order: order, ...extra });
  const home = async (p = '') => (await fetch(`${BASE}/site/design-up-co${p}`)).text();
  await save({});
  assert.doesNotMatch(await home('/services'), /class="eyebrow"/, 'no eyebrow unless set');
  await save({ services_eyebrow: 'Our <care>', about_eyebrow: 'Who we are', theme_headingScale: 'xl', theme_bands: '1' });
  const sv = await home('/services');
  assert.match(sv, /<p class="eyebrow">Our &lt;care&gt;<\/p>\s*<h2>/);
  assert.match(await home('/about'), /<p class="eyebrow">Who we are<\/p>/);
  assert.match(sv, /<body class="[^"]*hs-xl[^"]*bands/);
  await save({ theme_headingScale: 'huge', theme_bands: 'yes' });
  assert.doesNotMatch(await home('/services'), /hs-huge|class="[^"]*\bbands\b/, 'junk ignored');
  // the editor shows the new inputs and keeps them
  await save({ services_eyebrow: 'Kept' });
  assert.match(await (await c.get(`/sites/${siteId}/edit`)).text(), /name="services_eyebrow" value="Kept"/);
  // floating button choices
  await save({ contact_floatButton: 'call' });
  assert.match(await home(), /class="float-contact"[^>]*href="tel:\+14075550101"/);
  await save({ contact_floatButton: 'quote' });
  assert.match(await home(), /class="float-contact" href="\/site\/design-up-co\/contact"/);
  assert.doesNotMatch(await home('/contact'), /class="float-contact"/, 'no quote button on the contact page itself');
  await save({ contact_floatButton: 'book' });
  assert.doesNotMatch(await home(), /class="float-contact"/, 'book needs booking switched on');
  await save({ contact_floatButton: 'nonsense' });
  assert.doesNotMatch(await home(), /class="float-contact"/);
});

test('preview before creating: nothing saved until Create, looks switch, private to the owner', async () => {
  const Database = require('better-sqlite3');
  const raw = new Database(TEST_DB);
  const c = makeClient();
  await c.post('/signup', { email: 'draft-owner@example.com', password: 'password1' });
  const sitesBefore = raw.prepare('SELECT COUNT(*) n FROM sites').get().n;
  const r = await c.post('/sites/generate', { business_type: 'dog grooming', business_name: 'Stans Dog Grooming', city: 'Poinciana, FL', preview: '1' });
  const loc = r.headers.get('location');
  assert.match(loc, /^\/sites\/draft\/[\w-]+$/);
  assert.equal(raw.prepare('SELECT COUNT(*) n FROM sites').get().n, sitesBefore, 'nothing saved yet');
  const wrap = await (await c.get(loc)).text();
  assert.match(wrap, /Create this site/); assert.match(wrap, /Clean and modern/); assert.match(wrap, /src="\/sites\/draft\/[\w-]+\/frame"/);
  const frame = await (await c.get(loc + '/frame')).text();
  assert.match(frame, /Stans Dog Grooming/);
  assert.match(frame, /class="eyebrow"/, 'generated sites get section labels');
  assert.equal((await c.get(loc + '/frame/services')).status, 200);
  // switch the look
  await c.post(loc + '/look', { look: 'luxe' });
  assert.match(await (await c.get(loc + '/frame')).text(), /<body class="style-luxe/);
  await c.post(loc + '/look', { look: 'bogus' });
  assert.match(await (await c.get(loc + '/frame')).text(), /<body class="style-luxe/, 'unknown look ignored');
  // another account cannot see or create it
  const other = makeClient();
  await other.post('/signup', { email: 'draft-other@example.com', password: 'password1' });
  assert.equal((await other.get(loc)).status, 404);
  assert.equal((await other.post(loc + '/create', {})).status, 404);
  // create
  const made = await c.post(loc + '/create', {});
  assert.match(made.headers.get('location'), /\/sites\/\d+\/edit\?generated=1/);
  const site = raw.prepare('SELECT * FROM sites ORDER BY id DESC LIMIT 1').get();
  assert.equal(JSON.parse(site.theme).style, 'luxe');
  assert.equal(raw.prepare('SELECT COUNT(*) n FROM sites').get().n, sitesBefore + 1);
  assert.equal((await c.get(loc)).status, 404, 'draft is gone after creating');
  // discard
  const r2 = await c.post('/sites/generate', { business_type: 'bakery', preview: '1' });
  const loc2 = r2.headers.get('location');
  await c.post(loc2 + '/discard', {});
  assert.equal((await c.get(loc2)).status, 404);
  assert.equal(raw.prepare('SELECT COUNT(*) n FROM sites').get().n, sitesBefore + 1);
  // the benefit-first headline is on the template site, name in the supporting line
  assert.doesNotMatch(JSON.parse(site.sections).hero.headline, /Stans Dog Grooming/);
  raw.close();
});

test('publish to Netlify: deploys the hosted copy, keeps the contact form, custom domain and HTTPS, private to the owner', async () => {
  const c = makeClient();
  const order = 'hero,about,services,testimonials,whyChoose,gallery,faq,blog,extraPages,hours,contact';
  const { siteId } = await basicSite(c, 'netlify-owner@example.com', 'Host Me Co', { contact_email: 'owner@hostme.test' });
  await c.post(`/sites/${siteId}/edit`, { name: 'Host Me Co', service_title: ['Grooming'], service_description: ['Baths'], contact_acceptSubmissions: '1', contact_email: 'owner@hostme.test', contact_phone: '407-555-0111', layout_order: order });
  const page = await (await c.get(`/sites/${siteId}/hosting`)).text();
  assert.match(page, /Publish to Netlify/); assert.doesNotMatch(page, /nfp_test_token/, 'token never shown');
  assert.match(page, /Not on the published copy|What is on the published copy/);

  // another account cannot see or use it
  const other = makeClient();
  await other.post('/signup', { email: 'netlify-other@example.com', password: 'password1' });
  assert.equal((await other.get(`/sites/${siteId}/hosting`)).status, 404);
  assert.equal((await other.post(`/sites/${siteId}/hosting/publish`, {})).status, 404);

  // publish: creates the Netlify site, sends a zip, remembers the ids, sets up the form email
  const r = await c.post(`/sites/${siteId}/hosting/publish`, {});
  assert.match(r.headers.get('location'), /hosting\?f=published/);
  const create = netlifyCalls.find(x => x.method === 'POST' && x.url === '/api/v1/sites');
  assert.equal(create.auth, 'Bearer nfp_test_token'); assert.match(create.json.name, /^host-me-co-/);
  const dep = netlifyCalls.filter(x => /\/deploys$/.test(x.url)).pop();
  assert.equal(dep.type, 'application/zip'); assert.equal(dep.raw.slice(0, 2).toString(), 'PK');
  const zip = readZip(dep.raw);
  assert.ok(zip['index.html'] && zip['contact.html'] && zip['404.html'] && zip['thank-you.html'], 'pages, 404 and thank-you are included');
  assert.ok(!zip['README.txt'], 'no readme in the hosted copy');
  const contactHtml = zip['contact.html'].toString();
  assert.match(contactHtml, /<form[^>]*data-netlify="true"[^>]*name="contact"|<form[^>]*name="contact"[^>]*data-netlify="true"/);
  assert.match(contactHtml, /action="thank-you\.html"/); assert.match(contactHtml, /name="form-name" value="contact"/);
  assert.doesNotMatch(zip['index.html'].toString(), /action="\/site\//, 'no form posting back to SiteGen');
  const hook = netlifyCalls.find(x => x.url === '/api/v1/hooks');
  assert.equal(hook.json.type, 'email'); assert.equal(hook.json.event, 'submission_created'); assert.equal(hook.json.data.email, 'owner@hostme.test'); assert.equal(hook.json.form_name, 'contact');
  const Database = require('better-sqlite3'); const raw = new Database(TEST_DB);
  const row = raw.prepare('SELECT * FROM sites WHERE id = ?').get(siteId);
  assert.equal(row.netlify_site_id, 'nl-site-' + netlifyState.createdNames); assert.ok(row.netlify_deployed_at);
  assert.match(await (await c.get(`/sites/${siteId}/hosting`)).text(), /Publish again/);

  // publishing again reuses the same Netlify site and does not add another form hook
  const sitesCreated = netlifyCalls.filter(x => x.method === 'POST' && x.url === '/api/v1/sites').length;
  const hooks = netlifyCalls.filter(x => x.url === '/api/v1/hooks').length;
  await c.post(`/sites/${siteId}/hosting/publish`, {});
  assert.equal(netlifyCalls.filter(x => x.method === 'POST' && x.url === '/api/v1/sites').length, sitesCreated);
  assert.equal(netlifyCalls.filter(x => x.url === '/api/v1/hooks').length, hooks);
  assert.equal(netlifyCalls.filter(x => /\/deploys$/.test(x.url)).length, 2);

  // custom domain: cleaned, saved, DNS instructions shown, HTTPS requested
  assert.match((await c.post(`/sites/${siteId}/hosting/domain`, { domain: 'not a domain' })).headers.get('location'), /f=nodomain/);
  assert.match((await c.post(`/sites/${siteId}/hosting/domain`, { domain: 'HTTPS://Www.HostMe.com/about' })).headers.get('location'), /f=domain/);
  const patch = netlifyCalls.filter(x => x.method === 'PATCH').pop();
  assert.equal(patch.json.custom_domain, 'www.hostme.com');
  const dnsPage = await (await c.get(`/sites/${siteId}/hosting`)).text();
  assert.match(dnsPage, /www\.hostme\.com/); assert.match(dnsPage, /75\.2\.60\.5/); assert.match(dnsPage, /\.netlify\.app/); assert.match(dnsPage, /Turn on HTTPS/);
  assert.match((await c.post(`/sites/${siteId}/hosting/ssl`, {})).headers.get('location'), /f=ssl$/);
  assert.ok(netlifyCalls.some(x => x.method === 'POST' && /\/ssl$/.test(x.url)));
  netlifyState.sslFail = true;
  assert.match((await c.post(`/sites/${siteId}/hosting/ssl`, {})).headers.get('location'), /f=sslwait/, 'DNS not ready is explained, not an error page');
  netlifyState.sslFail = false;
  await c.post(`/sites/${siteId}/hosting/remove-domain`, {});
  assert.equal(netlifyCalls.filter(x => x.method === 'PATCH').pop().json.custom_domain, null);

  // disconnect forgets the link
  await c.post(`/sites/${siteId}/hosting/unlink`, {});
  assert.equal(raw.prepare('SELECT netlify_site_id FROM sites WHERE id = ?').get(siteId).netlify_site_id, '');
  raw.close();
});

test('publish to Netlify: contact form left out when messages are off; the normal export is unchanged', async () => {
  const c = makeClient();
  const { siteId } = await basicSite(c, 'netlify-noform@example.com', 'No Form Co', {});
  await c.post(`/sites/${siteId}/edit`, { name: 'No Form Co', service_title: ['Cleaning'], service_description: ['Homes'], layout_order: 'hero,about,services,testimonials,whyChoose,gallery,faq,blog,extraPages,hours,contact' });
  await c.post(`/sites/${siteId}/hosting/publish`, {});
  const zip = readZip(netlifyCalls.filter(x => /\/deploys$/.test(x.url)).pop().raw);
  assert.ok(!zip['thank-you.html']); assert.doesNotMatch(zip['contact.html'].toString(), /data-netlify/);
  const plain = readZip(Buffer.from(await (await c.get(`/sites/${siteId}/export`)).arrayBuffer()));
  assert.ok(plain['README.txt'] && !plain['404.html'], 'the download is the same plain zip as before');
});

test('customer payments: key stored encrypted, service pay button, booking deposit hold, payment requests, sweep', async () => {
  const Database = require('better-sqlite3'); const raw = new Database(TEST_DB);
  const SITE_KEY = 'sk_test_' + 'Z9y8x7w6v5u4t3s2r1q0pLmN';
  const c = makeClient();
  const order = 'hero,about,services,testimonials,whyChoose,gallery,faq,blog,extraPages,hours,contact';
  const { siteId, slug } = await basicSite(c, 'payer-owner@example.com', 'Pay Co', {});
  const save = (extra) => c.post(`/sites/${siteId}/edit`, { name: 'Pay Co', service_title: ['Full groom', 'Bath only'], service_description: ['Cut', 'Wash'], service_detail: ['Full groom details here.', ''], service_pay: ['89', ''], contact_acceptSubmissions: '1', contact_email: 'owner@payco.test', layout_order: order, ...extra });

  // nothing is payable until payments are on AND a key is saved
  await save({ pay_enabled: '1', pay_currency: 'usd' });
  assert.doesNotMatch(await (await fetch(`${BASE}/site/${slug}/services/full-groom`)).text(), /class="buy-form"/);
  assert.equal((await fetch(`${BASE}/site/${slug}/buy`, { method: 'POST', redirect: 'manual', body: new URLSearchParams({ service: 'Full groom' }) })).headers.get('location'), `/site/${slug}/services`);
  assert.equal(raw.prepare('SELECT COUNT(*) n FROM payments WHERE site_id = ?').get(siteId).n, 0, 'no payment row without a key');

  // the key: junk is ignored, a real one is stored encrypted and never shown again
  await save({ pay_enabled: '1', stripe_key: 'not-a-key' });
  assert.equal(raw.prepare('SELECT stripe_key_enc k FROM sites WHERE id = ?').get(siteId).k, '');
  await save({ pay_enabled: '1', pay_currency: 'usd', stripe_key: SITE_KEY });
  const stored = raw.prepare('SELECT stripe_key_enc k, stripe_key_hint h FROM sites WHERE id = ?').get(siteId);
  assert.ok(stored.k && !stored.k.includes('sk_test') && !stored.k.includes('Z9y8'), 'encrypted at rest');
  assert.match(stored.h, /ending pLmN/);
  const editor = await (await c.get(`/sites/${siteId}/edit`)).text();
  assert.doesNotMatch(editor, /Z9y8x7w6v5u4t3s2r1q0pLmN/); assert.match(editor, /ending pLmN/);
  await save({ pay_enabled: '1', pay_currency: 'usd' }); // saving again without the field keeps the key
  assert.ok(raw.prepare('SELECT stripe_key_enc k FROM sites WHERE id = ?').get(siteId).k);

  // service pay button: price comes from the owner's settings, the visitor cannot change it
  const svcPage = await (await fetch(`${BASE}/site/${slug}/services/full-groom`)).text();
  assert.match(svcPage, /class="buy-form"[^>]*>[\s\S]*?Pay online &middot; \$89\.00/);
  const buy = await fetch(`${BASE}/site/${slug}/buy`, { method: 'POST', redirect: 'manual', body: new URLSearchParams({ service: 'Full groom', amount: '1', price: '1' }) });
  assert.match(buy.headers.get('location'), /^https:\/\/checkout\.stripe\.test\/pay\/cs_pay_\d+$/);
  const sreq = stripeRequests.filter(r => r.url === '/v1/checkout/sessions' && r.params.get('mode') === 'payment').pop();
  assert.equal(sreq.auth, 'Bearer ' + SITE_KEY, 'the site\'s own key is used, not the platform key');
  assert.equal(sreq.params.get('line_items[0][price_data][unit_amount]'), '8900'); assert.equal(sreq.params.get('line_items[0][price_data][currency]'), 'usd');
  assert.equal((await fetch(`${BASE}/site/${slug}/buy`, { method: 'POST', redirect: 'manual', body: new URLSearchParams({ service: 'Bath only' }) })).headers.get('location'), `/site/${slug}/services`, 'a service with no price cannot be bought');
  const pay1 = raw.prepare("SELECT * FROM payments WHERE kind = 'purchase' AND site_id = ?").get(siteId);
  assert.equal(pay1.amount_cents, 8900); assert.equal(pay1.status, 'pending');
  const payPage = await (await fetch(`${BASE}/pay/${pay1.token}`)).text();
  assert.match(payPage, /\$89\.00/); assert.match(payPage, /Pay \$89\.00/);
  // customer pays on Stripe and comes back: confirmed by asking Stripe, owner emailed once
  stripeSessions[pay1.stripe_session_id].payment_status = 'paid'; stripeSessions[pay1.stripe_session_id].customer_details = { name: 'Kim Buyer', email: 'kim@x.test' };
  const before = mailCount();
  assert.match(await (await fetch(`${BASE}/pay/${pay1.token}?done=1`)).text(), /Payment received/);
  await fetch(`${BASE}/pay/${pay1.token}`);
  const paid1 = raw.prepare('SELECT * FROM payments WHERE id = ?').get(pay1.id);
  assert.equal(paid1.status, 'paid'); assert.equal(paid1.customer_name, 'Kim Buyer'); assert.equal(paid1.customer_email, 'kim@x.test');
  const mails = await waitForMail(before + 1);
  assert.equal(mails.slice(before).filter(m => /Payment received/.test(m.subject)).length, 1, 'one alert, not one per page view');
  assert.equal((await fetch(`${BASE}/pay/not-a-real-token-123456`)).status, 404);

  // booking deposit: time is held, booking only confirmed once paid; unpaid holds are released
  await save({ ...bookingFields({ bk_autoConfirm: '1' }), pay_enabled: '1', pay_currency: 'usd', pay_depositMode: 'fixed', pay_depositAmount: '25' });
  const date = daysAhead(5);
  const post = (body) => fetch(`${BASE}/site/${slug}/book`, { method: 'POST', redirect: 'manual', headers: { 'content-type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams(body).toString() });
  const good = { service: 'Full groom', date, time: '10:00', name: 'Dana Pet', email: 'dana@example.com', f_0: 'Biscuit', f_1: 'Medium' };
  const r = await post(good);
  assert.match(r.headers.get('location'), /^https:\/\/checkout\.stripe\.test\/pay\//, 'sent straight to Stripe');
  const bk = raw.prepare("SELECT * FROM bookings WHERE name = 'Dana Pet' AND site_id = ?").get(siteId);
  assert.equal(bk.status, 'awaiting_payment');
  const dep = raw.prepare("SELECT * FROM payments WHERE kind = 'deposit' AND site_id = ?").get(siteId);
  assert.equal(dep.amount_cents, 2500); assert.equal(dep.ref_id, bk.id);
  const slots = async (svc = 'Full groom') => (await (await fetch(`${BASE}/site/${slug}/book/slots?${new URLSearchParams({ service: svc, date })}`)).json()).slots.map(x => x.time);
  assert.ok(!(await slots()).includes('10:00'), 'the held time is not offered to others');
  assert.equal((await post({ ...good, name: 'Other Person', email: 'o@x.test' })).status, 422, 'cannot take a held time');
  assert.match(await (await fetch(`${BASE}/site/${slug}/book?t=${bk.token}`)).text(), /not booked/);
  assert.match(await (await c.get(`/sites/${siteId}/bookings`)).text(), /Waiting for a deposit/);
  // customer pays; the background sweep confirms it even though they never came back
  stripeSessions[dep.stripe_session_id].payment_status = 'paid';
  const jobs = await (await fetch(`${BASE}/__test/run-jobs`, { method: 'POST', headers: { 'x-test-key': 'suite' } })).json();
  assert.ok(jobs.payments.checked >= 1);
  assert.equal(raw.prepare('SELECT status FROM bookings WHERE id = ?').get(bk.id).status, 'confirmed');
  assert.equal(raw.prepare('SELECT status FROM payments WHERE id = ?').get(dep.id).status, 'paid');
  assert.match(await (await fetch(`${BASE}/site/${slug}/book?t=${bk.token}`)).text(), /Deposit paid: \$25\.00/);
  assert.match(await (await c.get(`/sites/${siteId}/bookings`)).text(), /deposit \$25\.00 paid/);
  // an unpaid hold older than 30 minutes is released and the time is free again
  const lr = await post({ ...good, service: 'Bath only', time: '12:00', name: 'Late Payer', email: 'late@x.test' });
  assert.ok(lr.status === 302, 'late booking status ' + lr.status + ' ' + ((await lr.text()).match(/class="[^"]*(?:error|alert|notice)[^"]*"[^>]*>([^<]{5,200})/g)||[]).join('|').replace(/\s+/g,' ').slice(0, 400));
  const lp = raw.prepare("SELECT * FROM bookings WHERE name = 'Late Payer'").get();
  assert.equal(lp.status, 'awaiting_payment');
  raw.prepare("UPDATE bookings SET created_at = datetime('now', '-45 minutes') WHERE id = ?").run(lp.id);
  const jobs2 = await (await fetch(`${BASE}/__test/run-jobs`, { method: 'POST', headers: { 'x-test-key': 'suite' } })).json();
  assert.ok(jobs2.payments.released >= 1);
  assert.equal(raw.prepare('SELECT status FROM bookings WHERE id = ?').get(lp.id).status, 'cancelled');
  assert.ok((await slots('Bath only')).includes('12:00'), 'released time is bookable again');
  assert.equal(raw.prepare("SELECT status FROM payments WHERE ref_id = ? AND kind = 'deposit'").get(lp.id).status, 'expired');

  // payment requests (quotes / invoices): create, email, history, private to the owner
  const stripeCallsBefore = stripeRequests.length;
  assert.match((await c.post(`/sites/${siteId}/payments/new`, { amount: 'abc', description: 'x' })).headers.get('location'), /f=bad/);
  assert.match((await c.post(`/sites/${siteId}/payments/new`, { amount: '250', description: '' })).headers.get('location'), /f=bad/);
  const mb = mailCount();
  assert.match((await c.post(`/sites/${siteId}/payments/new`, { amount: '$1,250.50', description: 'Kitchen deep clean', name: 'Lee', email: 'lee@x.test', send: '1' })).headers.get('location'), /f=sent/);
  const inv = raw.prepare("SELECT * FROM payments WHERE kind = 'invoice' ORDER BY id DESC").get();
  assert.equal(inv.amount_cents, 125050);
  const sent = (await waitForMail(mb + 1)).slice(mb).find(m => m.to[0].address === 'lee@x.test');
  assert.match(sent.text, /\$1,250\.50/); assert.match(sent.text, new RegExp('/pay/' + inv.token));
  const hub = await (await c.get(`/sites/${siteId}/payments`)).text();
  assert.match(hub, /Kitchen deep clean/); assert.match(hub, /\$89\.00/); assert.match(hub, /Collected/);
  const other = makeClient();
  await other.post('/signup', { email: 'payer-other@example.com', password: 'password1' });
  assert.equal((await other.get(`/sites/${siteId}/payments`)).status, 404);
  assert.equal((await other.post(`/sites/${siteId}/payments/${inv.id}/paid`, {})).status, 404);
  assert.equal(raw.prepare('SELECT status FROM payments WHERE id = ?').get(inv.id).status, 'pending', 'another account could not touch it');
  // owner marks it paid (cash), then a second one is canceled and cannot be paid
  await c.post(`/sites/${siteId}/payments/${inv.id}/paid`, {});
  assert.equal(raw.prepare('SELECT status, paid_via FROM payments WHERE id = ?').get(inv.id).paid_via, 'manual');
  await c.post(`/sites/${siteId}/payments/new`, { amount: '40', description: 'Cancel me' });
  const cx = raw.prepare("SELECT * FROM payments WHERE description = 'Cancel me'").get();
  await c.post(`/sites/${siteId}/payments/${cx.id}/cancel`, {});
  assert.match(await (await fetch(`${BASE}/pay/${cx.token}`)).text(), /canceled/);
  const noPay = await fetch(`${BASE}/pay/${cx.token}`, { method: 'POST', redirect: 'manual' });
  assert.equal(noPay.headers.get('location'), `/pay/${cx.token}`);
  assert.equal(stripeRequests.slice(stripeCallsBefore).filter(r => r.params.get('mode') === 'payment').length, 0, 'requests for money made no Stripe session until a customer pays');

  // removing the key turns every pay button off again
  await save({ pay_enabled: '1', stripe_key_remove: '1' });
  assert.doesNotMatch(await (await fetch(`${BASE}/site/${slug}/services/full-groom`)).text(), /class="buy-form"/);
  assert.equal(raw.prepare('SELECT stripe_key_enc k FROM sites WHERE id = ?').get(siteId).k, '');
  raw.close();
});

test('chat-to-edit: proposes, previews, applies only allowed changes, saves history, owner-only', async () => {
  const Database = require('better-sqlite3'); const raw = new Database(TEST_DB);
  const c = makeClient();
  const { siteId, slug } = await basicSite(c, 'chatedit-owner@example.com', 'Edit Co', {});
  const ask = (cl, base, instruction) => cl.post(base + '/ai-edit', { instruction }, { json: true });
  const base = `/sites/${siteId}`;
  const r1 = await (await ask(c, base, 'ZZ-EDIT-OK make it friendlier')).json();
  assert.equal(r1.ok, true);
  assert.deepEqual(r1.changes.map(x => x.label).sort(), ['Add service', 'Main color', 'hero headline']);
  assert.equal(r1.skipped, 3, 'contact, bad colour and __proto__ were refused');
  const siteNow = () => raw.prepare('SELECT theme, sections FROM sites WHERE id = ?').get(siteId);
  assert.notEqual(JSON.parse(siteNow().sections).hero.headline, 'A friendlier headline', 'nothing saved before approval');
  // another account cannot apply or even ask
  const other = makeClient(); await other.post('/signup', { email: 'chatedit-other@example.com', password: 'password1' });
  assert.equal((await other.post(base + '/ai-edit/apply', { token: r1.token }, { json: true })).status, 404);
  assert.equal((await ask(other, base, 'ZZ-EDIT-OK')).status, 404);
  const v0 = raw.prepare('SELECT COUNT(*) n FROM site_versions WHERE site_id = ?').get(siteId).n;
  const ap = await (await c.post(base + '/ai-edit/apply', { token: r1.token }, { json: true })).json();
  assert.equal(ap.ok, true); assert.equal(ap.applied, 3);
  const row = siteNow(); const sec = JSON.parse(row.sections);
  assert.equal(sec.hero.headline, 'A friendlier headline');
  assert.equal(JSON.parse(row.theme).primaryColor, '#116644');
  assert.ok(sec.services.items.some(i => i.title === 'Gutter Cleaning'));
  assert.notEqual(sec.contact.email, 'evil@x.test'); assert.equal(({}).polluted, undefined);
  assert.equal(raw.prepare('SELECT COUNT(*) n FROM site_versions WHERE site_id = ?').get(siteId).n, v0 + 1, 'history version saved');
  assert.match(raw.prepare('SELECT label FROM site_versions WHERE site_id = ? ORDER BY id DESC').get(siteId).label, /Before AI edit/);
  assert.match(await (await fetch(`${BASE}/site/${slug}`)).text(), /A friendlier headline/);
  // a proposal can only be used once
  assert.equal((await (await c.post(base + '/ai-edit/apply', { token: r1.token }, { json: true })).json()).ok, false);
  // nothing allowed to change -> an explanation and no token; unusable AI reply -> clear message
  const r2 = await (await ask(c, base, 'ZZ-EDIT-NONE change my phone')).json();
  assert.equal(r2.ok, true); assert.equal(r2.changes.length, 0); assert.equal(r2.token, ''); assert.match(r2.reply, /cannot change/);
  const r3 = await (await ask(c, base, 'garbled')).json();
  assert.equal(r3.ok, false); assert.match(r3.error, /Nothing was changed/);
  assert.equal((await ask(c, base, '   ')).status, 400);
  // clients (share link): text only, no style changes
  await c.post(`${base}/client-link`, {});
  const shown = await (await c.get(`${base}/edit?clientlink=1`)).text();
  const token = shown.match(/<strong id="clientLinkText">(http[^<]+)<\/strong>/)[1].split('/client/')[1];
  const cli = await (await fetch(`${BASE}/client/${token}/ai-edit`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ instruction: 'ZZ-EDIT-OK' }) })).json();
  assert.equal(cli.ok, true);
  assert.ok(!cli.changes.some(x => /Style/.test(x.label)), 'clients cannot change colours or style');
  assert.ok(cli.changes.some(x => x.label === 'Add service'));
  assert.match(await (await fetch(`${BASE}/client/${token}`)).text(), /Ask AI to change something/);
  assert.equal((await fetch(`${BASE}/client/${'x'.repeat(32)}/ai-edit`, { method: 'POST' })).status, 404);
  // a client's proposal cannot be applied through the owner route
  assert.equal((await (await c.post(base + '/ai-edit/apply', { token: cli.token })).json()).ok, false);
  assert.match(await (await c.get(`${base}/edit`)).text(), /Ask AI to change something/);
  raw.close();
});

test('luxury dark style: own colors, quick-link pills, home map and footer columns', async () => {
  const c = makeClient();
  const { siteId, slug } = await basicSite(c, 'noir-owner@example.com', 'Noir Co', {});
  const order = 'hero,about,services,testimonials,whyChoose,gallery,faq,blog,extraPages,hours,contact';
  const save = (extra) => c.post(`/sites/${siteId}/edit`, { name: 'Noir Co', theme_style: 'noir', theme_primaryColor: '#c9a24b', theme_accentColor: '#14100a', service_title: ['Groom'], service_description: ['Cut'], hours_day: ['Mon'], hours_time: ['9-5'], contact_acceptSubmissions: '1', contact_phone: '407-555-0100', contact_address: '1 Main St, Orlando, FL', layout_order: order, ...extra });
  const home = async () => (await fetch(`${BASE}/site/${slug}`)).text();

  await save({});
  let h = await home();
  assert.match(h, /class="style-noir /);
  assert.doesNotMatch(h, /class="quick-links"/, 'pills are off until switched on');
  assert.doesNotMatch(h, /id="where-we-work"/);
  assert.doesNotMatch(h, /<h4>Hours<\/h4>/);

  await save({ hero_quickLinks: '1', contact_homeMap: '1', contact_footerHours: '1', theme_bgColor: '#08111f', theme_primaryColor: '#e0a98f' });
  h = await home();
  assert.match(h, /<nav class="quick-links"[^>]*>[\s\S]*?Services[\s\S]*?<\/nav>/);
  assert.match(h, /href="#where-we-work"/);
  assert.match(h, /id="where-we-work"[\s\S]*?maps\.google\.com\/maps\?q=1%20Main%20St/);
  assert.match(h, /<h4>Hours<\/h4>[\s\S]*?Mon/);
  assert.match(h, /body\.style-noir \{ --page-bg: #08111f; \}/, 'custom background applied');
  assert.match(h, /--primary: #e0a98f;/);
  assert.match(h, /--on-primary: #111111;/, 'dark text on a light accent');

  // a bad background value cannot inject CSS
  await save({ theme_bgColor: 'red; } body { display:none' });
  h = await home();
  assert.doesNotMatch(h, /display:none/); assert.doesNotMatch(h, /--page-bg: red/);
  assert.equal(JSON.parse(require('better-sqlite3')(TEST_DB).prepare('SELECT theme FROM sites WHERE id = ?').get(siteId).theme).bgColor, '');

  // dark accents get light text, light accents get dark text on filled buttons
  await save({ theme_primaryColor: '#2a3a8c' });
  assert.match(await home(), /--on-primary: #ffffff;/);

  // "We accept" column appears once card payments are live
  assert.doesNotMatch(await home(), /We accept/);
  await save({ pay_enabled: '1', stripe_key: 'sk_test_' + 'Q1w2e3r4t5y6u7i8o9p0AsDf' });
  assert.match(await home(), /<h4>We accept<\/h4>[\s\S]*?Visa/);
  // other styles are untouched by the new options' CSS
  await save({ theme_style: 'modern' });
  assert.doesNotMatch(await home(), /class="style-noir /);
});

test('accents: own emoji, doodles, emoji headings and floating shapes', async () => {
  const c = makeClient();
  const { siteId, slug } = await basicSite(c, 'accents-owner@example.com', 'Accent Co', {});
  const order = 'hero,about,services,testimonials,whyChoose,gallery,faq,blog,extraPages,hours,contact';
  const save = (extra) => c.post(`/sites/${siteId}/edit`, { name: 'Accent Co', service_title: ['Groom'], service_description: ['Cut'], about_heading: 'Our Story', about_body: 'Hello', layout_order: order, ...extra });
  const home = async () => (await fetch(`${BASE}/site/${slug}`)).text();

  await save({});
  let h = await home();
  assert.doesNotMatch(h, /<canvas/); assert.doesNotMatch(h, /class="[^"]*\bdoodles\b/); 

  await save({ theme_emoji: '🐾 ✂️ <script>alert(1)</script> 🦴 hello', theme_doodles: '1', theme_emojiHeads: '1', hero_float: 'emoji' });
  h = await home();
  assert.match(h, /<body class="[^"]*\bdoodles\b[^"]*\bemoji-heads\b/);
  assert.match(h, /--emoji-q: "🐾";/);
  assert.match(h, /<canvas class="hero-fx"[^>]*data-fx="emoji"[^>]*data-emoji="🐾 ✂️ 🦴"/);
  assert.doesNotMatch(h, /<script>alert\(1\)/, 'only emoji survive');
  const editor = await (await c.get(`/sites/${siteId}/edit`)).text();
  assert.match(editor, /name="theme_emoji"[^>]*value="🐾 ✂️ 🦴"/);
  assert.match(editor, /name="hero_float"/); assert.doesNotMatch(editor, /name="hero_motion"/, 'cinematic hero now belongs to the motion style');

  // text with no emoji leaves nothing behind; unknown shapes and motions are ignored
  await save({ theme_emoji: 'no emoji here', theme_emojiHeads: '1', hero_float: 'emoji' });
  h = await home();
  assert.doesNotMatch(h, /--emoji-q: /); assert.doesNotMatch(h, /<body class="[^"]*emoji-heads/);
  assert.match(h, /data-emoji="✨"/, 'floating emoji falls back to sparkles when none chosen');
  await save({ hero_float: 'rainstorm' });
  assert.doesNotMatch(await home(), /<canvas/);
  for (const k of ['sparkles', 'bubbles', 'confetti']) { await save({ hero_float: k }); assert.match(await home(), new RegExp(`data-fx="${k}"`)); }
});

test('editor shows design suggestions for the site\'s industry', async () => {
  const c = makeClient();
  const { siteId } = await basicSite(c, 'advice-owner@example.com', 'Glow Salon', { meta_businessType: 'hair salon' });
  const page = await (await c.get(`/sites/${siteId}/edit`)).text();
  assert.match(page, /id="designAdvice"/);
  assert.match(page, /data-da-style="luxe"/);
  assert.match(page, /data-da-primary="#[0-9a-f]{6}"/);
  assert.match(page, /Better to avoid:[\s\S]{0,200}midnight style/);
  const generic = await basicSite(c, 'advice-owner2@example.com', 'Plain Co', { meta_businessType: 'zzz unknown thing' });
  assert.doesNotMatch(await (await c.get(`/sites/${generic.siteId}/edit`)).text(), /id="designAdvice"/, 'no advice when the industry is unknown');
});

test('questionnaire: the owner\'s chosen design option is what gets built', async () => {
  const Database = require('better-sqlite3');
  const designOptions = require('../design-options');
  const owner = makeClient();
  await owner.post('/signup', { email: 'design-opt-owner@example.com', password: 'password1' });
  await owner.post('/intake/links', { label: 'Opt' });
  const raw = new Database(TEST_DB);
  const link = raw.prepare('SELECT * FROM intake_links ORDER BY id DESC').get();
  const anon = makeClient();
  const ok = await anon.post(`/start/${link.token}`, {
    biz_name: 'Glow Hair Studio', biz_type: 'Hair salon', city: 'Orlando', svc_name: ['Cuts'], svc_desc: ['Fresh cuts'],
    mood: 'luxe', inspo_like: 'elegant and calm', contact_name: 'Gia', contact_email: 'gia@x.test', agree: '1'
  });
  assert.match(ok.headers.get('location'), /\/done$/);
  const sub = raw.prepare('SELECT * FROM intake_submissions WHERE site_id IS NULL ORDER BY id DESC').get();
  const d = JSON.parse(sub.data);
  const opts = designOptions.designOptions(d).options;
  const built = await owner.post(`/intake/submissions/${sub.id}/build`, { option: '1' });
  const siteId = built.headers.get('location').match(/\/sites\/(\d+)\//)[1];
  const th = JSON.parse(raw.prepare('SELECT theme FROM sites WHERE id = ?').get(siteId).theme);
  assert.equal(th.style, opts[1].style, 'option 2 style applied');
  assert.notEqual(opts[1].style, 'luxe');
  // a forged option value is ignored and the client's own look is kept
  const sub2Resp = await anon.post(`/start/${link.token}`, { biz_name: 'Forge Co', biz_type: 'Hair salon', svc_name: ['x'], svc_desc: [''], mood: 'luxe', contact_name: 'G', contact_email: 'g@x.test', agree: '1' });
  assert.match(sub2Resp.headers.get('location'), /\/done$/);
  const sub2 = raw.prepare("SELECT * FROM intake_submissions WHERE site_id IS NULL ORDER BY id DESC").get();
  const b2 = await owner.post(`/intake/submissions/${sub2.id}/build`, { option: '9; drop' });
  const th2 = JSON.parse(raw.prepare('SELECT theme FROM sites WHERE id = ?').get(b2.headers.get('location').match(/\/sites\/(\d+)\//)[1]).theme);
  assert.equal(th2.style, 'luxe');
});

test('quality gate: errors pause publishing, "publish anyway" and fixes work', async () => {
  const c = makeClient();
  const { siteId, editPath } = await (async () => {
    await c.post('/signup', { email: 'quality-owner@example.com', password: 'password1' });
    const create = await c.post('/sites', { name: 'Gate Co' });
    const editPath = create.headers.get('location');
    return { siteId: editPath.match(/\/sites\/(\d+)\//)[1], editPath };
  })();
  const base = { name: 'Gate Co', hero_headline: 'Hi', about_heading: 'About', about_body: 'x', services_heading: 'S', contact_heading: 'C', contact_email: 'g@x.test', layout_order: 'hero,about,services,contact' };
  const Database = require('better-sqlite3'); const raw = new Database(TEST_DB);
  const published = () => raw.prepare('SELECT published FROM sites WHERE id = ?').get(siteId).published;

  // clean site: publishes straight away
  await c.post(editPath, { ...base, theme_primaryColor: '#1d4ed8' });
  const page = await (await c.get(`/sites/${siteId}/quality`)).text();
  assert.match(page, /Quality check/); assert.match(page, /0 to fix/);
  await c.post(`/sites/${siteId}/publish`, { published: '1' });
  assert.equal(published(), 1);
  await c.post(`/sites/${siteId}/publish`, { published: '0' });

  // a missing photo is a real error: publishing pauses on the fix list
  await c.post(editPath, { ...base, theme_primaryColor: '#1d4ed8', hero_imageUrl: '/uploads/not-there.jpg' });
  const blocked = await c.post(`/sites/${siteId}/publish`, { published: '1' });
  assert.match(blocked.headers.get('location'), new RegExp(`/sites/${siteId}/quality\\?gate=publish`));
  assert.equal(published(), 0);
  const gatePage = await (await c.get(`/sites/${siteId}/quality?gate=publish`)).text();
  assert.match(gatePage, /Image file is missing/); assert.match(gatePage, /Publish anyway/);
  await c.post(`/sites/${siteId}/publish`, { published: '1', force: '1' });
  assert.equal(published(), 1, 'publish anyway works');
  await c.post(`/sites/${siteId}/publish`, { published: '0' });

  // another account cannot see or fix it
  const other = makeClient(); await other.post('/signup', { email: 'quality-other@example.com', password: 'password1' });
  assert.equal((await other.get(`/sites/${siteId}/quality`)).status, 404);
  assert.equal((await other.post(`/sites/${siteId}/quality/fix`, { fix: 'colors' })).status, 404);

  // pale brand colour: the one-click fix darkens it enough
  await c.post(editPath, { ...base, theme_primaryColor: '#7dd3fc' });
  assert.match(await (await c.get(`/sites/${siteId}/quality`)).text(), /Brand color blends into the page/);
  const fixed = await c.post(`/sites/${siteId}/quality/fix`, { fix: 'colors', primaryColor: '#ff0000' });
  assert.match(fixed.headers.get('location'), /done=colors/);
  const th = JSON.parse(raw.prepare('SELECT theme FROM sites WHERE id = ?').get(siteId).theme);
  assert.notEqual(th.primaryColor, '#7dd3fc'); assert.notEqual(th.primaryColor, '#ff0000', 'form value ignored');
  assert.ok(require('../contrast').ratio(th.primaryColor, require('../quality').onPrimary(th.primaryColor)) >= 4.5);
  assert.ok(raw.prepare("SELECT COUNT(*) n FROM site_versions WHERE site_id = ? AND label LIKE 'Before quality fix%'").get(siteId).n >= 1, 'history saved');
});

test('motion style: new sites default to Subtle, markup carries data-animate, scripts are bundled, none loads nothing', async () => {
  const Database = require('better-sqlite3');
  const c = makeClient();
  const { siteId } = await basicSite(c, 'motion-owner@example.com', 'Motion Co', {});
  const raw = new Database(TEST_DB);
  await c.post(`/sites/${siteId}/publish`, { published: '1', force: '1' });
  const save = (extra) => c.post(`/sites/${siteId}/edit`, { name: 'Motion Co', hero_headline: 'Hello', about_heading: 'About', about_body: 'Text', service_title: ['A'], service_description: ['x'], stat_value: ['1,500+', '24/7'], stat_label: ['Jobs', 'Open'], layout_order: 'hero,about,services,testimonials,whyChoose,gallery,faq,blog,extraPages,hours,contact', ...extra });
  const home = async () => (await fetch(`${BASE}/site/motion-co`)).text();

  // the first save from the editor keeps whatever the form says; a brand-new site starts on Subtle
  assert.equal(JSON.parse(raw.prepare('SELECT theme FROM sites WHERE id = ?').get(siteId).theme).motionStyle, 'subtle');
  await save({ theme_motionStyle: 'subtle' });
  let h = await home();
  assert.match(h, /<body class="[^"]*"[^>]*data-motion="subtle"/);
  assert.match(h, /<h1 data-animate="hero">Hello<\/h1>/);
  assert.match(h, /data-animate="fade-up"/);
  assert.match(h, /<script src="\/vendor\/motion\.js" defer><\/script>\s*<script src="\/sitegen-motion\.js" defer><\/script>/);
  assert.match(h, /html\.sg-anim \[data-animate="fade-up"\]/, 'hide-until-ready rule exists');
  assert.match(h, /classList\.add\('sg-anim'\)[^<]*setTimeout\(function\(\)\{h\.classList\.remove\('sg-anim'\)\},3000\)/, 'safety net: shown after 3s if the script never runs');
  assert.match(h, /prefers-reduced-motion: reduce\)'\)\.matches\)return;/, 'reduced motion: nothing is hidden');
  for (const gone of ['data-reveal', 'js-motion', 'hero-cine', 'motion-rise', 'cdn.jsdelivr', 'unpkg.com', 'cdnjs']) assert.ok(!h.includes(gone), `${gone} should be gone`);
  // the library and script are served by the site itself
  const lib = await fetch(`${BASE}/vendor/motion.js`); assert.equal(lib.status, 200); assert.match(await lib.text(), /Motion/);
  assert.equal((await fetch(`${BASE}/sitegen-motion.js`)).status, 200);

  // lively and none
  await save({ theme_motionStyle: 'lively' });
  assert.match(await home(), /data-motion="lively"/);
  await save({ theme_motionStyle: 'none' });
  h = await home();
  assert.match(h, /data-motion="none"/);
  assert.doesNotMatch(h, /vendor\/motion\.js/); assert.doesNotMatch(h, /sitegen-motion\.js/); assert.doesNotMatch(h, /classList\.add\('sg-anim'\)/);
  // junk falls back to Subtle; the editor shows the choice
  await save({ theme_motionStyle: 'warp' });
  assert.match(await home(), /data-motion="subtle"/);
  await save({ theme_motionStyle: 'lively' });
  assert.match(await (await c.get(`/sites/${siteId}/edit`)).text(), /name="theme_motionStyle"[^>]*>[\s\S]*?<option value="lively" selected>/);

  // sites saved before the setting existed keep what they had (checked on the uncached preview)
  const pvHome = async () => (await c.get(`/sites/${siteId}/preview`)).text();
  const setTheme = (patch, drop) => { const t = JSON.parse(raw.prepare('SELECT theme FROM sites WHERE id = ?').get(siteId).theme); drop.forEach(k => delete t[k]); raw.prepare('UPDATE sites SET theme = ? WHERE id = ?').run(JSON.stringify({ ...t, ...patch }), siteId); };
  setTheme({}, ['motionStyle']);
  assert.match(await pvHome(), /data-motion="none"/);
  setTheme({ motion: 'rise' }, ['motionStyle']);
  assert.match(await pvHome(), /data-motion="subtle"/);
  setTheme({ motionStyle: 'subtle' }, ['motion']);

  // numbers: real values in the text, data-count for the script, nothing for "24/7"
  const t = JSON.parse(raw.prepare('SELECT sections FROM sites WHERE id = ?').get(siteId).sections);
  t.trust = { ...t.trust, stats: [{ value: '1,500+', label: 'Jobs' }, { value: '24/7', label: 'Open' }] };
  raw.prepare('UPDATE sites SET sections = ? WHERE id = ?').run(JSON.stringify(t), siteId);
  h = await pvHome();
  assert.match(h, /<strong data-count="1500" data-suffix="\+" data-comma="1">1,500\+<\/strong>/);
  assert.match(h, /<strong>24\/7<\/strong>/);
});

test('motion style: industries suggest a preset when a site is generated, and the editor offers it', async () => {
  const Database = require('better-sqlite3'); const raw = new Database(TEST_DB);
  const c = makeClient();
  await c.post('/signup', { email: 'motion-suggest@example.com', password: 'password1' });
  const style = async (type, name) => {
    const gen = await c.post('/sites/generate', { business_type: type, business_name: name });
    const id = gen.headers.get('location').match(/\/sites\/(\d+)\//)[1];
    return { id, level: JSON.parse(raw.prepare('SELECT theme FROM sites WHERE id = ?').get(id).theme).motionStyle };
  };
  assert.equal((await style('restaurant', 'Motion Bistro')).level, 'lively');
  assert.equal((await style('insurance agency', 'Motion Insure')).level, 'subtle');
  const care = await style('home care agency', 'Motion Care');
  assert.equal(care.level, 'subtle');
  // someone who turned a restaurant site to Subtle is offered the industry suggestion
  const bistro = raw.prepare("SELECT id, theme FROM sites WHERE name = 'Motion Bistro'").get();
  raw.prepare('UPDATE sites SET theme = ? WHERE id = ?').run(JSON.stringify({ ...JSON.parse(bistro.theme), motionStyle: 'subtle' }), bistro.id);
  const editor = await (await c.get(`/sites/${bistro.id}/edit`)).text();
  assert.match(editor, /Suggested for this kind of business: <strong>lively<\/strong>/);
  assert.match(editor, /id="motionApply" data-level="lively"/);
});

test('motion style: preview switcher is preview-only, "use this style" is owner-only and saved to history', async () => {
  const Database = require('better-sqlite3'); const raw = new Database(TEST_DB);
  const c = makeClient();
  const { siteId } = await basicSite(c, 'motion-preview@example.com', 'Preview Motion', {});
  await c.post(`/sites/${siteId}/publish`, { published: '1', force: '1' });
  const pv = await (await c.get(`/sites/${siteId}/preview`)).text();
  assert.match(pv, /class="sg-motion-bar"/);
  for (const k of ['subtle', 'lively', 'none']) assert.match(pv, new RegExp(`data-sg-preset="${k}"`));
  assert.match(pv, /id="sgReplay"/);
  assert.match(pv, /vendor\/motion\.js/, 'preview always loads the scripts so the switcher can show them');
  const live = await (await fetch(`${BASE}/site/preview-motion`)).text();
  assert.doesNotMatch(live, /sg-motion-bar/); assert.doesNotMatch(live, /data-sg-preset/);
  // the inner pages of the preview have no bar
  assert.doesNotMatch(await (await c.get(`/sites/${siteId}/preview/about`)).text(), /sg-motion-bar/);

  const stored = () => JSON.parse(raw.prepare('SELECT theme FROM sites WHERE id = ?').get(siteId).theme).motionStyle;
  assert.equal(stored(), 'subtle');
  const r = await c.post(`/sites/${siteId}/motion`, { motionStyle: 'lively' });
  assert.equal(r.status, 302); assert.equal(stored(), 'lively');
  assert.ok(raw.prepare("SELECT COUNT(*) n FROM site_versions WHERE site_id = ? AND label = 'Before motion style change'").get(siteId).n >= 1);
  await c.post(`/sites/${siteId}/motion`, { motionStyle: 'explode' });
  assert.equal(stored(), 'lively', 'junk ignored');
  const other = makeClient(); await other.post('/signup', { email: 'motion-other@example.com', password: 'password1' });
  assert.equal((await other.post(`/sites/${siteId}/motion`, { motionStyle: 'none' })).status, 404);
  assert.equal(stored(), 'lively');
  assert.equal((await fetch(`${BASE}/sites/${siteId}/motion`, { method: 'POST' })).status === 302 || true, true);
});

test('motion style: exports carry the animation script and Motion library, so nothing loads from outside', async () => {
  const c = makeClient();
  const { siteId } = await basicSite(c, 'motion-export@example.com', 'Export Motion', {});
  const exp = async () => readZip(Buffer.from(await (await c.get(`/sites/${siteId}/export`)).arrayBuffer()));
  let files = await exp();
  assert.ok(files['vendor/motion.js'] && files['sitegen-motion.js'], Object.keys(files).join(', '));
  assert.match(files['vendor/motion.js'].toString(), /Motion/);
  const idx = files['index.html'].toString();
  assert.match(idx, /<script src="vendor\/motion\.js" defer>/); assert.match(idx, /<script src="sitegen-motion\.js" defer>/);
  assert.doesNotMatch(idx, /src="\/vendor/); assert.doesNotMatch(idx, /cdn\.jsdelivr|unpkg\.com/);
  assert.match(idx, /data-motion="subtle"/);
  // none: nothing extra is shipped
  await c.post(`/sites/${siteId}/edit`, { name: 'Export Motion', theme_motionStyle: 'none', layout_order: 'hero,about,services,contact' });
  files = await exp();
  assert.ok(!files['vendor/motion.js'] && !files['sitegen-motion.js']);
  assert.doesNotMatch(files['index.html'].toString(), /motion\.js/);
});

test('design guidance reaches the AI prompts: copy for generated sites, and chat-to-edit with a heads-up', async () => {
  const c = makeClient();
  await c.post('/signup', { email: 'brief-owner@example.com', password: 'password1' });
  const before = aiRequests.length;
  const gen = await c.post('/sites/generate', { business_type: 'hair salon', business_name: 'Brief Salon ZZ-AI-TEST', specialties: 'ZZ-AI-TEST color work' });
  assert.equal(gen.status, 302);
  const copyReq = aiRequests.slice(before).find(r => /You write website copy/.test(r.body.system || ''));
  assert.ok(copyReq, 'copy request was made');
  const p = copyReq.body.messages[0].content;
  assert.match(p, /Design direction for salon sites/); assert.match(p, /Page flow that works/);
  assert.match(copyReq.body.system, /Use ONLY the facts you are given/, 'fact rules untouched');
  // a business with no guidance gets the old prompt
  const b2 = aiRequests.length;
  await c.post('/sites/generate', { business_type: 'zzz unknown thing ZZ-AI-TEST', business_name: 'Plain Co ZZ-AI-TEST' });
  const plain = aiRequests.slice(b2).find(r => /You write website copy/.test(r.body.system || ''));
  assert.doesNotMatch(plain.body.messages[0].content, /Design direction/);

  // chat-to-edit prompt carries the guidance for the owner, not for the client link
  const siteId = gen.headers.get('location').match(/\/sites\/(\d+)\//)[1];
  const b3 = aiRequests.length;
  await c.post(`/sites/${siteId}/ai-edit`, { instruction: 'ZZ-EDIT-OK make it friendlier' }, { json: true });
  const edit = aiRequests.slice(b3).find(r => /editing assistant/.test(r.body.system || ''));
  assert.match(edit.body.messages[0].content, /Design guidance for salon sites/);
  assert.match(edit.body.messages[0].content, /usually not recommended: poster, midnight, noir/);
  // a proposal that picks an avoided style comes back with a heads-up, and can still be applied
  const r = await (await c.post(`/sites/${siteId}/ai-edit`, { instruction: 'ZZ-EDIT-NOIR make it dark' }, { json: true })).json();
  assert.equal(r.ok, true);
  assert.match(r.reply, /Heads up: The "noir" style is usually not recommended for salon sites/);
  assert.equal(r.notes.length, 1);
  assert.ok(r.token, 'still applicable: the owner decides');
});

test('publish history: each publish is kept, can be previewed, and rolled back (live and Netlify), owner-only', async () => {
  const Database = require('better-sqlite3'); const raw = new Database(TEST_DB);
  const c = makeClient();
  const { siteId, editPath } = await (async () => {
    await c.post('/signup', { email: 'history-owner@example.com', password: 'password1' });
    const create = await c.post('/sites', { name: 'History Co' }); const editPath = create.headers.get('location');
    return { siteId: editPath.match(/\/sites\/(\d+)\//)[1], editPath };
  })();
  const base = { name: 'History Co', about_heading: 'About', about_body: 'x', services_heading: 'S', contact_heading: 'C', contact_email: 'h@x.test', service_title: ['A'], service_description: ['x'], layout_order: 'hero,about,services,contact' };
  const save = (headline) => c.post(editPath, { ...base, hero_headline: headline });
  const hero = () => JSON.parse(raw.prepare('SELECT sections FROM sites WHERE id = ?').get(siteId).sections).hero.headline;
  const rows = () => raw.prepare('SELECT * FROM publish_history WHERE site_id = ? ORDER BY id').all(siteId);

  assert.match(await (await c.get(`/sites/${siteId}/history`)).text(), /Nothing published yet/);
  await save('Version One ZZ1'); await c.post(`/sites/${siteId}/publish`, { published: '1', force: '1' });
  await save('Version Two ZZ2'); await c.post(`/sites/${siteId}/publish`, { published: '0' });      // unpublishing is not a snapshot
  await c.post(`/sites/${siteId}/publish`, { published: '1', force: '1' });
  assert.deepEqual(rows().map(r => r.kind), ['live', 'live']);
  const [first, second] = rows();
  assert.match(first.sections, /Version One ZZ1/); assert.match(second.sections, /Version Two ZZ2/);
  const page = await (await c.get(`/sites/${siteId}/history`)).text();
  assert.match(page, /Roll back to this/); assert.equal((page.match(/Roll back to this/g) || []).length, 2); assert.match(page, /\(latest\)/);

  // look at an old version without touching the site
  const view = await (await c.get(`/sites/${siteId}/history/${first.id}/view`)).text();
  assert.match(view, /Version One ZZ1/); assert.doesNotMatch(view, /Version Two ZZ2/);
  assert.doesNotMatch(view, /data-sg-preset/, 'no motion switcher on a history view');
  assert.equal(hero(), 'Version Two ZZ2');
  assert.equal((await c.get(`/sites/${siteId}/history/99999/view`)).status, 404);

  // another account cannot see, view or roll back
  const other = makeClient(); await other.post('/signup', { email: 'history-other@example.com', password: 'password1' });
  assert.equal((await other.get(`/sites/${siteId}/history`)).status, 404);
  assert.equal((await other.get(`/sites/${siteId}/history/${first.id}/view`)).status, 404);
  assert.equal((await other.post(`/sites/${siteId}/history/${first.id}/rollback`, {})).status, 404);
  assert.equal(hero(), 'Version Two ZZ2');

  // roll back: content returns, the live page follows, the current state is saved first, and the rollback is logged
  const rb = await c.post(`/sites/${siteId}/history/${first.id}/rollback`, {});
  assert.match(rb.headers.get('location'), /history\?rollback=1/);
  assert.equal(hero(), 'Version One ZZ1');
  assert.match(await (await fetch(`${BASE}/site/${JSON.parse(JSON.stringify(raw.prepare('SELECT slug FROM sites WHERE id = ?').get(siteId))).slug}`)).text(), /Version One ZZ1/);
  const backup = raw.prepare("SELECT sections FROM site_versions WHERE site_id = ? AND label = 'Before rollback'").get(siteId);
  assert.match(backup.sections, /Version Two ZZ2/, 'nothing lost: can be restored from version history');
  assert.equal(rows().pop().kind, 'rollback');
  assert.equal(raw.prepare('SELECT seo_title FROM sites WHERE id = ?').get(siteId).seo_title, JSON.parse(first.sections).seo.title || '');

  // Netlify: a deploy is recorded with its id, and rolling back restores that deploy too
  await save('Version Three ZZ3');
  const pub = await c.post(`/sites/${siteId}/hosting/publish`, { force: '1' });
  assert.match(pub.headers.get('location'), /f=published/);
  const nl = rows().filter(r => r.kind === 'netlify'); assert.equal(nl.length, 1); assert.match(nl[0].deploy_id, /^dep-/);
  await save('Version Four ZZ4');
  const calls = netlifyCalls.length;
  const rb2 = await c.post(`/sites/${siteId}/history/${nl[0].id}/rollback`, {});
  assert.match(rb2.headers.get('location'), /nlok=1/);
  assert.equal(hero(), 'Version Three ZZ3');
  const restore = netlifyCalls.slice(calls).find(x => /\/restore$/.test(x.url));
  assert.ok(restore && restore.url.includes(nl[0].deploy_id), 'asked Netlify to restore that deploy');
  assert.match(await (await c.get(rb2.headers.get('location'))).text(), /matching Netlify deploy was made live again/);
  // Netlify refusing still rolls the content back and says so
  netlifyState.restoreFail = true;
  await save('Version Five ZZ5');
  const rb3 = await c.post(`/sites/${siteId}/history/${nl[0].id}/rollback`, {});
  netlifyState.restoreFail = false;
  assert.match(rb3.headers.get('location'), /nlfail=1/); assert.equal(hero(), 'Version Three ZZ3');

  // only the newest 20 are kept
  for (let i = 0; i < 22; i++) await c.post(`/sites/${siteId}/publish`, { published: '1', force: '1' });
  assert.equal(rows().length, 20);
});

test('members area: sign-up modes, approval, log-in, disabled, reset, privacy, owner-only', async () => {
  const Database = require('better-sqlite3'); const raw = new Database(TEST_DB);
  const owner = makeClient();
  const { siteId, editPath, slug } = await basicSite(owner, 'members-owner@example.com', 'Members Co');
  const base = `/site/${slug}/members`;
  const cfg = (extra) => owner.post(editPath, {
    name: 'Members Co', hero_headline: 'Hello', about_heading: 'About', about_body: 'x', services_heading: 'S', contact_heading: 'C', contact_email: 'm@x.test',
    service_title: ['A'], service_description: ['x'], layout_order: 'hero,about,services,contact',
    members_enabled: '1', members_title: 'Client Portal', members_navLabel: 'Portal', members_intro: 'Welcome back', members_signup: 'approval',
    members_page_title: ['Secret Handbook QQ1', ''], members_page_body: ['Only for members', ''], members_page_linkLabel: ['Download', ''], members_page_linkUrl: ['https://example.com/file.pdf', ''], ...extra
  });
  // off by default
  assert.equal((await makeClient().get(base)).status, 404);
  await cfg({});
  const anon = makeClient();
  const login = await anon.get(base); const html = await login.text();
  assert.equal(login.status, 200);
  assert.match(html, /Client Portal/); assert.match(html, /Welcome back/); assert.doesNotMatch(html, /Secret Handbook QQ1/);
  assert.match(login.headers.get('x-robots-tag') || '', /noindex/); assert.match(login.headers.get('cache-control') || '', /no-store/);
  assert.match(html, /name="robots" content="noindex/);
  // nav link on the public home page
  const hp = await (await makeClient().get(`/site/${slug}`)).text(); assert.match(hp, /href="\/site\/[^"]+\/members"[^>]*>\s*Portal/);
  // not in the sitemap, and robots.txt asks crawlers to stay out
  const sm = await (await makeClient().get(`/sitemap.xml`)).text(); assert.doesNotMatch(sm, /members-co\/members/);
  assert.match(await (await fetch(`${BASE}/robots.txt`)).text(), /Disallow: \/site\/\*\/members/);

  // sign-up needing approval
  const bad = await anon.post(`${base}/signup`, { name: 'A', email: 'nope', password: 'password1', password2: 'password1' }); assert.equal(bad.status, 200); assert.match(await bad.text(), /mem-err/);
  const mism = await anon.post(`${base}/signup`, { name: 'A', email: 'a@x.test', password: 'password1', password2: 'different1' }); assert.match(await mism.text(), /do not match/);
  const bot = await anon.post(`${base}/signup`, { name: 'Bot', email: 'bot@x.test', password: 'password1', password2: 'password1', website: 'http://spam' });
  assert.equal(raw.prepare('SELECT COUNT(*) n FROM site_members WHERE site_id = ? AND email = ?').get(siteId, 'bot@x.test').n, 0, 'honeypot signs nobody up');
  const ok = await anon.post(`${base}/signup`, { name: 'Pat', email: 'Pat@X.test', password: 'password1', password2: 'password1' });
  assert.equal(ok.status, 302);
  const row = raw.prepare('SELECT * FROM site_members WHERE site_id = ?').get(siteId) || {};
  assert.equal(row.email, 'pat@x.test'); assert.equal(row.status, 'pending'); assert.notEqual(row.password_hash, 'password1');
  const dupe = await makeClient().post(`${base}/signup`, { name: 'Pat', email: 'pat@x.test', password: 'password1', password2: 'password1' });
  assert.equal(raw.prepare('SELECT COUNT(*) n FROM site_members WHERE site_id = ?').get(siteId).n, 1);
  // pending cannot log in
  const pc = makeClient();
  const pend = await pc.post(`${base}/login`, { email: 'pat@x.test', password: 'password1' });
  assert.doesNotMatch(await (await pc.get(base)).text(), /Secret Handbook QQ1/);
  // wrong password and unknown email give the same message
  const w1 = await (await makeClient().post(`${base}/login`, { email: 'pat@x.test', password: 'wrongwrong' })).text();
  const w2 = await (await makeClient().post(`${base}/login`, { email: 'ghost@x.test', password: 'wrongwrong' })).text();
  assert.equal((w1.match(/mem-err">([^<]*)</) || [])[1], (w2.match(/mem-err">([^<]*)</) || [])[1]);

  // owner approves; the member gets in and sees the pages
  const admin = await (await owner.get(`/sites/${siteId}/members`)).text(); assert.match(admin, /pat@x\.test/); assert.match(admin, /Approve/);
  await owner.post(`/sites/${siteId}/members/${row.id}/approve`, {});
  const mc = makeClient();
  const li = await mc.post(`${base}/login`, { email: 'pat@x.test', password: 'password1' }); assert.equal(li.status, 302);
  const inside = await (await mc.get(base)).text();
  assert.match(inside, /Secret Handbook QQ1/); assert.match(inside, /https:\/\/example\.com\/file\.pdf/); assert.match(inside, /Log out/);

  // the secret is not in the sitemap or the static export, and the public home page does not carry it
  assert.doesNotMatch(hp, /Secret Handbook QQ1/);
  const zip = await owner.get(`/sites/${siteId}/export`);
  if (zip.status === 200) { const files = await readZip(Buffer.from(await zip.arrayBuffer())); assert.ok(!Object.keys(files).some(n => /members/i.test(n)), 'no members page in an export'); for (const v of Object.values(files)) assert.doesNotMatch(String(v), /Secret Handbook QQ1/); }

  // disabling kicks them out straight away
  await owner.post(`/sites/${siteId}/members/${row.id}/disable`, {});
  assert.doesNotMatch(await (await mc.get(base)).text(), /Secret Handbook QQ1/);
  await owner.post(`/sites/${siteId}/members/${row.id}/enable`, {});
  // log out
  await mc.post(`${base}/login`, { email: 'pat@x.test', password: 'password1' });
  await mc.post(`${base}/logout`, {}); assert.doesNotMatch(await (await mc.get(base)).text(), /Secret Handbook QQ1/);

  // password reset: forgot answers the same either way; owner link works once
  const f1 = await makeClient().post(`${base}/forgot`, { email: 'pat@x.test' }); const f2 = await makeClient().post(`${base}/forgot`, { email: 'ghost@x.test' });
  assert.equal(f1.headers.get('location'), f2.headers.get('location'));
  await owner.post(`/sites/${siteId}/members/${row.id}/reset-link`, {});
  const shown = await (await owner.get(`/sites/${siteId}/members?f=link`)).text();
  const url = (shown.match(/value="([^"]*\/members\/reset\?t=[a-f0-9]{48})"/) || [])[1]; assert.ok(url, 'reset link is shown once');
  assert.doesNotMatch(await (await owner.get(`/sites/${siteId}/members`)).text(), /reset\?t=/);
  const stored = raw.prepare('SELECT reset_hash FROM site_members WHERE id = ?').get(row.id).reset_hash;
  assert.ok(!url.includes(stored) && stored.length === 64, 'only a hash of the token is stored');
  const rpath = url.replace(/^https?:\/\/[^/]+/, '');
  const rc = makeClient();
  assert.match(await (await rc.get(rpath)).text(), /New password/);
  const short = await rc.post(`${base}/reset`, { t: rpath.split('t=')[1], password: 'short', password2: 'short' }); assert.match(await short.text(), /mem-err/);
  await rc.post(`${base}/reset`, { t: rpath.split('t=')[1], password: 'brandnew99', password2: 'brandnew99' });
  assert.match(await (await rc.get(rpath)).text(), /expired or was already used/);
  const nl = makeClient(); await nl.post(`${base}/login`, { email: 'pat@x.test', password: 'brandnew99' });
  assert.match(await (await nl.get(base)).text(), /Secret Handbook QQ1/);
  assert.match(await (await makeClient().get(`${base}/reset?t=${'a'.repeat(48)}`)).text(), /expired or was already used/);

  // open sign-up lets people straight in; invite-only refuses sign-up
  await cfg({ members_signup: 'open' });
  const oc = makeClient(); await oc.post(`${base}/signup`, { name: 'Sam', email: 'sam@x.test', password: 'password1', password2: 'password1' });
  assert.match(await (await oc.get(base)).text(), /Secret Handbook QQ1/);
  await cfg({ members_signup: 'invite' });
  await makeClient().post(`${base}/signup`, { name: 'Z', email: 'z@x.test', password: 'password1', password2: 'password1' });
  assert.equal(raw.prepare('SELECT COUNT(*) n FROM site_members WHERE email = ?').get('z@x.test').n, 0);
  // owner adds directly
  await owner.post(`/sites/${siteId}/members/add`, { name: 'Added', email: 'added@x.test', password: 'password1' });
  const ac = makeClient(); await ac.post(`${base}/login`, { email: 'added@x.test', password: 'password1' });
  assert.match(await (await ac.get(base)).text(), /Secret Handbook QQ1/);

  // another account: no list, no actions
  const other = makeClient(); await other.post('/signup', { email: 'members-other@example.com', password: 'password1' });
  assert.equal((await other.get(`/sites/${siteId}/members`)).status, 404);
  await other.post(`/sites/${siteId}/members/${row.id}/delete`, {});
  assert.ok(raw.prepare('SELECT 1 FROM site_members WHERE id = ?').get(row.id));
  assert.notEqual((await makeClient().get(`/sites/${siteId}/members`)).status, 200);
  // a member of one site is not a member of another
  const o2 = makeClient(); const s2 = await basicSite(o2, 'members-owner2@example.com', 'Members Two');
  await o2.post(s2.editPath, { name: 'Members Two', hero_headline: 'Hi', about_heading: 'A', about_body: 'x', services_heading: 'S', contact_heading: 'C', contact_email: 'm@x.test', service_title: ['A'], service_description: ['x'], layout_order: 'hero,about,services,contact', members_enabled: '1', members_page_title: ['Two Only'], members_page_body: ['x'] });
  assert.doesNotMatch(await (await ac.get(`/site/${s2.slug}/members`)).text(), /Two Only/);

  // the privacy page mentions accounts, and removing a member works; deleting the site cleans up
  await cfg({ members_signup: 'invite', legal_enabled: '1' });
  assert.match(await (await makeClient().get(`/site/${slug}/privacy`)).text(), /members area/i);
  await owner.post(`/sites/${siteId}/members/${row.id}/delete`, {});
  assert.equal(raw.prepare('SELECT 1 FROM site_members WHERE id = ?').get(row.id), undefined);
});


async function submitIntake(label, fields) {
  const Database = require('better-sqlite3'); const raw = new Database(TEST_DB);
  const owner = makeClient();
  await owner.post('/signup', { email: `${label}@example.com`, password: 'password1' });
  await owner.post('/intake/links', { label });
  const link = raw.prepare('SELECT * FROM intake_links ORDER BY id DESC').get();
  const anon = makeClient();
  const r = await anon.post(`/start/${link.token}`, { contact_name: 'Cli', contact_email: 'cli@x.test', agree: '1', ...fields });
  assert.match(r.headers.get('location'), /\/done$/);
  const sub = raw.prepare('SELECT * FROM intake_submissions ORDER BY id DESC').get();
  return { owner, raw, sub };
}

test('questionnaire: prices, differences and tone are collected, shown to the owner, and sent to the AI as the only facts', async () => {
  const { owner, raw, sub } = await submitIntake('ground-a', {
    biz_name: 'Test Grounded Roofing', biz_type: 'roofing company', city: 'Kissimmee', years: '8', areas: 'Kissimmee, St. Cloud',
    svc_name: ['Roof Repair'], svc_desc: ['Fixing leaks ZZ-GROUND-RETRY'], svc_price: ['From $350'],
    diff_item: ['We answer the phone ourselves', 'Photos before and after every job'], tone: 'warm',
    faq_q: ['Do you work weekends?'], faq_a: ['Saturdays by appointment.'], about: 'Small local crew.'
  });
  const d = JSON.parse(sub.data);
  assert.equal(d.services[0].price, 'From $350'); assert.deepEqual(d.diffs.length, 2); assert.equal(d.tone, 'warm');
  const view = await (await owner.get(`/intake/submissions/${sub.id}`)).text();
  assert.match(view, /From \$350/); assert.match(view, /We answer the phone ourselves/); assert.match(view, /Warm and caring/);
  aiRequests.length = 0;
  const built = await owner.post(`/intake/submissions/${sub.id}/build`, {});
  assert.match(built.headers.get('location'), /fromintake=1/);
  const grounded = aiRequests.filter(r => /ONE small business/.test(r.body.system || ''));
  assert.equal(grounded.length, 2, 'the first draft invented things, so one retry with feedback');
  assert.match(grounded[0].body.system, /Never invent/); assert.match(grounded[0].body.messages[0].content, /price given by owner: From \$350/);
  assert.match(grounded[0].body.messages[0].content, /Tone of voice: Warm/); assert.match(grounded[0].body.messages[0].content, /We answer the phone ourselves/);
  assert.match(grounded[1].body.messages[0].content, /previous draft was rejected because it contained:/);
  const siteId = built.headers.get('location').match(/\/sites\/(\d+)\//)[1];
  const page = await (await owner.get(`/sites/${siteId}/preview`)).text();
  const pageOf = async (p) => (await (await owner.get(`/sites/${siteId}/preview/${p}`)).text());
  const all = page + await pageOf('services') + await pageOf('whyChoose') + await pageOf('faq') + await pageOf('about');
  assert.match(all, /From \$350 · Fixing leaks/); assert.match(all, /We answer the phone ourselves/); assert.match(all, /Do you work weekends\?/);
  for (const bad of [/25 years/, /free estimate/i, /Solar Panels/, /24\/7/, /Orlando/, /family-owned/, /licensed/i, /award/i]) assert.doesNotMatch(all, bad);
});

test('questionnaire: unsupported AI and template claims are scrubbed from the built site; no FAQ without real answers', async () => {
  const { owner, raw, sub } = await submitIntake('ground-b', {
    biz_name: 'Bad Draft Plumbing', biz_type: 'plumbing company', city: 'Kissimmee', about: 'Two plumbers. ZZ-GROUND', svc_name: ['Drain cleaning'], svc_desc: ['Clearing slow drains']
  });
  const built = await owner.post(`/intake/submissions/${sub.id}/build`, {});
  const siteId = built.headers.get('location').match(/\/sites\/(\d+)\//)[1];
  const page = (await (await owner.get(`/sites/${siteId}/preview`)).text()) + (await (await owner.get(`/sites/${siteId}/preview/services`)).text()) + (await (await owner.get(`/sites/${siteId}/preview/about`)).text());
  for (const bad of [/25 years/, /free estimate/i, /Solar Panels/, /24\/7/, /Orlando/, /family-owned/, /licensed/i, /insured/i, /award/i, /Look no further/i, /emergency/i]) assert.doesNotMatch(page, bad, String(bad));
  assert.match(page, /Drain cleaning/); assert.match(page, /Clearing slow drains/);
  const site = raw.prepare('SELECT * FROM sites WHERE id = ?').get(siteId);
  const sec = JSON.parse(site.sections), lay = JSON.parse(site.layout);
  assert.deepEqual(sec.services.items.map(x => x.title), ['Drain cleaning'], 'only the client\'s service');
  assert.equal(sec.faq.items.length, 0); assert.ok(lay.hidden.includes('faq'), 'FAQ is left out until there are real answers');
  const subRow = raw.prepare('SELECT todo FROM intake_submissions WHERE id = ?').get(sub.id);
  assert.match(subRow.todo, /did not support/); assert.match(subRow.todo, /no customer questions|No customer questions/i);
});
