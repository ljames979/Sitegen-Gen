// Matching color palettes. Pure functions, used by the editor in the browser
// (window.Palette) and by the tests (require). A palette is { primary, accent }:
// primary = buttons and links (white text sits on it), accent = dark bands and
// the footer (white text sits on it), so both must stay readable against white.
(function (root) {
  'use strict';
  var clamp = function (n, lo, hi) { return Math.max(lo, Math.min(hi, n)); };

  function parseHex(s) {
    s = String(s || '').trim().replace(/^#/, '');
    if (/^[0-9a-f]{3}$/i.test(s)) s = s.split('').map(function (c) { return c + c; }).join('');
    return /^[0-9a-f]{6}$/i.test(s) ? '#' + s.toLowerCase() : null;
  }
  function hexToRgb(hex) { var n = parseInt((parseHex(hex) || '#000000').slice(1), 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; }
  function rgbToHex(r, g, b) { return '#' + [r, g, b].map(function (v) { return clamp(Math.round(v), 0, 255).toString(16).padStart(2, '0'); }).join(''); }
  function hexToHsl(hex) {
    var c = hexToRgb(hex).map(function (v) { return v / 255; }), mx = Math.max(c[0], c[1], c[2]), mn = Math.min(c[0], c[1], c[2]);
    var l = (mx + mn) / 2, d = mx - mn, h = 0, s = 0;
    if (d) {
      s = d / (1 - Math.abs(2 * l - 1));
      if (mx === c[0]) h = ((c[1] - c[2]) / d) % 6; else if (mx === c[1]) h = (c[2] - c[0]) / d + 2; else h = (c[0] - c[1]) / d + 4;
      h *= 60; if (h < 0) h += 360;
    }
    return { h: h, s: s, l: l };
  }
  function hslToHex(h, s, l) {
    h = ((h % 360) + 360) % 360; s = clamp(s, 0, 1); l = clamp(l, 0, 1);
    var c = (1 - Math.abs(2 * l - 1)) * s, x = c * (1 - Math.abs((h / 60) % 2 - 1)), m = l - c / 2, r = 0, g = 0, b = 0;
    if (h < 60) { r = c; g = x; } else if (h < 120) { r = x; g = c; } else if (h < 180) { g = c; b = x; }
    else if (h < 240) { g = x; b = c; } else if (h < 300) { r = x; b = c; } else { r = c; b = x; }
    return rgbToHex((r + m) * 255, (g + m) * 255, (b + m) * 255);
  }
  function luminance(hex) {
    var c = hexToRgb(hex).map(function (v) { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); });
    return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2];
  }
  function contrast(a, b) {
    var la = luminance(a), lb = luminance(b);
    return (Math.max(la, lb) + 0.05) / (Math.min(la, lb) + 0.05);
  }
  // darken (keeping the hue) until `hex` reaches `min` contrast against white
  function readableOnWhite(hex, min) {
    min = min || 4.5;
    var hsl = hexToHsl(hex), out = hex, guard = 0;
    while (contrast(out, '#ffffff') < min && hsl.l > 0.02 && guard++ < 100) { hsl.l -= 0.01; out = hslToHex(hsl.h, hsl.s, hsl.l); }
    return out;
  }
  // a dark companion in a given hue, for the accent role
  function dark(h, s, l) { return readableOnWhite(hslToHex(h, clamp(s, 0.25, 0.85), l), 7); }

  // Matching sets built from one brand color
  function suggestions(baseHex) {
    var base = parseHex(baseHex); if (!base) return [];
    var p0 = hexToHsl(base), h = p0.h, s = Math.max(p0.s, 0.2);
    var primary = readableOnWhite(base, 4.5);
    var pp = hexToHsl(primary);
    var mk = function (name, note, prim, acc) { return { name: name, note: note, primary: prim, accent: acc }; };
    var out = [
      mk('Same color, deeper', 'A dark shade of your color. Calm and consistent.', primary, dark(h, s, 0.17)),
      mk('Complementary', 'The opposite color for the dark areas. Stands out most.', primary, dark(h + 180, s * 0.8, 0.2)),
      mk('Neighbor (warm)', 'A close color toward warm tones.', primary, dark(h + 30, s * 0.8, 0.19)),
      mk('Neighbor (cool)', 'A close color toward cool tones.', primary, dark(h - 30, s * 0.8, 0.19)),
      mk('Triad', 'Two more colors spaced evenly around the wheel. Playful.', primary, dark(h + 120, s * 0.7, 0.2)),
      mk('Neutral slate', 'Your color with a dark slate. Safe and professional.', primary, '#1e293b'),
      mk('Softer', 'Less saturated. Gentler, more premium.', readableOnWhite(hslToHex(h, pp.s * 0.6, pp.l), 4.5), dark(h, s * 0.4, 0.2)),
      mk('Bolder', 'More saturated. Livelier.', readableOnWhite(hslToHex(h, Math.min(1, pp.s * 1.25 + 0.05), pp.l), 4.5), dark(h, Math.min(1, s * 1.1), 0.16))
    ];
    var seen = {};
    return out.filter(function (x) { var k = x.primary + x.accent; if (seen[k]) return false; seen[k] = 1; return true; });
  }

  // Ready-made palettes. `for` are words matched against the business type.
  var INDUSTRY = [
    { id: 'pet-warm', name: 'Friendly pets', primary: '#c2410c', accent: '#431407', for: ['pet', 'groom', 'dog', 'cat', 'vet', 'kennel', 'boarding'] },
    { id: 'pet-fresh', name: 'Fresh paws', primary: '#0f766e', accent: '#134e4a', for: ['pet', 'groom', 'dog', 'training', 'walk'] },
    { id: 'salon-rose', name: 'Rose salon', primary: '#be185d', accent: '#4a1d33', for: ['salon', 'hair', 'beauty', 'nail', 'lash', 'makeup', 'barber'] },
    { id: 'spa-calm', name: 'Calm spa', primary: '#0f766e', accent: '#1e3a3a', for: ['spa', 'wellness', 'massage', 'yoga', 'chiropract', 'clinic'] },
    { id: 'trust-navy', name: 'Trusted navy', primary: '#1d4ed8', accent: '#0f1f45', for: ['insurance', 'law', 'attorney', 'account', 'financ', 'consult', 'real estate', 'dental', 'dentist'] },
    { id: 'law-gold', name: 'Navy and brass', primary: '#92400e', accent: '#14213d', for: ['law', 'attorney', 'insurance', 'account', 'financ'] },
    { id: 'green-grow', name: 'Garden green', primary: '#15803d', accent: '#14301e', for: ['landscap', 'lawn', 'garden', 'tree', 'pool', 'pest', 'clean', 'organic'] },
    { id: 'trade-blue', name: 'Reliable trades', primary: '#0369a1', accent: '#0c2a43', for: ['plumb', 'hvac', 'air', 'electric', 'roof', 'contract', 'handyman', 'pressure', 'wash'] },
    { id: 'trade-orange', name: 'Workwear orange', primary: '#c2410c', accent: '#1f2937', for: ['roof', 'contract', 'construct', 'paint', 'remodel', 'junk', 'moving', 'auto', 'repair'] },
    { id: 'auto-red', name: 'Garage red', primary: '#b91c1c', accent: '#1c1917', for: ['auto', 'car', 'detail', 'mechanic', 'tire', 'tattoo'] },
    { id: 'food-warm', name: 'Warm kitchen', primary: '#b45309', accent: '#3b1d0b', for: ['restaurant', 'cafe', 'bakery', 'catering', 'food', 'coffee', 'bar'] },
    { id: 'care-soft', name: 'Gentle care', primary: '#4f46e5', accent: '#1e1b4b', for: ['home care', 'senior', 'care', 'child', 'daycare', 'health', 'therapy'] },
    { id: 'tech-violet', name: 'Modern tech', primary: '#6d28d9', accent: '#1e1038', for: ['it ', 'tech', 'software', 'computer', 'web', 'design', 'photo', 'studio'] },
    { id: 'earth', name: 'Earthy', primary: '#4d7c0f', accent: '#2f2a1d', for: ['farm', 'organic', 'eco', 'craft', 'florist', 'flower'] },
    { id: 'mono', name: 'Black and white', primary: '#111827', accent: '#000000', for: ['photo', 'studio', 'gallery', 'art', 'fashion', 'boutique'] },
    { id: 'sunny', name: 'Sunny', primary: '#b45309', accent: '#78350f', for: ['party', 'event', 'rental', 'kids', 'fun', 'florida'] }
  ];
  function industryFor(businessType) {
    var t = ' ' + String(businessType || '').toLowerCase() + ' ';
    var scored = INDUSTRY.map(function (p, i) {
      var hit = p.for.some(function (w) { return t.indexOf(w) !== -1; });
      return { p: p, hit: hit, i: i };
    });
    scored.sort(function (a, b) { return (b.hit - a.hit) || (a.i - b.i); });
    return scored.map(function (x) { return { id: x.p.id, name: x.p.name, primary: x.p.primary, accent: x.p.accent, match: x.hit }; });
  }


  // Dominant colors of an image. `data` is RGBA pixel data (canvas ImageData.data).
  // Transparent and near-white pixels (usually background) are ignored; colorful
  // pixels count for more than grey ones. Returns up to `max` hex colors, best first.
  function extract(data, max) {
    max = max || 5;
    var buckets = {}, n = data.length;
    for (var i = 0; i + 3 < n; i += 4) {
      var a = data[i + 3]; if (a < 128) continue;
      var r = data[i], g = data[i + 1], b = data[i + 2];
      var mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (mx + mn) / 510, sat = mx === mn ? 0 : (mx - mn) / (255 - Math.abs(mx + mn - 255));
      if (l > 0.93) continue;            // paper white
      var key = (r >> 4) + ',' + (g >> 4) + ',' + (b >> 4);
      var w = 0.25 + sat * 1.5 - (l < 0.08 ? 0.15 : 0);
      var e = buckets[key] || (buckets[key] = { r: 0, g: 0, b: 0, c: 0, w: 0 });
      e.r += r; e.g += g; e.b += b; e.c++; e.w += Math.max(0.02, w);
    }
    var list = Object.keys(buckets).map(function (k) { var e = buckets[k]; return { hex: rgbToHex(e.r / e.c, e.g / e.c, e.b / e.c), w: e.w }; });
    list.sort(function (x, y) { return y.w - x.w; });
    var out = [];
    list.forEach(function (c) {
      if (out.length >= max) return;
      var close = out.some(function (o) { var a = hexToRgb(o.hex), b = hexToRgb(c.hex); return Math.abs(a[0] - b[0]) + Math.abs(a[1] - b[1]) + Math.abs(a[2] - b[2]) < 90; });
      if (close) { var m = out.filter(function (o) { var a = hexToRgb(o.hex), b = hexToRgb(c.hex); return Math.abs(a[0] - b[0]) + Math.abs(a[1] - b[1]) + Math.abs(a[2] - b[2]) < 90; })[0]; m.w += c.w; return; }
      out.push({ hex: c.hex, w: c.w });
    });
    out.sort(function (x, y) { return y.w - x.w; });
    return out.map(function (o) { return o.hex; });
  }
  // The logo's own two main colors as a palette (primary readable, accent a dark companion)
  function fromLogo(colors) {
    if (!colors || !colors.length) return null;
    var p = readableOnWhite(colors[0], 4.5), second = colors.slice(1).filter(function (c) { return c !== colors[0]; })[0];
    var h = hexToHsl(colors[0]);
    var acc = second ? readableOnWhite(hslToHex(hexToHsl(second).h, hexToHsl(second).s, Math.min(hexToHsl(second).l, 0.25)), 7) : dark(h.h, Math.max(h.s, 0.25), 0.17);
    return { name: 'Logo colors', note: 'Built from the two main colors in the logo.', primary: p, accent: acc };
  }

  // Readability report for the two colors. level: 'ok' | 'warn' | 'bad'
  function check(primary, accent) {
    var p = parseHex(primary), a = parseHex(accent), issues = [];
    var rate = function (r) { return r >= 4.5 ? 'ok' : r >= 3 ? 'warn' : 'bad'; };
    if (!p) issues.push({ level: 'bad', what: 'primary', text: 'The primary color is not a valid hex color like #2563eb.' });
    else { var rp = contrast(p, '#ffffff'); var lp = rate(rp); if (lp !== 'ok') issues.push({ level: lp, what: 'primary', ratio: rp, text: 'White button text on the primary color is ' + (lp === 'bad' ? 'hard' : 'a bit hard') + ' to read (contrast ' + rp.toFixed(1) + ', aim for 4.5 or more).', fix: readableOnWhite(p, 4.5) }); }
    if (!a) issues.push({ level: 'bad', what: 'accent', text: 'The accent color is not a valid hex color like #1e293b.' });
    else { var ra = contrast(a, '#ffffff'); var la = rate(ra); if (la !== 'ok') issues.push({ level: la, what: 'accent', ratio: ra, text: 'White text on the accent color (footer and dark bands) is ' + (la === 'bad' ? 'hard' : 'a bit hard') + ' to read (contrast ' + ra.toFixed(1) + ', aim for 4.5 or more).', fix: readableOnWhite(a, 4.5) }); }
    if (p && a && p === a) issues.push({ level: 'warn', what: 'both', text: 'Primary and accent are the same color, so buttons will not stand out from dark areas.' });
    return issues;
  }

  var api = { parseHex: parseHex, hexToHsl: hexToHsl, hslToHex: hslToHex, contrast: contrast, readableOnWhite: readableOnWhite, suggestions: suggestions, extract: extract, fromLogo: fromLogo, INDUSTRY: INDUSTRY, industryFor: industryFor, check: check };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.Palette = api;
})(typeof window !== 'undefined' ? window : this);
