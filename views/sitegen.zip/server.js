require('dotenv').config();

const path = require('path');
const os = require('os');
const crypto = require('crypto');
const fs = require('fs');
const express = require('express');
const session = require('express-session');
const bcrypt = require('bcryptjs');
const rateLimit = require('express-rate-limit');
const multer = require('multer');
const { nanoid } = require('nanoid');

const db = require('./db');
const cache = require('./cache');
const mailer = require('./mailer');
const reports = require('./reports');
const billing = require('./billing');
const fonts = require('./fonts');
const icons = require('./icons');
const { buildChecklist } = require('./checklist');
const forms = require('./forms');
const redirects = require('./redirects');
const legal = require('./legal');
const backups = require('./backups');
const leadsLib = require('./leads');
const chat = require('./chat');
const googleReviews = require('./googlereviews');
const calc = require('./calc');
const intake = require('./intake');
const grounding = require('./grounding');
const netlify = require('./netlify');
const payments = require('./payments');
const images = require('./images');
const { optimizeUpload } = images;
const { hasAiProvider, generateCopy, generateGroundedCopy, complete: aiComplete } = require('./ai');
const chatedit = require('./chatedit');
const accents = require('./accents');
const industryDesign = require('./industry-design');
const designOptionsLib = require('./design-options');
const quality = require('./quality');
const designBrief = require('./design-brief');
const membersLib = require('./members');
const { ZipArchive } = require('archiver');
const extraThemes = require('./themes');
const templateLooks = require('./template-looks');
const { defaultSections, defaultTheme, defaultLayout, SECTION_KEYS } = require('./defaults');
const { scrapeUrl } = require('./scraper');
const { servicesWithSlugs, areasWithSlugs, cleanGaId, cleanPixelId } = require('./local');
const { scrapeSocialInspiration, applySocialInspiration } = require('./social');
const { findTemplate, fillTemplate } = require('./templates');
const booking = require('./booking');
const { videoInfo } = require('./video');
const { fetchPhotoSet, hasPhotoProvider, searchPhotosPage } = require('./photos');
const { isValidEmail, isValidPassword, isValidHostname, isValidHexColor, isSafeUrl, str } = require('./validate');

// icon keys available for the "Why Choose Us" section — kept in sync with
// the inline SVG library rendered in views/public-site.ejs
const WHY_CHOOSE_ICONS = ['check', 'dollar', 'shield', 'clock', 'people', 'tools', 'star', 'truck', 'leaf', 'home'];

const app = express();
const PORT = process.env.PORT || 3000;
const IS_PROD = process.env.NODE_ENV === 'production';

if (IS_PROD && (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 16)) {
  console.warn('WARNING: SESSION_SECRET is missing or short. Set a long random value in .env before deploying.');
}

app.locals.fonts = fonts;
app.locals.extraThemes = extraThemes;
app.locals.formsLib = forms;
app.locals.legalLib = legal;
app.locals.calcLib = calc;
app.locals.intakeLib = intake;
app.locals.payLib = payments;
app.locals.accentsLib = accents;
app.locals.motionLib = require('./motion-presets');
app.locals.membersLib = require('./members');
app.locals.hasAi = hasAiProvider;
app.locals.leadsLibDefault = leadsLib.DEFAULT_TEXT;
app.locals.bookingLib = require('./booking');
app.locals.videoInfo = require('./video').videoInfo;
app.locals.icons = icons;
app.set('view engine', 'ejs');
app.set('views', __dirname + '/views');
app.set('trust proxy', 1);
// Stripe webhooks need the exact raw bytes to verify the signature, so this
// route is registered before the body parsers.
app.post('/stripe/webhook', express.raw({ type: '*/*', limit: '1mb' }), (req, res) => {
  const raw = Buffer.isBuffer(req.body) ? req.body.toString('utf8') : '';
  if (!billing.verifyWebhook(raw, req.get('stripe-signature'), process.env.STRIPE_WEBHOOK_SECRET)) return res.status(400).send('bad signature');
  let event;
  try { event = JSON.parse(raw); } catch (e) { return res.status(400).send('bad json'); }
  try { billing.applyEvent(db, event); } catch (err) { console.error('stripe webhook failed:', err.message); return res.status(500).send('error'); }
  res.json({ received: true });
});
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
// Smaller pages: gzip text responses with Node's built-in zlib (no extra package)
const zlib = require('zlib');
app.use((req, res, next) => {
  if (!/\bgzip\b/.test(req.headers['accept-encoding'] || '')) return next();
  const send = res.send.bind(res);
  res.send = function (body) {
    if (res.headersSent || res.get('Content-Encoding')) return send(body);
    let ct = String(res.get('Content-Type') || '');
    if (!ct && typeof body === 'string') { res.type('html'); ct = 'text/html'; }
    if ((typeof body === 'string' || Buffer.isBuffer(body)) && body.length > 1024 && /text|json|xml|svg/i.test(ct)) {
      res.set('Content-Encoding', 'gzip');
      res.vary('Accept-Encoding');
      return send(zlib.gzipSync(Buffer.isBuffer(body) ? body : Buffer.from(body), { level: 6 }));
    }
    return send(body);
  };
  next();
});

// uploaded photos get random file names, so browsers can keep them for a month
app.use('/uploads', express.static(path.join(__dirname, 'public', 'uploads'), { maxAge: '30d', immutable: true }));
app.use(express.static(__dirname + '/public'));

app.use(session({
  secret: process.env.SESSION_SECRET || 'dev-secret-change-me',
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 1000 * 60 * 60 * 24 * 7, httpOnly: true, sameSite: 'lax', secure: IS_PROD }
}));

// ---- rate limiting ----
// Auth endpoints and the URL importer (which makes this server fetch
// arbitrary third-party pages) are the routes most worth throttling.
// The test suite runs dozens of signups/imports/generates from a single IP
// in minutes (each test signs up its own user for isolation), which isn't a
// real abuse pattern — so limiting is skipped when running under the test
// harness (identified by DB_PATH, which only the test suite sets).
const isTestEnv = !!process.env.DB_PATH;

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 20,
  standardHeaders: true,
  legacyHeaders: false,
  skip: () => isTestEnv,
  message: 'Too many attempts. Please try again in a few minutes.'
});

const importLimiter = rateLimit({
  windowMs: 10 * 60 * 1000,
  limit: 10,
  standardHeaders: true,
  legacyHeaders: false,
  skip: () => isTestEnv,
  message: 'Too many import attempts. Please try again in a few minutes.'
});

const generateLimiter = rateLimit({
  windowMs: 10 * 60 * 1000,
  limit: 20,
  standardHeaders: true,
  legacyHeaders: false,
  skip: () => isTestEnv,
  message: 'Too many generate attempts. Please try again in a few minutes.'
});

// Public contact-form submissions (unauthenticated, one per visitor's site
// visit) get their own, stricter limiter since this endpoint is reachable
// by anyone who finds a published site.
const contactLimiter = rateLimit({
  windowMs: 10 * 60 * 1000,
  limit: 8,
  standardHeaders: true,
  legacyHeaders: false,
  skip: () => isTestEnv,
  message: 'Too many submissions from this device. Please try again later.'
});

// A small set of pleasant color pairs, assigned deterministically per
// business-template category so generated sites aren't all the same blue.
const GENERATE_PALETTE = [
  { primaryColor: '#2563eb', accentColor: '#1e293b' }, // blue
  { primaryColor: '#0f766e', accentColor: '#134e4a' }, // teal
  { primaryColor: '#b45309', accentColor: '#78350f' }, // amber
  { primaryColor: '#be123c', accentColor: '#881337' }, // rose
  { primaryColor: '#4d7c0f', accentColor: '#365314' }, // olive
  { primaryColor: '#7c3aed', accentColor: '#4c1d95' }, // violet
  { primaryColor: '#0369a1', accentColor: '#0c4a6e' }, // sky
  { primaryColor: '#c2410c', accentColor: '#7c2d12' }  // burnt orange
];

function colorForCategory(id) {
  let hash = 0;
  for (let i = 0; i < id.length; i++) hash = (hash * 31 + id.charCodeAt(i)) >>> 0;
  return GENERATE_PALETTE[hash % GENERATE_PALETTE.length];
}

// A darker shade of a brand color, used as the accent when the intake form
// supplies only one color.
function darkenHex(hex, amount = 0.45) {
  let h = hex.replace('#', '');
  if (h.length === 3 || h.length === 4) h = h.split('').map(c => c + c).join('');
  h = h.slice(0, 6);
  if (h.length !== 6) return hex;
  const n = parseInt(h, 16);
  const ch = (shift) => Math.round(((n >> shift) & 255) * (1 - amount));
  return '#' + [16, 8, 0].map(sh => ch(sh).toString(16).padStart(2, '0')).join('');
}

// ---- uploads ----
const upload = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => cb(null, path.join(__dirname, 'public', 'uploads')),
    filename: (req, file, cb) => {
      const ext = (path.extname(file.originalname) || '.jpg').toLowerCase().slice(0, 5);
      cb(null, `${nanoid(12)}${ext}`);
    }
  }),
  limits: { fileSize: 8 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    if (!/^image\/(png|jpe?g|gif|webp|svg\+xml)$/.test(file.mimetype)) {
      return cb(new Error('Only image files are allowed.'));
    }
    cb(null, true);
  }
});

// ---- helpers ----
function requireAuth(req, res, next) {
  if (!req.session.userId) return res.redirect('/login');
  next();
}

function slugify(s) {
  return s
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '') || 'site';
}

function uniqueSlug(base) {
  let slug = slugify(base);
  let candidate = slug;
  let i = 1;
  const exists = (s) => db.prepare('SELECT id FROM sites WHERE slug = ?').get(s);
  while (exists(candidate)) {
    candidate = `${slug}-${i}`;
    i++;
  }
  return candidate;
}

function getSite(id) {
  const row = db.prepare('SELECT * FROM sites WHERE id = ?').get(id);
  if (!row) return null;
  return hydrateSite(row);
}

function hydrateSite(row) {
  return {
    ...row,
    theme: JSON.parse(row.theme),
    sections: mergeSectionsWithDefaults(JSON.parse(row.sections)),
    layout: safeParseLayout(row.layout)
  };
}

// A site saved before a new section type or field existed (e.g. "Why Choose
// Us", or the social/acceptSubmissions fields on contact) won't have it in
// its stored JSON. Fill in just the missing pieces from the defaults so
// older sites keep working in the editor and on the public page, without
// touching anything the site owner actually set.
function mergeSectionsWithDefaults(sections) {
  const defaults = defaultSections();
  const merged = { ...defaults, ...sections };
  for (const key of Object.keys(defaults)) {
    if (sections[key] && typeof sections[key] === 'object' && typeof defaults[key] === 'object') {
      merged[key] = { ...defaults[key], ...sections[key] };
    }
  }
  merged.booking = booking.mergeBooking(sections.booking);
  if (merged.contact) {
    merged.contact.social = { ...defaults.contact.social, ...(sections.contact && sections.contact.social) };
  }
  return merged;
}

function safeParseLayout(raw) {
  let parsed = {};
  try { parsed = JSON.parse(raw || '{}'); } catch { parsed = {}; }
  const order = Array.isArray(parsed.order) && parsed.order.length ? parsed.order : defaultLayout().order;
  // make sure every known section key is present exactly once, even if the
  // stored layout predates a newly added section type
  const known = new Set(SECTION_KEYS);
  const cleanOrder = order.filter(k => known.has(k));
  for (const k of SECTION_KEYS) if (!cleanOrder.includes(k)) cleanOrder.push(k);
  const hidden = Array.isArray(parsed.hidden) ? parsed.hidden.filter(k => known.has(k)) : [];
  return { order: cleanOrder, hidden };
}

function saveVersion(siteId, theme, sections, layout, label = '') {
  db.prepare(
    'INSERT INTO site_versions (site_id, theme, sections, layout, label) VALUES (?, ?, ?, ?, ?)'
  ).run(siteId, JSON.stringify(theme), JSON.stringify(sections), JSON.stringify(layout), label);
  // keep only the most recent 10 versions per site
  const old = db.prepare(
    'SELECT id FROM site_versions WHERE site_id = ? ORDER BY id DESC LIMIT -1 OFFSET 10'
  ).all(siteId);
  if (old.length) {
    const ids = old.map(o => o.id);
    db.prepare(`DELETE FROM site_versions WHERE id IN (${ids.map(() => '?').join(',')})`).run(...ids);
  }
}

// Publish history: a snapshot each time the owner publishes (live toggle or Netlify), so any earlier published
// state can be previewed and rolled back to. Newest 20 kept per site.
function recordPublish(site, kind, deployId = '', label = '') {
  db.prepare('INSERT INTO publish_history (site_id, kind, theme, sections, layout, deploy_id, label) VALUES (?, ?, ?, ?, ?, ?, ?)')
    .run(site.id, kind, JSON.stringify(site.theme), JSON.stringify(site.sections), JSON.stringify(site.layout), String(deployId || ''), label);
  const old = db.prepare('SELECT id FROM publish_history WHERE site_id = ? ORDER BY id DESC LIMIT -1 OFFSET 20').all(site.id);
  if (old.length) db.prepare(`DELETE FROM publish_history WHERE id IN (${old.map(() => '?').join(',')})`).run(...old.map(o => o.id));
}

function invalidateSiteCache(site) {
  // the render cache is keyed per page ("slug:home", "slug:about", …), so
  // clearing a site means clearing every page it might have cached
  cache.invalidatePrefix(`${site.slug}:`);
  if (site.custom_domain) cache.invalidatePrefix(`${site.custom_domain}:`);
}

// ---- multi-page public site ----
// Every section except the hero gets its own page; the hero (plus the
// featured photo row) is the home page. PAGE_KEYS is SECTION_KEYS minus
// 'hero', i.e. the set of valid :page route params.
// (extraPages is a section in the editor but each of its items is its own page at /p/<name>)
const PAGE_KEYS = SECTION_KEYS.filter(k => k !== 'hero' && k !== 'extraPages');
// /<prefix>/<item> pages: which page type each URL prefix serves
const ITEM_ROUTES = { services: 'service', areas: 'area', blog: 'post', p: 'extra' };
const PAGE_LABELS = {
  about: 'About', services: 'Services', testimonials: 'Reviews',
  whyChoose: 'Why Choose Us', gallery: 'Gallery', faq: 'FAQ', blog: 'News & Tips', hours: 'Hours', contact: 'Contact'
};

// Some pages only make sense once there's something to show (no point
// linking to an empty testimonials or gallery page); about/services/contact
// always exist once their section isn't hidden.
function sectionHasContent(site, key) {
  const s = site.sections;
  switch (key) {
    case 'testimonials': return !!(s.testimonials && (s.testimonials.items.length || (s.testimonials.googleMode === 'reviews' && googleReviews.forSite(db, { id: site.id, sections: s }))));
    case 'whyChoose': return !!(s.whyChoose && s.whyChoose.items.length);
    case 'gallery': return !!(s.gallery && (s.gallery.images.length || (s.gallery.beforeAfter || []).length));
    case 'faq': return !!(s.faq && s.faq.items.length);
    case 'blog': return !!(s.blog && s.blog.items.length);
    case 'hours': return !!(s.hours && s.hours.items.length);
    default: return true; // about, services, contact
  }
}

function pageIsAvailable(site, key) {
  if (!PAGE_KEYS.includes(key)) return false;
  const hidden = site.layout ? site.layout.hidden : [];
  if (hidden.includes(key)) return false;
  return sectionHasContent(site, key);
}

// Owner-written extra pages (Financing, Service plans, ...): each item with
// text is its own page, shown wherever the "Extra pages" block sits in the order.
function extraPageList(site) {
  const hidden = (site.layout && site.layout.hidden) || [];
  if (hidden.includes('extraPages')) return [];
  return servicesWithSlugs((site.sections.extraPages.items || []).filter(i => i.title && i.body));
}

function buildNavPages(site, basePath, serverFeatures = true) {
  const order = (site.layout && site.layout.order) || PAGE_KEYS;
  const nav = [];
  for (const k of order) {
    if (k === 'extraPages') {
      for (const ex of extraPageList(site)) nav.push({ key: `p:${ex.slug}`, label: ex.title, href: `${basePath}/p/${ex.slug}` });
    } else if (pageIsAvailable(site, k)) {
      nav.push({
        key: k,
        label: (site.sections[k] && site.sections[k].heading) || PAGE_LABELS[k] || k,
        href: `${basePath}/${k}`
      });
    }
  }
  if (serverFeatures && site.sections.members && site.sections.members.enabled) nav.push({ key: 'members', label: membersLib.clean(site.sections.members).navLabel, href: `${basePath}/members` });
  if (serverFeatures && calc.isUsable(site.sections.calculator)) nav.push({ key: 'estimate', label: calc.normalize(site.sections.calculator).heading, href: `${basePath}/estimate` });
  return nav;
}

// Shared renderer for the home page and every section page, used by the
// slug-based route, the custom-domain route, and the editor's preview.
// `next` is only needed for the custom-domain middleware (so a render
// error can fall through instead of crashing); the ordinary routes pass
// null and just throw, matching how they behaved before.
// the site's own "page not found" page (same header, footer and style as the rest of the site)
function siteNotFound(req, res, next, siteIn, basePath, preview) {
  return renderSitePage(req, res.status(404), next, { site: siteIn, page: 'notfound', basePath, preview: !!preview, cacheKey: null });
}

function renderSitePage(req, res, next, { site: siteIn, page, basePath, preview, contactSent, contactError, cacheKey, serviceSlug, itemSlug, reviewThanks, reviewError, bookingView, hideMotionBar, memberView }) {
  const site = extraThemes.withPageStyle(siteIn, page);
  const slugArg = itemSlug || serviceSlug;
  const trustData = site.sections.trust || {};
  const services = servicesWithSlugs(site.sections.services.items);
  const areas = areasWithSlugs(trustData.serviceAreas, trustData.areaText);
  const posts = servicesWithSlugs(site.sections.blog.items);
  const extras = extraPageList(site);
  let service = null, area = null, post = null, extra = null;
  if (page === 'service') {
    service = pageIsAvailable(site, 'services') ? services.find(x => x.slug === slugArg) : null;
    if (!service) return siteNotFound(req, res, next, siteIn, basePath, preview);
  } else if (page === 'area') {
    area = areas.find(x => x.slug === slugArg);
    if (!area) return siteNotFound(req, res, next, siteIn, basePath, preview);
  } else if (page === 'post') {
    post = pageIsAvailable(site, 'blog') ? posts.find(x => x.slug === slugArg) : null;
    if (!post) return siteNotFound(req, res, next, siteIn, basePath, preview);
  } else if (page === 'extra') {
    extra = extras.find(x => x.slug === slugArg);
    if (!extra) return siteNotFound(req, res, next, siteIn, basePath, preview);
  } else if (page === 'book') {
    if (!site.sections.booking.enabled) return siteNotFound(req, res, next, siteIn, basePath, preview);
  } else if (page === 'members') {
    if (!(site.sections.members && site.sections.members.enabled)) return siteNotFound(req, res, next, siteIn, basePath, preview);
  } else if (page !== 'home' && page !== 'thank-you' && page !== 'review' && page !== 'notfound' && !(legal.PAGES.includes(page) && legal.enabled(site)) && !(page === 'estimate' && calc.isUsable(site.sections.calculator)) && !pageIsAvailable(site, page)) {
    return siteNotFound(req, res, next, siteIn, basePath, preview);
  }
  // cookie-free page-view count (live pages only, not the owner's preview, not bots)
  if (!preview && page !== 'notfound' && req.method === 'GET' && !reports.isBot(req.get('user-agent'))) {
    try { reports.recordView(db, site.id, service ? `services/${service.slug}` : area ? `areas/${area.slug}` : post ? `blog/${post.slug}` : extra ? `p/${extra.slug}` : page); } catch (e) { /* counting must never break a page */ }
  }
  const origin = `${req.protocol}://${req.get('host')}`;
  if (cacheKey) cacheKey = `${cacheKey}@${req.get('host')}`;
  const skipCache = !cacheKey || page === 'book' || page === 'estimate' || contactSent || contactError || reviewThanks || reviewError;
  if (!skipCache) {
    const cached = cache.get(cacheKey);
    if (cached) return res.send(cached);
  }
  const locals = {
    site, preview: !!preview, hideMotionBar: !!hideMotionBar, page, basePath, origin, services, service, areas, area, posts, post, extras, extra,
    navPages: buildNavPages(site, basePath),
    estimateError: str(req.query && req.query.error, 140),
    googleData: (preview ? null : googleReviews.forSite(db, site, () => cache.clear())),
    contactSent: !!contactSent, contactError: !!contactError,
    reviewThanks: !!reviewThanks, reviewError: !!reviewError,
    bookingView: bookingView || { mode: 'form', values: {} },
    memberView: memberView || { mode: 'login' },
    payOn: payReady(siteIn, site), payCur: (site.sections.payments || {}).currency || 'usd', buyLabel: (site.sections.payments || {}).buyLabel || 'Pay online'
  };
  res.render('public-site', locals, (err, html) => {
    if (err) {
      console.error('Render error:', err.message);
      if (next) return next(err);
      return res.status(500).send('Something went wrong rendering this page.');
    }
    html = images.optimizeHtml(html, { onVariants: () => cache.clear() });
    if (!skipCache) cache.set(cacheKey, html);
    res.send(html);
  });
}

// Emails the site owner about a new lead. Never blocks or fails the visitor's
// submission: it runs in the background and any error is only logged.
function notifyOwner(req, row, lead, imageUrl) {
  if (!mailer.isConfigured()) return;
  try {
    const contact = hydrateSite(row).sections.contact;
    const to = (contact.notifyEmail && isValidEmail(contact.notifyEmail)) ? contact.notifyEmail : contact.email;
    if (!to) return;
    const base = `${req.protocol}://${req.get('host')}`;
    mailer.sendLeadAlert({
      to,
      siteName: row.name,
      lead,
      leadsUrl: `${base}/sites/${row.id}/leads`,
      photoUrl: imageUrl ? `${base}${imageUrl}` : ''
    }).catch(err => console.error('Lead email failed:', err.message));
  } catch (err) {
    console.error('Lead email failed:', err.message);
  }
}

const reviewLimiter = rateLimit({
  windowMs: 10 * 60 * 1000, limit: 5, standardHeaders: true, legacyHeaders: false,
  skip: () => isTestEnv, message: 'Too many submissions from this device. Please try again later.'
});
const reviewRequestLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, limit: 30, standardHeaders: true, legacyHeaders: false,
  skip: () => isTestEnv, message: 'Too many review requests sent this hour. Please try again later.'
});

// A customer-written review. It is only stored as "pending"; nothing appears
// on the site until the owner approves it.
function handleReviewSubmission(req, res, row, basePath) {
  if (!row.published) return res.status(404).render('not-found');
  if (billing.isSuspended(row)) return res.status(503).render('suspended', { name: row.name });
  const b = req.body || {};
  const back = (q) => res.redirect(`${basePath}/review?${q}`);
  if (b.website) return back('thanks=1'); // honeypot
  const name = str(b.name, 80);
  const rating = parseInt(b.rating, 10);
  const quote = str(b.quote, 800);
  if (!(rating >= 1 && rating <= 5) || quote.length < 10) return back('error=1');
  const info = db.prepare('INSERT INTO review_submissions (site_id, name, rating, quote) VALUES (?, ?, ?, ?)')
    .run(row.id, name, rating, quote);
  try {
    const contact = hydrateSite(row).sections.contact;
    const to = (contact.notifyEmail && isValidEmail(contact.notifyEmail)) ? contact.notifyEmail : contact.email;
    if (to && mailer.isConfigured()) {
      mailer.sendReviewAlert({
        to, siteName: row.name, review: { name, rating, quote },
        reviewsUrl: `${req.protocol}://${req.get('host')}/sites/${row.id}/reviews`
      }).catch(err => console.error('Review alert failed:', err.message));
    }
  } catch (err) { console.error('Review alert failed:', err.message); }
  void info;
  back('thanks=1');
}

// One place every new lead goes through (contact form, chat, estimate): store it, alert the owner,
// send the optional receipt, and queue the optional follow-up emails.
function recordLead(req, row, lead, imageUrl, source) {
  const info = db.prepare(
    'INSERT INTO contact_submissions (site_id, name, email, phone, message, image_url, service, answers, source) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
  ).run(row.id, lead.name, lead.email, lead.phone, lead.message, imageUrl || '', lead.service || '', (lead.answers || []).length ? JSON.stringify(lead.answers) : '', source || 'form');
  notifyOwner(req, row, lead, imageUrl || '');
  autoReplyToVisitor(row, lead.email);
  try { leadsLib.enqueue(db, info.lastInsertRowid, row.id, hydrateSite(row).sections.contact.followUp); } catch (e) { console.error('Follow-up queue failed:', e.message); }
  return info.lastInsertRowid;
}

// Shared contact-form submission handler for both the slug-based route and
// the custom-domain route — see the two POST routes near the bottom.
function handleContactSubmission(req, res, row, basePath) {
  upload.single('photo')(req, res, async (err) => {
    if (!row.published) return res.status(404).render('not-found');
    if (billing.isSuspended(row)) return res.status(503).render('suspended', { name: row.name });
    // an uploaded photo that never gets stored as a lead shouldn't pile up on disk
    const redirectTo = (flag, keepFile) => {
      if (!keepFile && req.file) fs.rm(req.file.path, { force: true }, () => {});
      // a real submission lands on the thank-you page (where conversion
      // tracking fires); errors and bot traps go back to the form
      if (flag === 'thank_you') return res.redirect(`${basePath}/thank-you`);
      res.redirect(`${basePath}/contact?${flag}=1`);
    };
    if (err) return redirectTo('contact_error');
    const b = req.body || {};
    // honeypot: a real visitor never fills this hidden field in; a bot that
    // does gets a normal-looking success without anything being stored
    if (b.website) return redirectTo('contact_sent');
    const siteData = hydrateSite(row);
    const customForm = forms.normalize(siteData.sections.contact.form);
    let name, email, phone, message, service, answers = [];
    if (customForm.mode === 'custom') {
      const result = forms.validate(customForm, b, { services: siteData.sections.services.items.map(it => it.title), hasFile: !!req.file, isValidEmail });
      if (!result.ok) return redirectTo('contact_error');
      ({ name, email, phone, message, service } = result.values);
      answers = result.answers;
    } else {
      name = str(b.name, 100);
      email = isValidEmail(b.email || '') ? str(b.email, 254) : '';
      phone = str(b.phone, 40);
      message = str(b.message, 2000);
      // only accept a service the site actually lists
      const requested = str(b.service, 60);
      service = requested && siteData.sections.services.items.some(it => it.title === requested) ? requested : '';
    }
    if (!name && !email && !phone) return redirectTo('contact_error');
    if (req.file) await optimizeUpload(req.file, 1600);
    const imageUrl = req.file ? `/uploads/${req.file.filename}` : '';
    recordLead(req, row, { name, email, phone, message, service, answers }, imageUrl, 'form');
    redirectTo('thank_you', true);
  });
}

// Optional receipt email to the visitor ("we got your request"). Background,
// best-effort, and only when the owner switched it on and the visitor gave an email.
function autoReplyToVisitor(row, visitorEmail) {
  if (!visitorEmail || !mailer.isConfigured()) return;
  try {
    const contact = hydrateSite(row).sections.contact;
    if (!contact.autoReply) return;
    const text = contact.autoReplyText ||
      `Thanks for contacting ${row.name}. We received your request and will be in touch.` +
      (contact.phone ? ` If it is urgent, please call ${contact.phone}.` : '');
    const replyTo = (contact.notifyEmail && isValidEmail(contact.notifyEmail)) ? contact.notifyEmail : contact.email;
    mailer.sendAutoReply({ to: visitorEmail, siteName: row.name, text, replyTo })
      .catch(err => console.error('Auto-reply failed:', err.message));
  } catch (err) {
    console.error('Auto-reply failed:', err.message);
  }
}

function wantsJson(req) {
  return req.xhr || (req.headers.accept || '').includes('application/json') || req.headers['x-requested-with'] === 'fetch';
}

// "a, b\nc" -> ['a', 'b', 'c'] (trimmed, de-duplicated, length- and count-capped)
function splitList(value, maxLen, maxCount) {
  const out = [];
  for (const part of String(value || '').split(/[\n,;]+/)) {
    const t = str(part, maxLen);
    if (t && !out.some(o => o.toLowerCase() === t.toLowerCase())) out.push(t);
  }
  return out.slice(0, maxCount);
}

function parseSectionsFromBody(b) {
  const cap = (v, n) => str(v, n);
  return {
    hero: {
      headline: cap(b.hero_headline, 100),
      subheadline: cap(b.hero_subheadline, 160),
      imageUrl: isSafeUrl(b.hero_imageUrl) ? cap(b.hero_imageUrl, 500) : '',
      slides: ([]).concat(b.hero_slide || []).filter(u => u && isSafeUrl(u)).map(u => cap(u, 500)).slice(0, 5),
      ctaText: cap(b.hero_ctaText, 40),
      ctaLink: isSafeUrl(b.hero_ctaLink) ? cap(b.hero_ctaLink, 300) : '#contact',
      trustText: cap(b.hero_trustText, 160),
      quickLinks: b.hero_quickLinks === '1',
      float: accents.HERO_FLOATS.includes(b.hero_float) ? b.hero_float : '',
      edge: ['wave', 'scallop'].includes(b.hero_edge) ? b.hero_edge : '',
      focalX: Math.max(0, Math.min(100, Number.isFinite(parseFloat(b.hero_focalX)) ? Math.round(parseFloat(b.hero_focalX)) : 50)),
      focalY: Math.max(0, Math.min(100, Number.isFinite(parseFloat(b.hero_focalY)) ? Math.round(parseFloat(b.hero_focalY)) : 50)),
      overlay: ['15', '30', '45', '60', '75'].includes(String(b.hero_overlay)) ? String(b.hero_overlay) : '',
      align: ['left', 'center', 'right'].includes(b.hero_align) ? b.hero_align : '',
      videoUrl: (() => { const u = str(b.hero_videoUrl, 500).trim(); const v = isSafeUrl(u) && videoInfo(u); return v && v.kind === 'file' ? u : ''; })(),
      cards: ([]).concat(b.hero_card_title || []).map((t, i) => ({ title: cap(t, 40), text: cap(([]).concat(b.hero_card_text || [])[i], 140) })).filter(c => c.title).slice(0, 4)
    },
    about: {
      heading: cap(b.about_heading, 60),
      eyebrow: cap(b.about_eyebrow, 40),
      body: cap(b.about_body, 2000),
      imageUrl: isSafeUrl(b.about_imageUrl) ? cap(b.about_imageUrl, 500) : '',
      imageAlt: cap(b.about_imageAlt, 140)
    },
    services: {
      heading: cap(b.services_heading, 60),
      eyebrow: cap(b.services_eyebrow, 40),
      items: ([]).concat(b.service_title || []).map((title, i) => ({
        title: cap(title, 60),
        description: cap(([]).concat(b.service_description || [])[i], 300),
        detail: cap(([]).concat(b.service_detail || [])[i], 1500),
        pay: String(([]).concat(b.service_pay || [])[i] || '').replace(/[^0-9.]/g, '').slice(0, 10),
        imageUrl: isSafeUrl(([]).concat(b.service_image || [])[i]) ? cap(([]).concat(b.service_image || [])[i], 500) : '',
        icon: icons.ICONS[([]).concat(b.service_icon || [])[i]] ? ([]).concat(b.service_icon || [])[i] : '',
        seoTitle: cap(([]).concat(b.service_seoTitle || [])[i], 70),
        seoDescription: cap(([]).concat(b.service_seoDescription || [])[i], 160)
      })).filter(item => item.title || item.description).slice(0, 12)
    },
    testimonials: {
      heading: cap(b.testimonials_heading, 60),
      eyebrow: cap(b.testimonials_eyebrow, 40),
      display: b.testimonials_display === 'carousel' ? 'carousel' : 'grid',
      googlePlaceId: googleReviews.cleanPlaceId(b.testimonials_googlePlaceId),
      googleMode: ['badge', 'reviews'].includes(b.testimonials_googleMode) ? b.testimonials_googleMode : '',
      items: ([]).concat(b.testimonial_quote || []).map((quote, i) => {
        const rating = parseInt(([]).concat(b.testimonial_rating || [])[i], 10);
        return {
          quote: cap(quote, 500),
          author: cap(([]).concat(b.testimonial_author || [])[i], 80),
          rating: Number.isInteger(rating) && rating >= 1 && rating <= 5 ? rating : 0,
          date: cap(([]).concat(b.testimonial_date || [])[i], 40)
        };
      }).filter(item => item.quote).slice(0, 30)
    },
    whyChoose: {
      heading: cap(b.whyChoose_heading, 60),
      eyebrow: cap(b.whyChoose_eyebrow, 40),
      items: ([]).concat(b.whyChoose_title || []).map((title, i) => ({
        icon: WHY_CHOOSE_ICONS.includes(([]).concat(b.whyChoose_icon || [])[i]) ? ([]).concat(b.whyChoose_icon || [])[i] : 'check',
        title: cap(title, 50),
        text: cap(([]).concat(b.whyChoose_text || [])[i], 160)
      })).filter(item => item.title || item.text).slice(0, 8)
    },
    gallery: {
      heading: cap(b.gallery_heading, 60),
      eyebrow: cap(b.gallery_eyebrow, 40),
      ...(() => {
        const alts = ([]).concat(b.gallery_alt || []);
        const rows = ([]).concat(b.gallery_image || []).map((u, i) => ({ u: str(u, 500), a: str(alts[i], 140) })).filter(r => r.u && isSafeUrl(r.u)).slice(0, 20);
        return { images: rows.map(r => r.u), alts: rows.map(r => r.a) };
      })(),
      beforeAfter: ([]).concat(b.ba_before || []).map((before, i) => ({
        before: isSafeUrl(before) ? str(before, 500) : '',
        after: isSafeUrl(([]).concat(b.ba_after || [])[i]) ? str(([]).concat(b.ba_after || [])[i], 500) : '',
        caption: cap(([]).concat(b.ba_caption || [])[i], 120)
      })).filter(p => p.before && p.after).slice(0, 6)
    },
    blocks: { items: parseBlocksFromBody(b) },
    trust: {
      badges: splitList(b.trust_badges, 40, 8),
      stats: ([]).concat(b.trust_stat_value || []).map((value, i) => ({
        value: cap(value, 14),
        label: cap(([]).concat(b.trust_stat_label || [])[i], 40)
      })).filter(st => st.value && st.label).slice(0, 4),
      serviceAreas: splitList(b.trust_serviceAreas, 50, 30),
      legalNote: cap(b.trust_legalNote, 300),
      areaText: (() => {
        const names = ([]).concat(b.area_name || []);
        const texts = ([]).concat(b.area_text || []);
        const map = {};
        names.forEach((n, i) => { const t = str(texts[i], 1500); if (n && t) map[str(n, 50)] = t; });
        return map;
      })(),
      logosHeading: cap(b.trust_logosHeading, 60),
      logos: ([]).concat(b.trust_logo_url || []).map((u, i) => ({ imageUrl: isSafeUrl(u) ? cap(u, 500) : '', label: cap(([]).concat(b.trust_logo_label || [])[i], 60) })).filter(l => l.imageUrl).slice(0, 8),
      googleReviewsUrl: isSafeUrl(b.trust_googleReviewsUrl) && /^https?:\/\//i.test(b.trust_googleReviewsUrl) ? cap(b.trust_googleReviewsUrl, 500) : ''
    },
    blog: {
      heading: cap(b.blog_heading, 60),
      eyebrow: cap(b.blog_eyebrow, 40),
      items: ([]).concat(b.blog_title || []).map((title, i) => ({
        title: cap(title, 120),
        date: cap(([]).concat(b.blog_date || [])[i], 40),
        body: cap(([]).concat(b.blog_body || [])[i], 8000)
      })).filter(it => it.title && it.body).slice(0, 30)
    },
    extraPages: {
      heading: cap(b.extraPages_heading, 60) || 'Extra pages',
      items: ([]).concat(b.extra_title || []).map((title, i) => ({
        title: cap(title, 60),
        body: cap(([]).concat(b.extra_body || [])[i], 8000)
      })).filter(it => it.title && it.body).slice(0, 10)
    },
    meta: {
      businessType: cap(b.meta_businessType, 100),
      city: cap(b.meta_city, 80),
      gaId: cleanGaId(b.meta_gaId),
      metaPixelId: cleanPixelId(b.meta_metaPixelId),
      reportEmail: isValidEmail(b.meta_reportEmail || '') ? str(b.meta_reportEmail, 254) : '',
      trackingMode: b.meta_trackingMode === 'always' ? 'always' : 'ask'
    },
    faq: {
      heading: cap(b.faq_heading, 60),
      eyebrow: cap(b.faq_eyebrow, 40),
      items: ([]).concat(b.faq_question || []).map((q, i) => ({
        question: cap(q, 150),
        answer: cap(([]).concat(b.faq_answer || [])[i], 500)
      })).filter(item => item.question).slice(0, 15)
    },
    hours: {
      heading: cap(b.hours_heading, 60),
      eyebrow: cap(b.hours_eyebrow, 40),
      items: ([]).concat(b.hours_day || []).map((day, i) => ({
        day: cap(day, 20),
        time: cap(([]).concat(b.hours_time || [])[i], 60)
      })).filter(item => item.day).slice(0, 7)
    },
    contact: {
      heading: cap(b.contact_heading, 60),
      eyebrow: cap(b.contact_eyebrow, 40),
      email: isValidEmail(b.contact_email || '') ? str(b.contact_email, 254) : '',
      phone: cap(b.contact_phone, 40),
      address: cap(b.contact_address, 200),
      locations: ([]).concat(b.loc_name || []).map((name, i) => ({
        name: cap(name, 80),
        address: cap(([]).concat(b.loc_address || [])[i], 200),
        phone: cap(([]).concat(b.loc_phone || [])[i], 40)
      })).filter(l => l.name || l.address || l.phone).slice(0, 6),
      social: {
        facebook: isSafeUrl(b.contact_social_facebook) ? cap(b.contact_social_facebook, 300) : '',
        instagram: isSafeUrl(b.contact_social_instagram) ? cap(b.contact_social_instagram, 300) : '',
        twitter: isSafeUrl(b.contact_social_twitter) ? cap(b.contact_social_twitter, 300) : ''
      },
      notifyEmail: isValidEmail(b.contact_notifyEmail || '') ? str(b.contact_notifyEmail, 254) : '',
      autoReply: b.contact_autoReply === '1' || b.contact_autoReply === 'on',
      autoReplyText: cap(b.contact_autoReplyText, 600),
      homeMap: b.contact_homeMap === '1',
      footerHours: b.contact_footerHours === '1',
      floatButton: ['text', 'whatsapp', 'call', 'book', 'quote'].includes(b.contact_floatButton) ? b.contact_floatButton : '',
      form: forms.fromBody(b),
      followUp: leadsLib.fromBody(b),
      remindersOff: b.rem_off === '1' || b.rem_off === 'on',
      acceptSubmissions: b.contact_acceptSubmissions === '1' || b.contact_acceptSubmissions === 'on'
    },
    seo: {
      title: cap(b.seo_title, 70),
      description: cap(b.seo_description, 160),
      shareImage: isSafeUrl(b.seo_shareImage) ? cap(b.seo_shareImage, 500) : '',
      pages: (() => {
        const o = {};
        for (const k of [...PAGE_KEYS, 'book']) {
          const e = { title: cap(b['seopage_' + k + '_title'], 70), description: cap(b['seopage_' + k + '_description'], 160), shareImage: isSafeUrl(b['seopage_' + k + '_shareImage']) ? cap(b['seopage_' + k + '_shareImage'], 500) : '', noindex: b['seopage_' + k + '_noindex'] === '1' || b['seopage_' + k + '_noindex'] === 'on' };
          if (e.title || e.description || e.shareImage || e.noindex) o[k] = e;
        }
        return o;
      })(),
      redirects: redirects.fromBody(b),
      notFound: { heading: cap(b.nf_heading, 80), text: cap(b.nf_text, 300) }
    },
    legal: (() => {
      const on = b.legal_enabled === '1' || b.legal_enabled === 'on';
      const l = legal.clean({ enabled: on, ownerName: b.legal_ownerName, email: isValidEmail(b.legal_email || '') ? b.legal_email : '', address: b.legal_address, state: b.legal_state, updated: b.legal_updated, banner: b.legal_banner, privacyExtra: b.legal_privacyExtra, termsExtra: b.legal_termsExtra });
      if (l.enabled && !l.updated) l.updated = legal.monthYear();
      return l;
    })(),
    calculator: calc.fromBody(b),
    payments: payments.normalize({ enabled: b.pay_enabled === '1', currency: b.pay_currency, depositMode: b.pay_depositMode, depositAmount: b.pay_depositAmount, buyLabel: cap(b.pay_buyLabel, 30) }),
    members: membersLib.clean({
      enabled: b.members_enabled === '1' || b.members_enabled === 'on', title: b.members_title, navLabel: b.members_navLabel, intro: b.members_intro, signup: b.members_signup,
      pages: ([]).concat(b.members_page_title || []).map((title, i) => ({ title, body: ([]).concat(b.members_page_body || [])[i], linkLabel: ([]).concat(b.members_page_linkLabel || [])[i], linkUrl: ([]).concat(b.members_page_linkUrl || [])[i] }))
    }),
    chat: chat.clean({ enabled: b.chat_enabled === '1' || b.chat_enabled === 'on', greeting: b.chat_greeting, dailyCap: b.chat_dailyCap }),
    booking: parseBookingFromBody(b),
    announcement: {
      enabled: b.ann_enabled === '1' || b.ann_enabled === 'on',
      text: cap(b.ann_text, 160),
      linkText: cap(b.ann_linkText, 40),
      linkUrl: isSafeUrl(b.ann_linkUrl) ? cap(b.ann_linkUrl, 500) : '',
      dismissible: !(b.ann_dismissible === '0')
    }
  };
}

// Online booking settings. Hours come as one row per weekday; services, add-ons
// and the industry-specific questions are parallel arrays like the other lists.
function parseBookingFromBody(b) {
  const cap = (v, n) => str(v, n);
  const col = (k) => ([]).concat(b[k] || []);
  const num = (v, lo, hi, d) => { const n = parseInt(v, 10); return Number.isFinite(n) ? Math.max(lo, Math.min(hi, n)) : d; };
  const d = booking.defaultBooking();
  const hours = {};
  for (const k of booking.DAYS) {
    const open = String(b[`bk_open_${k}`] || '').trim(), close = String(b[`bk_close_${k}`] || '').trim();
    const ok = booking.TIME_RE.test(open) && booking.TIME_RE.test(close) && booking.toMin(open) < booking.toMin(close);
    hours[k] = ok ? { closed: b[`bk_closed_${k}`] === '1' || b[`bk_closed_${k}`] === 'on', open, close } : { ...d.hours[k], closed: true };
  }
  const money = (v) => cap(v, 20);
  return {
    enabled: b.bk_enabled === '1' || b.bk_enabled === 'on',
    kind: booking.PRESETS[b.bk_kind] ? b.bk_kind : 'generic',
    heading: cap(b.bk_heading, 60) || d.heading,
    intro: cap(b.bk_intro, 400),
    autoConfirm: b.bk_autoConfirm === '1' || b.bk_autoConfirm === 'on',
    timezone: booking.TIMEZONES.some(t => t[0] === b.bk_timezone) ? b.bk_timezone : d.timezone,
    stepMinutes: [10, 15, 20, 30, 45, 60].includes(parseInt(b.bk_step, 10)) ? parseInt(b.bk_step, 10) : 30,
    leadHours: num(b.bk_lead, 0, 720, 24),
    windowDays: num(b.bk_window, 1, 365, 45),
    capacity: num(b.bk_capacity, 1, 20, 1),
    hours,
    services: col('bk_service_name').map((name, i) => ({
      name: cap(name, 80), minutes: num(col('bk_service_minutes')[i], 5, 600, 60),
      price: money(col('bk_service_price')[i]), description: cap(col('bk_service_desc')[i], 200)
    })).filter(x => x.name).slice(0, 20),
    addons: col('bk_addon_name').map((name, i) => ({
      name: cap(name, 80), price: money(col('bk_addon_price')[i]), minutes: num(col('bk_addon_minutes')[i], 0, 240, 0)
    })).filter(x => x.name).slice(0, 15),
    fields: col('bk_field_label').map((label, i) => {
      const type = ['text', 'select', 'textarea'].includes(col('bk_field_type')[i]) ? col('bk_field_type')[i] : 'text';
      const options = type === 'select' ? String(col('bk_field_options')[i] || '').split(',').map(o => cap(o, 60)).filter(Boolean).slice(0, 12) : [];
      return { label: cap(label, 80), type: type === 'select' && !options.length ? 'text' : type, options, required: col('bk_field_required')[i] === '1' };
    }).filter(x => x.label).slice(0, 12),
    askAddress: b.bk_askAddress === '1' || b.bk_askAddress === 'on',
    policy: cap(b.bk_policy, 800),
    confirmNote: cap(b.bk_confirmNote, 400)
  };
}

function parseThemeFromBody(b) {
  return {
    primaryColor: isValidHexColor(b.theme_primaryColor) ? b.theme_primaryColor.trim() : '#2563eb',
    accentColor: isValidHexColor(b.theme_accentColor) ? b.theme_accentColor.trim() : '#1e293b',
    font: ['Inter, system-ui, sans-serif', "Georgia, 'Times New Roman', serif", "'Trebuchet MS', sans-serif"]
      .includes(b.theme_font) ? b.theme_font : 'Inter, system-ui, sans-serif',
    style: extraThemes.ALL_STYLES.includes(b.theme_style) ? b.theme_style : 'modern',
    headingFont: fonts.cleanFontName(b.theme_headingFontCustom) || fonts.cleanFontName(b.theme_headingFont),
    bodyFont: fonts.cleanFontName(b.theme_bodyFontCustom) || fonts.cleanFontName(b.theme_bodyFont),
    headingCase: ['none', 'uppercase'].includes(b.theme_headingCase) ? b.theme_headingCase : '',
    homeLayout: extraThemes.HOME_LAYOUTS.includes(b.theme_homeLayout) ? b.theme_homeLayout : ((b.theme_homeFull === '1' || b.theme_homeFull === 'on') ? 'full' : ''),
    homeFull: false,
    pageStyles: (() => { const o = {}; for (const k of extraThemes.PAGE_KEYS_FOR_STYLE) { const v = b['pagestyle_' + k]; if (extraThemes.ALL_STYLES.includes(v)) o[k] = v; } return o; })(),
    buttonShape: ['square', 'rounded', 'pill'].includes(b.theme_buttonShape) ? b.theme_buttonShape : '',
    corners: ['sharp', 'soft', 'round'].includes(b.theme_corners) ? b.theme_corners : '',
    spacing: ['compact', 'airy'].includes(b.theme_spacing) ? b.theme_spacing : '',
    emoji: accents.cleanEmoji(b.theme_emoji),
    doodles: b.theme_doodles === '1',
    emojiHeads: b.theme_emojiHeads === '1',
    bgColor: isValidHexColor(b.theme_bgColor) ? b.theme_bgColor.trim() : '',
    headingScale: ['large', 'xl'].includes(b.theme_headingScale) ? b.theme_headingScale : '',
    bands: b.theme_bands === '1',
    header: ['static', 'shrink', 'transparent'].includes(b.theme_header) ? b.theme_header : '',
    headerLayout: b.theme_headerLayout === 'centered' ? 'centered' : '',
    motionStyle: app.locals.motionLib.isValid(b.theme_motionStyle) ? b.theme_motionStyle : app.locals.motionLib.DEFAULT,
    hoverLift: b.theme_hoverLift === '1' || b.theme_hoverLift === 'on',
    logoUrl: isSafeUrl(b.theme_logoUrl) ? str(b.theme_logoUrl, 500) : ''
  };
}

// Content blocks (photo + text, numbered steps). Parallel arrays from the
// editor, one entry per block; steps are one per line as "Title | text".
const BLOCK_TYPES = ['photoText', 'steps', 'features', 'cta', 'chips', 'strip', 'split', 'pricing', 'team', 'stats', 'video', 'tabs', 'accordion'];
const BLOCK_PAGES = ['home', 'about', 'services', 'testimonials', 'whyChoose', 'gallery', 'faq', 'blog', 'hours', 'contact'];
function parseBlocksFromBody(b) {
  const cap = (v, n) => str(v, n);
  const col = (k) => ([]).concat(b[k] || []);
  const types = col('block_type');
  const pick = (v, allowed, dflt) => (allowed.includes(v) ? v : dflt);
  const out = [];
  types.forEach((type, i) => {
    if (!BLOCK_TYPES.includes(type)) return;
    const blk = {
      type,
      heading: cap(col('block_heading')[i], 120),
      body: type === 'video'
        ? (() => { const u = str(col('block_body')[i], 500).split('\n')[0].trim(); return isSafeUrl(u) && videoInfo(u) ? u : ''; })()
        : type === 'team'
        ? str(col('block_body')[i], 6000).split('\n').map(l => { const parts = l.split('|').map(x => x.trim()); if (!parts[0]) return ''; const photo = parts[3] && isSafeUrl(parts[3]) ? parts[3].slice(0, 500) : ''; return [parts[0].slice(0, 60), (parts[1] || '').slice(0, 60), (parts[2] || '').slice(0, 300), photo].join(' | '); }).filter(Boolean).slice(0, 12).join('\n')
        : type === 'strip'
        ? str(col('block_body')[i], 12000).split('\n').map(u => u.trim()).filter(u => u && isSafeUrl(u)).map(u => u.slice(0, 500)).slice(0, 20).join('\n')
        : cap(col('block_body')[i], type === 'photoText' || type === 'cta' || type === 'split' ? 2000 : 1600),
      imageUrl: isSafeUrl(col('block_image')[i]) ? cap(col('block_image')[i], 500) : '',
      buttonText: cap(col('block_buttonText')[i], 40),
      buttonUrl: isSafeUrl(col('block_buttonUrl')[i]) ? cap(col('block_buttonUrl')[i], 500) : '',
      side: pick(col('block_side')[i], ['auto', 'left', 'right'], 'auto'),
      bg: pick(col('block_bg')[i], ['none', 'tint', 'brand', 'dark'], 'none'),
      edge: pick(col('block_edge')[i], ['none', 'wave', 'scallop'], 'none'),
      place: pick(col('block_place')[i], ['bottom', 'top'], 'bottom'),
      page: pick(col('block_page')[i], BLOCK_PAGES, 'home')
    };
    if (blk.heading || blk.body || blk.imageUrl) out.push(blk);
  });
  return out.slice(0, 20);
}

function parseLayoutFromBody(b) {
  const orderRaw = str(b.layout_order, 500);
  const order = orderRaw ? orderRaw.split(',').map(s => s.trim()).filter(Boolean) : [];
  const hidden = ([]).concat(b.hidden_sections || []).filter(Boolean);
  return safeParseLayout(JSON.stringify({ order, hidden }));
}

// ---- online booking ----
// Customers pick a service, add-ons and a time on /book; the request is stored
// as 'pending' (or 'confirmed' when the owner turned on auto-confirm) and the
// owner confirms or declines it on the Bookings page. Times are stored as the
// business's own wall-clock time, so the business time zone decides what "now" is.
const bookingLimiter = rateLimit({
  windowMs: 10 * 60 * 1000, limit: 10, standardHeaders: true, legacyHeaders: false,
  skip: () => isTestEnv, message: 'Too many booking attempts from this device. Please try again later.'
});
// ---- customer payments (deposits, payment requests, service purchases) ----
// Money goes to the site owner's own Stripe account (their key, stored encrypted). Payments are confirmed by
// asking Stripe about the Checkout Session, so no webhook is needed.
const siteStripeKey = (row) => payments.decryptKey(row.stripe_key_enc);
const payReady = (row, site) => !!(site.sections.payments && site.sections.payments.enabled && siteStripeKey(row));
const payBase = (req, row) => (row.custom_domain ? `https://${row.custom_domain}` : `${req.protocol}://${req.get('host')}`);
function newPayment(row, { kind, refId = null, description, amountCents, name = '', email = '', currency = 'usd' }) {
  const token = nanoid(24);
  db.prepare('INSERT INTO payments (site_id, token, kind, ref_id, description, amount_cents, currency, customer_name, customer_email) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)')
    .run(row.id, token, kind, refId, String(description || '').slice(0, 200), amountCents, payments.CURRENCIES[currency] ? currency : 'usd', String(name).slice(0, 100), String(email).slice(0, 254));
  return db.prepare('SELECT * FROM payments WHERE token = ?').get(token);
}
// returns the Stripe-hosted page to send the customer to
async function startCheckout(req, row, p) {
  const key = siteStripeKey(row);
  if (!key) throw new Error('This site is not set up to take payments.');
  if (p.stripe_session_id) { // reuse a still-open session; notice if it was already paid
    try {
      const s = await payments.getSession(key, p.stripe_session_id);
      if (payments.isPaid(s)) { markPaid(row, p, s); return `${payBase(req, row)}/pay/${p.token}?done=1`; }
      if (s.status === 'open' && s.url) return s.url;
    } catch { /* make a new one */ }
  }
  const base = payBase(req, row);
  const s = await payments.createCheckout(key, {
    amountCents: p.amount_cents, currency: p.currency, description: p.description, customerEmail: p.customer_email,
    successUrl: `${base}/pay/${p.token}?done=1`, cancelUrl: `${base}/pay/${p.token}`, paymentId: p.id, siteName: row.name
  });
  db.prepare('UPDATE payments SET stripe_session_id = ?, stripe_session_url = ? WHERE id = ?').run(s.id, s.url || '', p.id);
  return s.url;
}
// the one place a payment becomes "paid" (safe to call twice: only the first call does the follow-up work)
function pseudoReq(row) { // for emails sent from background jobs: build links from PUBLIC_URL (or the site's own domain)
  let u = null; try { u = process.env.PUBLIC_URL ? new URL(process.env.PUBLIC_URL) : null; } catch { /* ignore */ }
  const host = row.custom_domain || (u && u.host) || `localhost:${PORT}`;
  return { protocol: row.custom_domain ? 'https' : (u ? u.protocol.replace(':', '') : 'http'), get: (h) => (h === 'host' ? host : '') };
}
function markPaid(row, p, session, via = 'stripe', req) {
  const cd = (session && session.customer_details) || {};
  const r = db.prepare("UPDATE payments SET status = 'paid', paid_at = datetime('now'), paid_via = ?, customer_name = CASE WHEN customer_name = '' THEN ? ELSE customer_name END, customer_email = CASE WHEN customer_email = '' THEN ? ELSE customer_email END WHERE id = ? AND status != 'paid'")
    .run(via, String(cd.name || '').slice(0, 100), String(cd.email || '').slice(0, 254), p.id);
  if (!r.changes) return false;
  const paid = db.prepare('SELECT * FROM payments WHERE id = ?').get(p.id);
  try {
    if (paid.kind === 'deposit' && paid.ref_id) {
      const bk = db.prepare("SELECT * FROM bookings WHERE id = ? AND site_id = ? AND status = 'awaiting_payment'").get(paid.ref_id, row.id);
      const site = hydrateSite(row);
      if (bk) {
        const status = site.sections.booking.autoConfirm ? 'confirmed' : 'pending';
        db.prepare('UPDATE bookings SET status = ? WHERE id = ?').run(status, bk.id);
        emailBooking(req || pseudoReq(row), row, { ...bk, status }, 'created');
      }
    }
    const site = hydrateSite(row); const to = ownerEmailFor(site);
    if (to && mailer.isConfigured()) {
      mailer.sendReport({ to, replyTo: paid.customer_email || undefined, subject: `Payment received: ${payments.money(paid.amount_cents, paid.currency)} (${row.name})`,
        text: `${paid.customer_name || 'A customer'} paid ${payments.money(paid.amount_cents, paid.currency)}.\n\nFor: ${paid.description}\n${paid.customer_email ? 'Email: ' + paid.customer_email + '\n' : ''}\nSee all payments in SiteGen under Payments for ${row.name}.\n` })
        .catch(e => console.error('Payment alert failed:', e.message));
    }
  } catch (e) { console.error('After-payment steps failed:', e.message); }
  return true;
}
// ask Stripe where a pending payment stands
async function refreshPayment(row, p) {
  if (p.status !== 'pending' || !p.stripe_session_id) return p;
  const key = siteStripeKey(row);
  if (!key) return p;
  try {
    const s = await payments.getSession(key, p.stripe_session_id);
    if (payments.isPaid(s)) markPaid(row, p, s);
    else if (payments.isExpired(s)) db.prepare("UPDATE payments SET status = 'expired' WHERE id = ? AND status = 'pending'").run(p.id);
  } catch (e) { console.error('Payment check failed:', e.message); }
  return db.prepare('SELECT * FROM payments WHERE id = ?').get(p.id);
}
// background: confirm payments the customer paid but never came back from, and release unpaid deposit holds
async function runPaymentSweep() {
  let checked = 0, released = 0;
  const pend = db.prepare("SELECT * FROM payments WHERE status = 'pending' AND stripe_session_id != '' AND created_at > datetime('now', '-3 days')").all();
  for (const p of pend) {
    const row = db.prepare('SELECT * FROM sites WHERE id = ?').get(p.site_id);
    if (row) { await refreshPayment(row, p); checked++; }
  }
  const stale = db.prepare("SELECT * FROM bookings WHERE status = 'awaiting_payment' AND created_at <= datetime('now', '-30 minutes')").all();
  for (const bk of stale) {
    const row = db.prepare('SELECT * FROM sites WHERE id = ?').get(bk.site_id);
    const pay = db.prepare("SELECT * FROM payments WHERE kind = 'deposit' AND ref_id = ? ORDER BY id DESC").get(bk.id);
    if (row && pay) await refreshPayment(row, pay);
    const now = db.prepare('SELECT status FROM bookings WHERE id = ?').get(bk.id);
    if (now && now.status === 'awaiting_payment') {
      db.prepare("UPDATE bookings SET status = 'cancelled' WHERE id = ?").run(bk.id);
      db.prepare("UPDATE payments SET status = 'expired' WHERE kind = 'deposit' AND ref_id = ? AND status = 'pending'").run(bk.id);
      released++;
    }
  }
  return { checked, released };
}

// customer-facing payment page: one link per payment, works on the site's own domain too
const payLimiter = rateLimit({
  windowMs: 10 * 60 * 1000, limit: 30, standardHeaders: true, legacyHeaders: false, skip: () => isTestEnv,
  message: 'Too many attempts. Please try again in a few minutes.'
});
function loadPayment(req, res, next) {
  const t = String(req.params.token || '');
  const p = /^[A-Za-z0-9_-]{16,64}$/.test(t) ? db.prepare('SELECT * FROM payments WHERE token = ?').get(t) : null;
  const row = p && db.prepare('SELECT * FROM sites WHERE id = ?').get(p.site_id);
  if (!p || !row) return res.status(404).render('not-found');
  res.set({ 'Referrer-Policy': 'no-referrer', 'X-Robots-Tag': 'noindex, nofollow' });
  req.pay = p; req.payRow = row;
  next();
}
app.get('/pay/:token', loadPayment, async (req, res) => {
  let p = req.pay; const row = req.payRow;
  if (p.status === 'pending' && p.stripe_session_id) p = await refreshPayment(row, p);
  const site = hydrateSite(row);
  res.render('pay', { p, siteName: row.name, color: (site.theme && site.theme.primaryColor) || '#2563eb', amount: payments.money(p.amount_cents, p.currency), ready: payReady(row, site), error: req.query.error === '1', done: req.query.done === '1' });
});
app.post('/pay/:token', payLimiter, loadPayment, async (req, res) => {
  const p = req.pay, row = req.payRow, site = hydrateSite(row);
  if (p.status !== 'pending' || !payReady(row, site)) return res.redirect(`/pay/${p.token}`);
  try { res.redirect(await startCheckout(req, row, p)); }
  catch (e) { console.error('Checkout failed:', e.message); res.redirect(`/pay/${p.token}?error=1`); }
});

const BOOKING_LIVE = ['pending', 'confirmed'];
const BOOKING_ERRORS = {
  name: 'Please enter your name.', email: 'Please enter a valid email address so we can confirm with you.',
  service: 'Please choose a service.', slot: 'Please pick a date and time.', taken: 'Sorry, that time is no longer available. Please choose another.',
  required: 'Please fill in the highlighted questions.', address: 'Please enter the address where we should come.'
};

function bookableServices(b) {
  return b.services.length ? b.services : [{ name: 'Appointment', minutes: 60, price: '', description: '' }];
}
// what the customer asked for -> the service, add-ons and total length (null if it doesn't match the owner's setup)
function resolveBookingChoice(b, serviceName, addonNames) {
  const svc = bookableServices(b).find(s => s.name === serviceName);
  if (!svc) return null;
  const wanted = ([]).concat(addonNames || []).map(a => String(a));
  const addons = b.addons.filter(a => wanted.includes(a.name));
  const minutes = (+svc.minutes || 60) + addons.reduce((n, a) => n + (+a.minutes || 0), 0);
  return { service: svc, addons, minutes };
}
function liveBookingsOn(siteId, date) {
  return db.prepare(`SELECT start_at, duration FROM bookings WHERE site_id = ? AND start_at LIKE ? AND (status IN ('pending','confirmed') OR (status = 'awaiting_payment' AND created_at > datetime('now', '-30 minutes')))`).all(siteId, `${date}%`);
}
function bookingSlotsResponse(req, res, row) {
  const b = hydrateSite(row).sections.booking;
  if (!b.enabled) return res.status(404).json({ slots: [] });
  const date = String(req.query.date || '');
  const choice = resolveBookingChoice(b, String(req.query.service || ''), String(req.query.addons || '').split('|').filter(Boolean));
  if (!choice || !booking.DATE_RE.test(date)) return res.json({ slots: [] });
  const slots = booking.slotsFor(b, date, choice.minutes, liveBookingsOn(row.id, date));
  res.json({ date, minutes: choice.minutes, slots: slots.map(t => ({ time: t, label: booking.prettyTime(t) })) });
}
function bookingSummaryText(bk, b) {
  const details = JSON.parse(bk.details || '[]');
  const addons = JSON.parse(bk.addons || '[]');
  return [
    `${bk.name} — ${bk.service}${addons.length ? ' + ' + addons.join(', ') : ''}`,
    `When: ${booking.prettyDate(bk.start_at.slice(0, 10))} at ${booking.prettyTime(bk.start_at.slice(11, 16))} (about ${bk.duration} min)`,
    `Email: ${bk.email}`, bk.phone ? `Phone: ${bk.phone}` : null, bk.address ? `Address: ${bk.address}` : null,
    ...details.filter(d => d.value).map(d => `${d.label}: ${d.value}`),
    bk.notes ? `Notes: ${bk.notes}` : null
  ].filter(Boolean).join('\n');
}
function ownerEmailFor(site) {
  const c = site.sections.contact;
  return (c.notifyEmail && isValidEmail(c.notifyEmail)) ? c.notifyEmail : c.email;
}
function bookingStatusLink(req, row, bk) {
  const base = row.custom_domain ? `https://${row.custom_domain}/book` : `${req.protocol}://${req.get('host')}/site/${row.slug}/book`;
  return `${base}?t=${bk.token}`;
}
// background, best-effort emails for a booking event
function emailBooking(req, row, bk, event, extraMessage) {
  if (!mailer.isConfigured()) return;
  try {
    const site = hydrateSite(row);
    const b = site.sections.booking;
    const ownerTo = ownerEmailFor(site);
    const summary = bookingSummaryText(bk, b);
    const log = (err) => console.error('Booking email failed:', err.message);
    const base = `${req.protocol}://${req.get('host')}`;
    if (event === 'created' || event === 'cancelled-by-customer') {
      if (ownerTo) mailer.sendBookingAlert({
        to: ownerTo, siteName: row.name, replyTo: bk.email, needsAction: event === 'created' && bk.status === 'pending',
        summary: (event === 'cancelled-by-customer' ? 'A customer cancelled this booking:\n\n' : '') + summary,
        bookingsUrl: `${base}/sites/${row.id}/bookings`
      }).catch(log);
    }
    const link = bookingStatusLink(req, row, bk);
    const when = `${booking.prettyDate(bk.start_at.slice(0, 10))} at ${booking.prettyTime(bk.start_at.slice(11, 16))}`;
    const replyTo = ownerTo || undefined;
    const note = [extraMessage, event === 'confirmed' || (event === 'created' && bk.status === 'confirmed') ? b.confirmNote : ''].filter(Boolean).join('\n\n');
    let subject, text;
    if (event === 'created' && bk.status === 'confirmed') { subject = 'Your appointment is confirmed'; text = `Hi ${bk.name},\n\nYour appointment is confirmed for ${when}.\n\n${summary}\n\n${note ? note + '\n\n' : ''}View or cancel your booking: ${link}`; }
    else if (event === 'created') { subject = 'We received your booking request'; text = `Hi ${bk.name},\n\nThanks! We received your request for ${when}. It is not confirmed yet; we will email you once we have reviewed it.\n\n${summary}\n\nCheck its status or cancel: ${link}`; }
    else if (event === 'confirmed') { subject = 'Your appointment is confirmed'; text = `Hi ${bk.name},\n\nGood news: your appointment is confirmed for ${when}.\n\n${summary}\n\n${note ? note + '\n\n' : ''}View or cancel your booking: ${link}`; }
    else if (event === 'declined') { subject = 'About your booking request'; text = `Hi ${bk.name},\n\nUnfortunately we are not able to take your request for ${when}.${extraMessage ? '\n\n' + extraMessage : ''}\n\nYou are welcome to choose another time: ${link.split('?')[0]}`; }
    else if (event === 'cancelled') { subject = 'Your appointment was cancelled'; text = `Hi ${bk.name},\n\nYour appointment for ${when} has been cancelled.${extraMessage ? '\n\n' + extraMessage : ''}\n\nYou can book another time here: ${link.split('?')[0]}`; }
    if (subject && bk.email) mailer.sendBookingCustomer({ to: bk.email, siteName: row.name, subject, text, replyTo }).catch(log);
  } catch (err) { console.error('Booking email failed:', err.message); }
}

function createBooking(req, res, row, basePath) {
  const site = hydrateSite(row);
  const b = site.sections.booking;
  if (!b.enabled) return res.status(404).render('not-found');
  const body = req.body || {};
  if (body.website) return res.redirect(`${basePath}/book?done=1`); // honeypot
  const values = { name: str(body.name, 100), email: str(body.email, 254), phone: str(body.phone, 40), address: str(body.address, 200), notes: str(body.notes, 1000), service: str(body.service, 80), date: str(body.date, 10), time: str(body.time, 5), addon: ([]).concat(body.addon || []).map(a => str(a, 80)), fields: {} };
  b.fields.forEach((f, i) => { values.fields[i] = str(body['f_' + i], 500); });
  const fail = (code, field) => renderSitePage(req, res.status(422), null, {
    site, page: 'book', basePath, preview: false, cacheKey: null,
    bookingView: { mode: 'form', error: BOOKING_ERRORS[code], errorCode: code, field: field || '', values }
  });
  if (values.name.length < 2) return fail('name', 'name');
  if (!isValidEmail(values.email)) return fail('email', 'email');
  const choice = resolveBookingChoice(b, values.service, values.addon);
  if (!choice) return fail('service');
  if (b.askAddress && values.address.length < 5) return fail('address', 'address');
  if (!booking.DATE_RE.test(values.date) || !booking.TIME_RE.test(values.time)) return fail('slot');
  const details = [];
  for (let i = 0; i < b.fields.length; i++) {
    const f = b.fields[i];
    let v = values.fields[i] || '';
    if (f.type === 'select' && v && !f.options.includes(v)) v = '';
    if (f.required && !v) return fail('required', 'f_' + i);
    details.push({ label: f.label, value: v });
  }
  const token = nanoid(24);
  const startAt = `${values.date} ${values.time}`;
  // a deposit holds the time for 30 minutes; the booking is only confirmed or sent to the owner once it is paid
  const payCfg = site.sections.payments || {};
  const priceCents = payments.toCents(choice.service.price) + choice.addons.reduce((n, a) => n + payments.toCents(a.price), 0);
  const depCents = payReady(row, site) ? payments.depositCents(payCfg, priceCents) : 0;
  const status = depCents ? 'awaiting_payment' : (b.autoConfirm ? 'confirmed' : 'pending');
  const insert = db.transaction(() => {
    const ok = booking.slotsFor(b, values.date, choice.minutes, liveBookingsOn(row.id, values.date)).includes(values.time);
    if (!ok) return false;
    db.prepare(`INSERT INTO bookings (site_id, token, service, addons, start_at, duration, name, email, phone, address, details, notes, status)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`).run(row.id, token, choice.service.name, JSON.stringify(choice.addons.map(a => a.name)), startAt, choice.minutes,
      values.name, values.email, values.phone, b.askAddress ? values.address : '', JSON.stringify(details), values.notes, status);
    return true;
  });
  if (!insert()) return fail('taken');
  const bk = db.prepare('SELECT * FROM bookings WHERE token = ?').get(token);
  if (depCents) {
    const pay = newPayment(row, { kind: 'deposit', refId: bk.id, description: `Deposit: ${choice.service.name} on ${booking.prettyDate(values.date)}`, amountCents: depCents, name: values.name, email: values.email, currency: payCfg.currency });
    return startCheckout(req, row, pay).then(
      (url) => res.redirect(url),
      (err) => { console.error('Deposit checkout failed:', err.message); res.redirect(`${payBase(req, row)}/pay/${pay.token}?error=1`); }
    );
  }
  emailBooking(req, row, bk, 'created');
  res.redirect(`${basePath}/book?t=${token}&new=1`);
}

function cancelBookingByCustomer(req, res, row, basePath) {
  const token = str((req.body || {}).token, 60);
  const bk = token && db.prepare('SELECT * FROM bookings WHERE token = ? AND site_id = ?').get(token, row.id);
  if (bk && BOOKING_LIVE.includes(bk.status)) {
    db.prepare("UPDATE bookings SET status = 'cancelled' WHERE id = ?").run(bk.id);
    emailBooking(req, row, { ...bk, status: 'cancelled' }, 'cancelled-by-customer');
  }
  res.redirect(`${basePath}/book?t=${encodeURIComponent(token)}`);
}

// One entry point for /book, /book/slots and /book/cancel, used by the slug
// routes and by the custom-domain middleware.
function bookingRoute(req, res, next, row, basePath, sub) {
  if (!row || !row.published) return res.status(404).render('not-found');
  if (billing.isSuspended(row)) return res.status(503).render('suspended', { name: row.name });
  if (sub === 'slots' && req.method === 'GET') return bookingSlotsResponse(req, res, row);
  if (sub === 'cancel' && req.method === 'POST') return bookingLimiter(req, res, () => cancelBookingByCustomer(req, res, row, basePath));
  if (!sub && req.method === 'POST') return bookingLimiter(req, res, () => createBooking(req, res, row, basePath));
  if (sub || req.method !== 'GET') return res.status(404).render('not-found');
  const site = hydrateSite(row);
  let view = { mode: 'form', values: {} };
  const t = str(req.query.t, 60);
  if (t) {
    const bk = db.prepare('SELECT * FROM bookings WHERE token = ? AND site_id = ?').get(t, row.id);
    if (bk) {
      const dep = db.prepare("SELECT token, status, amount_cents, currency FROM payments WHERE kind = 'deposit' AND ref_id = ? AND site_id = ? ORDER BY id DESC").get(bk.id, row.id);
      view = { mode: 'status', booking: bk, isNew: req.query.new === '1', details: JSON.parse(bk.details || '[]'), addons: JSON.parse(bk.addons || '[]'),
        payToken: dep && dep.status === 'pending' ? dep.token : '', depositPaid: dep && dep.status === 'paid' ? payments.money(dep.amount_cents, dep.currency) : '' };
    }
  } else if (req.query.done === '1') view = { mode: 'done' };
  renderSitePage(req, res, next, { site, page: 'book', basePath, preview: false, cacheKey: null, bookingView: view });
}
app.all(['/site/:slug/book', '/site/:slug/book/:sub'], (req, res, next) => {
  const row = db.prepare('SELECT * FROM sites WHERE slug = ?').get(req.params.slug);
  bookingRoute(req, res, next, row, `/site/${req.params.slug}`, req.params.sub);
});
// the editor's preview can look up open times too (it is read-only: nothing can be submitted there)
app.get('/sites/:id/preview/book/slots', requireAuth, loadOwnedSite, (req, res) => bookingSlotsResponse(req, res, db.prepare('SELECT * FROM sites WHERE id = ?').get(req.site.id)));

// ---- members area: visitors sign up / log in and see members-only pages ----
const memberLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, limit: 30, standardHeaders: true, legacyHeaders: false, skip: () => isTestEnv,
  message: 'Too many attempts. Please wait a few minutes and try again.'
});
function currentMember(req, row) {
  const id = req.session && req.session.members && req.session.members[row.id];
  if (!id) return null;
  const m = db.prepare('SELECT * FROM site_members WHERE id = ? AND site_id = ?').get(id, row.id);
  return m && m.status === 'active' ? m : null;     // a disabled or removed member loses access at once
}
function memberLogin(req, row, m) {
  req.session.members = { ...(req.session.members || {}), [row.id]: m.id };
  db.prepare("UPDATE site_members SET last_login_at = datetime('now') WHERE id = ?").run(m.id);
}
const MEMBER_MSGS = { welcome: 'Welcome! Your account is ready.', pending: 'Thanks for signing up. Your account will be ready once the site owner approves it.', bye: 'You have been logged out.', reset: 'Your password was changed. Log in with the new one.', sent: 'If that email has an account, a link to choose a new password is on its way. If it does not arrive, ask the site owner for help.' };
function membersRoute(req, res, next, row, basePath, sub) {
  res.set({ 'X-Robots-Tag': 'noindex, nofollow', 'Cache-Control': 'no-store', 'Referrer-Policy': 'no-referrer' });
  if (!row || !row.published) return res.status(404).render('not-found');
  if (billing.isSuspended(row)) return res.status(503).render('suspended', { name: row.name });
  const site = hydrateSite(row);
  const cfg = membersLib.clean(site.sections.members);
  if (!cfg.enabled) return res.status(404).render('not-found');
  const home = `${basePath}/members`;
  const show = (view) => renderSitePage(req, res, next, { site, page: 'members', basePath, preview: false, cacheKey: null, memberView: { cfg, ...view } });
  const body = req.body || {};
  const run = (fn) => memberLimiter(req, res, fn);

  if (req.method === 'GET' && !sub) {
    const m = currentMember(req, row);
    const msg = MEMBER_MSGS[str(req.query.msg, 12)] ? str(req.query.msg, 12) : '';
    if (m) return show({ mode: 'area', member: { name: m.name, email: m.email }, notice: msg ? MEMBER_MSGS[msg] : '' });
    return show({ mode: 'login', error: '', email: '', tab: req.query.tab === 'signup' && cfg.signup !== 'invite' ? 'signup' : 'login', notice: msg ? MEMBER_MSGS[msg] : '' });
  }
  if (req.method === 'POST' && sub === 'logout') {
    if (req.session.members) { const o = { ...req.session.members }; delete o[row.id]; req.session.members = o; }
    return res.redirect(`${home}?msg=bye`);
  }
  if (req.method === 'POST' && sub === 'login') return run(() => {
    const email = membersLib.normEmail(body.email), pw = String(body.password || '');
    const m = email ? db.prepare('SELECT * FROM site_members WHERE site_id = ? AND email = ?').get(row.id, email) : null;
    const ok = bcrypt.compareSync(pw.slice(0, 200), m && m.password_hash ? m.password_hash : membersLib.dummyHash()) && m && m.password_hash;
    if (!ok) return show({ mode: 'login', error: 'Incorrect email or password.', email, tab: 'login' });
    if (m.status === 'pending') return show({ mode: 'login', error: 'Your account is waiting for the site owner to approve it.', email, tab: 'login' });
    if (m.status !== 'active') return show({ mode: 'login', error: 'This account is not active. Please contact the site owner.', email, tab: 'login' });
    memberLogin(req, row, m);
    res.redirect(home);
  });
  if (req.method === 'POST' && sub === 'signup') return run(() => {
    if (cfg.signup === 'invite') return res.status(404).render('not-found');
    if (str(body.website, 100)) return res.redirect(`${home}?msg=pending`);        // honeypot: looks fine, saves nothing
    const email = membersLib.normEmail(body.email), name = str(body.name, 80);
    const fail = (error) => show({ mode: 'login', error, email, name, tab: 'signup' });
    if (!name) return fail('Please enter your name.');
    if (!membersLib.okEmail(email)) return fail('Please enter a valid email address.');
    const pwErr = membersLib.passwordProblem(body.password); if (pwErr) return fail(pwErr);
    if (String(body.password) !== String(body.password2 || '')) return fail('The two passwords do not match.');
    if (db.prepare('SELECT 1 FROM site_members WHERE site_id = ? AND email = ?').get(row.id, email)) return fail('There is already an account with that email. Try logging in, or use "Forgot your password?".');
    const total = db.prepare('SELECT COUNT(*) n FROM site_members WHERE site_id = ?').get(row.id).n;
    if (total >= 5000) return fail('Sign-ups are closed right now. Please contact the site owner.');
    const status = cfg.signup === 'open' ? 'active' : 'pending';
    const info = db.prepare('INSERT INTO site_members (site_id, email, name, password_hash, status) VALUES (?, ?, ?, ?, ?)').run(row.id, email, name, bcrypt.hashSync(String(body.password), 10), status);
    const to = hostingNotifyEmail(site);
    if (to) mailer.sendBookingCustomer({ to, siteName: row.name, subject: status === 'pending' ? 'New member waiting for approval' : 'New member signed up', text: `${name} (${email}) signed up for the members area.${status === 'pending' ? `\n\nApprove or remove them here: ${req.protocol}://${req.get('host')}/sites/${row.id}/members` : ''}` }).catch(() => {});
    if (status === 'active') { memberLogin(req, row, { id: info.lastInsertRowid }); return res.redirect(`${home}?msg=welcome`); }
    return res.redirect(`${home}?msg=pending`);
  });
  if (req.method === 'POST' && sub === 'forgot') return run(() => {
    const email = membersLib.normEmail(body.email);
    const m = email ? db.prepare("SELECT * FROM site_members WHERE site_id = ? AND email = ? AND password_hash != ''").get(row.id, email) : null;
    if (m && m.status !== 'disabled' && mailer.isConfigured()) {
      const t = membersLib.newToken();
      db.prepare("UPDATE site_members SET reset_hash = ?, reset_expires = datetime('now', '+1 hour') WHERE id = ?").run(membersLib.hashToken(t), m.id);
      mailer.sendBookingCustomer({ to: m.email, siteName: row.name, subject: 'Choose a new password', text: `Use this link within one hour to choose a new password:\n${req.protocol}://${req.get('host')}${home}/reset?t=${t}\n\nIf you did not ask for this, you can ignore this email.` }).catch(() => {});
    }
    res.redirect(`${home}?msg=sent`);                   // same answer whether or not the email has an account
  });
  if (sub === 'reset' && (req.method === 'GET' || req.method === 'POST')) {
    const t = str(req.query.t || body.t, 80);
    const m = /^[a-f0-9]{48}$/.test(t) ? db.prepare("SELECT * FROM site_members WHERE site_id = ? AND reset_hash = ? AND reset_expires > datetime('now') AND status != 'disabled'").get(row.id, membersLib.hashToken(t)) : null;
    if (!m) return show({ mode: 'reset-bad' });
    if (req.method === 'GET') return show({ mode: 'reset', token: t, error: '' });
    return run(() => {
      const err = membersLib.passwordProblem(body.password) || (String(body.password) !== String(body.password2 || '') ? 'The two passwords do not match.' : '');
      if (err) return show({ mode: 'reset', token: t, error: err });
      db.prepare("UPDATE site_members SET password_hash = ?, reset_hash = '', reset_expires = '' WHERE id = ?").run(bcrypt.hashSync(String(body.password), 10), m.id);
      res.redirect(`${home}?msg=reset`);
    });
  }
  return res.status(404).render('not-found');
}
app.all(['/site/:slug/members', '/site/:slug/members/:sub'], (req, res, next) => {
  membersRoute(req, res, next, db.prepare('SELECT * FROM sites WHERE slug = ?').get(req.params.slug), `/site/${req.params.slug}`, req.params.sub);
});

// owner side: see, approve, add, disable and remove members
app.get('/sites/:id/members', requireAuth, loadOwnedSite, (req, res) => {
  const link = req.session.memberResetLink; delete req.session.memberResetLink;
  const rows = db.prepare('SELECT id, email, name, status, created_at, last_login_at FROM site_members WHERE site_id = ? ORDER BY (status = \'pending\') DESC, id DESC').all(req.site.id);
  res.render('members-admin', { site: req.site, rows, cfg: membersLib.clean(req.site.sections.members), link: link || null, flash: str(req.query.f, 12), err: str(req.query.err, 160), mailOn: mailer.isConfigured() });
});
function loadMember(req, res, next) {
  const m = /^\d+$/.test(req.params.mid) ? db.prepare('SELECT * FROM site_members WHERE id = ? AND site_id = ?').get(req.params.mid, req.site.id) : null;
  if (!m) return res.status(404).render('not-found');
  req.member = m; next();
}
app.post('/sites/:id/members/add', requireAuth, loadOwnedSite, (req, res) => {
  const b = req.body || {}, back = (q) => res.redirect(`/sites/${req.site.id}/members?${q}`);
  const email = membersLib.normEmail(b.email), name = str(b.name, 80);
  if (!membersLib.okEmail(email)) return back('err=' + encodeURIComponent('That does not look like an email address.'));
  const pwErr = membersLib.passwordProblem(b.password); if (pwErr) return back('err=' + encodeURIComponent(pwErr));
  if (db.prepare('SELECT 1 FROM site_members WHERE site_id = ? AND email = ?').get(req.site.id, email)) return back('err=' + encodeURIComponent('That email already has an account.'));
  db.prepare("INSERT INTO site_members (site_id, email, name, password_hash, status) VALUES (?, ?, ?, ?, 'active')").run(req.site.id, email, name, bcrypt.hashSync(String(b.password), 10));
  back('f=added');
});
for (const [action, status] of [['approve', 'active'], ['enable', 'active'], ['disable', 'disabled']]) {
  app.post(`/sites/:id/members/:mid/${action}`, requireAuth, loadOwnedSite, loadMember, (req, res) => {
    db.prepare('UPDATE site_members SET status = ? WHERE id = ?').run(status, req.member.id);
    res.redirect(`/sites/${req.site.id}/members?f=${action}`);
  });
}
app.post('/sites/:id/members/:mid/delete', requireAuth, loadOwnedSite, loadMember, (req, res) => {
  db.prepare('DELETE FROM site_members WHERE id = ?').run(req.member.id);
  res.redirect(`/sites/${req.site.id}/members?f=deleted`);
});
// a one-hour link the owner can pass on when email is not set up (shown once)
app.post('/sites/:id/members/:mid/reset-link', requireAuth, loadOwnedSite, loadMember, (req, res) => {
  const t = membersLib.newToken();
  db.prepare("UPDATE site_members SET reset_hash = ?, reset_expires = datetime('now', '+1 hour') WHERE id = ?").run(membersLib.hashToken(t), req.member.id);
  const base = req.site.custom_domain ? `${req.protocol}://${req.site.custom_domain}` : `${req.protocol}://${req.get('host')}/site/${req.site.slug}`;
  req.session.memberResetLink = { email: req.member.email, url: `${base}/members/reset?t=${t}` };
  res.redirect(`/sites/${req.site.id}/members?f=link`);
});

// ---- custom domain routing ----
// If a request's Host header matches a published site's custom_domain,
// serve that site's pages at "/", "/about", "/contact", etc. instead of the
// normal dashboard/marketing page.
// (For this to work in a real deployment, the domain's DNS must point at
// this server, and a reverse proxy / TLS termination is the operator's job.)
app.use((req, res, next) => {
  const host = (req.hostname || '').toLowerCase();
  if (!host || host === 'localhost') return next();
  const row = db.prepare('SELECT * FROM sites WHERE custom_domain = ? AND published = 1').get(host);
  if (!row) return next();
  if (billing.isSuspended(row)) return res.status(503).render('suspended', { name: row.name });
  if ((req.method === 'GET' || req.method === 'HEAD') && req.path !== '/') {
    const hit = redirectFor(row, req.path);
    if (hit) return sendRedirect(req, res, hit, '');
  }
  const segments = req.path.split('/').filter(Boolean);
  if (segments[0] === 'book' && segments.length <= 2) return bookingRoute(req, res, next, row, '', segments[1]);
  if (segments[0] === 'members' && segments.length <= 2) return membersRoute(req, res, next, row, '', segments[1]);
  const isItemPage = segments.length === 2 && Object.prototype.hasOwnProperty.call(ITEM_ROUTES, segments[0]);
  if (segments.length > 1 && !isItemPage) return next(); // not a page; let normal routing 404 it
  const page = isItemPage ? ITEM_ROUTES[segments[0]] : segments.length === 0 ? 'home' : segments[0];
  if (!isItemPage && page !== 'home' && page !== 'thank-you' && page !== 'review' && !PAGE_KEYS.includes(page) && !legal.PAGES.includes(page) && page !== 'estimate') return next();
  const site = hydrateSite(row);
  const hasFlash = req.query.contact_sent === '1' || req.query.contact_error === '1';
  renderSitePage(req, res, next, {
    site, page, basePath: '',
    preview: false,
    contactSent: req.query.contact_sent === '1',
    contactError: req.query.contact_error === '1',
    itemSlug: isItemPage ? segments[1] : undefined,
    reviewThanks: page === 'review' && req.query.thanks === '1',
    reviewError: page === 'review' && req.query.error === '1',
    cacheKey: (hasFlash || page === 'review') ? null : `${row.custom_domain}:${isItemPage ? segments[0] + '/' + segments[1] : page}`
  });
});

// ---- "what did visitors do" counters (taps on call / email / text, button clicks) ----
const EVENT_NAMES = ['call', 'email', 'text', 'cta', 'directions', 'social'];
const eventLimiter = rateLimit({
  windowMs: 60 * 1000, limit: 90, standardHeaders: true, legacyHeaders: false, skip: () => isTestEnv,
  handler: (req, res) => res.status(204).end()
});
function handleEvent(req, res, row) {
  const b = req.body || {};
  const name = EVENT_NAMES.includes(b.e) ? b.e : '';
  if (name && row && row.published && !reports.isBot(req.get('user-agent'))) {
    const pathKey = String(b.p || '').toLowerCase().replace(/[^a-z0-9/_-]/g, '').slice(0, 80) || 'home';
    try {
      db.prepare(`INSERT INTO page_events (site_id, day, event, path, n) VALUES (?, date('now'), ?, ?, 1)
        ON CONFLICT(site_id, day, event, path) DO UPDATE SET n = n + 1`).run(row.id, name, pathKey);
    } catch (e) { /* counting must never break anything */ }
  }
  res.status(204).end();
}
app.post('/site/:slug/e', eventLimiter, (req, res) => handleEvent(req, res, db.prepare('SELECT * FROM sites WHERE slug = ?').get(req.params.slug)));
app.post('/e', eventLimiter, (req, res, next) => {
  const host = (req.hostname || '').toLowerCase();
  if (!host || host === 'localhost') return next();
  const row = db.prepare('SELECT * FROM sites WHERE custom_domain = ? AND published = 1').get(host);
  if (!row) return next();
  handleEvent(req, res, row);
});

// ---- website chat assistant ----
const chatLimiter = rateLimit({
  windowMs: 10 * 60 * 1000, limit: 24, standardHeaders: true, legacyHeaders: false, skip: () => isTestEnv,
  handler: (req, res) => res.status(429).json({ ok: false, reply: 'Too many messages for now. Please leave your details below or try again in a few minutes.' })
});
async function handleChat(req, res, row) {
  if (!row || !row.published || billing.isSuspended(row)) return res.status(404).json({ ok: false });
  const site = hydrateSite(row);
  const cfg = chat.clean(site.sections.chat);
  if (!cfg.enabled) return res.status(404).json({ ok: false });
  const messages = chat.sanitize((req.body || {}).messages);
  if (!messages.length) return res.status(400).json({ ok: false, reply: 'Please type a question.' });
  const day = new Date().toISOString().slice(0, 10);
  db.prepare('INSERT INTO chat_usage (site_id, day, n) VALUES (?, ?, 1) ON CONFLICT(site_id, day) DO UPDATE SET n = n + 1').run(row.id, day);
  const used = db.prepare('SELECT n FROM chat_usage WHERE site_id = ? AND day = ?').get(row.id, day).n;
  let reply = used <= cfg.dailyCap ? await chat.askAi(site, messages) : null;
  const ai = !!reply;
  if (!reply) reply = chat.fallback(site, messages[messages.length - 1].content);
  res.json({ ok: true, reply, ai });
}
function handleChatLead(req, res, row) {
  if (!row || !row.published || billing.isSuspended(row)) return res.status(404).json({ ok: false });
  const site = hydrateSite(row);
  if (!chat.clean(site.sections.chat).enabled) return res.status(404).json({ ok: false });
  const b = req.body || {};
  if (b.website) return res.json({ ok: true }); // honeypot
  const name = str(b.name, 100), phone = str(b.phone, 40);
  const email = isValidEmail(b.email || '') ? str(b.email, 254) : '';
  if (!name && !email && !phone) return res.status(400).json({ ok: false, error: 'Please add a phone number or email so we can reply.' });
  const transcript = chat.sanitize(([]).concat(Array.isArray(b.transcript) ? b.transcript : [])).map(m => `${m.role === 'user' ? 'Visitor' : 'Assistant'}: ${m.content}`).join('\n');
  const message = (str(b.message, 1000) + (transcript ? `\n\n--- Chat ---\n${transcript}` : '')).trim().slice(0, 2000);
  recordLead(req, row, { name, email, phone, message, service: '', answers: [] }, '', 'chat');
  res.json({ ok: true });
}
app.post('/site/:slug/chat', chatLimiter, (req, res) => handleChat(req, res, db.prepare('SELECT * FROM sites WHERE slug = ?').get(req.params.slug)));
app.post('/site/:slug/chat/lead', contactLimiter, (req, res) => handleChatLead(req, res, db.prepare('SELECT * FROM sites WHERE slug = ?').get(req.params.slug)));
const byHost = (fn) => (req, res, next) => {
  const host = (req.hostname || '').toLowerCase();
  if (!host || host === 'localhost') return next();
  const row = db.prepare('SELECT * FROM sites WHERE custom_domain = ? AND published = 1').get(host);
  if (!row) return next();
  return fn(req, res, row);
};
app.post('/chat', chatLimiter, byHost(handleChat));
app.post('/chat/lead', contactLimiter, byHost(handleChatLead));

// ---- quote / estimate calculator ----
function handleEstimate(req, res, row, basePath) {
  if (!row || !row.published) return res.status(404).render('not-found');
  if (billing.isSuspended(row)) return res.status(503).render('suspended', { name: row.name });
  const site = hydrateSite(row);
  const cfg = calc.normalize(site.sections.calculator);
  if (!calc.isUsable(cfg)) return res.status(404).render('not-found');
  const b = req.body || {};
  const back = (q) => res.redirect(`${basePath}/estimate?${q}`);
  if (b.website) return res.redirect(`${basePath}/thank-you`); // honeypot
  const answers = cfg.fields.map((f, i) => b['ce_' + i]);
  const r = calc.compute(cfg, answers);
  if (!r.ok) return back('error=' + encodeURIComponent(r.error.slice(0, 120)));
  const name = str(b.name, 100), phone = str(b.phone, 40);
  const email = isValidEmail(b.email || '') ? str(b.email, 254) : '';
  if (!email && !phone) return back('error=' + encodeURIComponent('Please add a phone number or email so we can reply.'));
  const lines = r.lines.map(l => ({ label: l.label, value: cfg.showPrice && l.amount ? `${l.value} (${calc.fmt(l.amount)})` : l.value }));
  if (cfg.showPrice && r.total > 0) lines.push({ label: 'Estimate shown to visitor', value: calc.rangeText(r) });
  const message = (cfg.showPrice && r.total > 0 ? `Asked for an estimate: ${calc.rangeText(r)}.` : 'Asked for a quote.') + (str(b.message, 1000) ? '\n' + str(b.message, 1000) : '');
  recordLead(req, row, { name, email, phone, message, service: '', answers: lines }, '', 'estimate');
  res.redirect(`${basePath}/thank-you`);
}
app.post('/site/:slug/estimate', contactLimiter, (req, res) => handleEstimate(req, res, db.prepare('SELECT * FROM sites WHERE slug = ?').get(req.params.slug), `/site/${req.params.slug}`));
app.post('/estimate', contactLimiter, byHost((req, res, row) => handleEstimate(req, res, row, '')));

// "Pay online" on a service: the price always comes from the owner's settings, never from the visitor
async function handleBuy(req, res, row, basePath) {
  if (!row || !row.published) return res.status(404).render('not-found');
  if (billing.isSuspended(row)) return res.status(503).render('suspended', { name: row.name });
  const site = hydrateSite(row);
  const svc = (site.sections.services.items || []).find(x => x.title === str((req.body || {}).service, 80));
  const cents = svc ? payments.toCents(svc.pay) : 0;
  if (!svc || !cents || !payReady(row, site)) return res.redirect(`${basePath}/services`);
  try {
    const pay = newPayment(row, { kind: 'purchase', description: svc.title, amountCents: cents, currency: site.sections.payments.currency });
    res.redirect(await startCheckout(req, row, pay));
  } catch (e) { console.error('Purchase checkout failed:', e.message); res.redirect(`${basePath}/services`); }
}
app.post('/site/:slug/buy', payLimiter, (req, res) => handleBuy(req, res, db.prepare('SELECT * FROM sites WHERE slug = ?').get(req.params.slug), `/site/${req.params.slug}`));
app.post('/buy', payLimiter, byHost((req, res, row) => handleBuy(req, res, row, '')));

app.post('/review', reviewLimiter, (req, res, next) => {
  const host = (req.hostname || '').toLowerCase();
  if (!host || host === 'localhost') return next();
  const row = db.prepare('SELECT * FROM sites WHERE custom_domain = ? AND published = 1').get(host);
  if (!row) return next();
  if (billing.isSuspended(row)) return res.status(503).render('suspended', { name: row.name });
  handleReviewSubmission(req, res, row, '');
});

app.post('/contact', contactLimiter, (req, res, next) => {
  const host = (req.hostname || '').toLowerCase();
  if (!host || host === 'localhost') return next();
  const row = db.prepare('SELECT * FROM sites WHERE custom_domain = ? AND published = 1').get(host);
  if (!row) return next();
  if (billing.isSuspended(row)) return res.status(503).render('suspended', { name: row.name });
  handleContactSubmission(req, res, row, '');
});

// ---- auth routes ----
app.get('/', (req, res) => {
  if (req.session.userId) return res.redirect('/dashboard');
  res.render('home');
});

app.get('/signup', (req, res) => res.render('signup', { error: null }));

app.post('/signup', authLimiter, (req, res) => {
  const email = str(req.body.email, 254).toLowerCase();
  const password = req.body.password || '';
  if (!isValidEmail(email) || !isValidPassword(password)) {
    return res.render('signup', { error: 'Please provide a valid email and a password of at least 6 characters.' });
  }
  const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(email);
  if (existing) {
    return res.render('signup', { error: 'An account with that email already exists.' });
  }
  const hash = bcrypt.hashSync(password, 10);
  const info = db.prepare('INSERT INTO users (email, password_hash) VALUES (?, ?)').run(email, hash);
  req.session.userId = info.lastInsertRowid;
  res.redirect('/dashboard');
});

app.get('/login', (req, res) => res.render('login', { error: null }));

app.post('/login', authLimiter, (req, res) => {
  const email = str(req.body.email, 254).toLowerCase();
  const password = req.body.password || '';
  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
  if (!user || !bcrypt.compareSync(password, user.password_hash)) {
    return res.render('login', { error: 'Invalid email or password.' });
  }
  req.session.userId = user.id;
  res.redirect('/dashboard');
});

app.post('/logout', (req, res) => {
  req.session.destroy(() => res.redirect('/'));
});

// ---- dashboard ----
function listSites(userId) {
  return db.prepare('SELECT * FROM sites WHERE user_id = ? ORDER BY updated_at DESC').all(userId);
}

function renderDashboard(req, res, extra = {}) {
  res.render('dashboard', {
    sites: listSites(req.session.userId),
    importError: null,
    generateError: null,
    hasAiProvider: hasAiProvider(),
    isAdmin: isAdmin(req.session.userId),
    hasPhotoProvider: hasPhotoProvider(),
    ...extra
  });
}

app.get('/dashboard', requireAuth, (req, res) => {
  renderDashboard(req, res);
});

app.post('/sites', requireAuth, (req, res) => {
  const name = str(req.body.name, 80) || 'My Site';
  const slug = uniqueSlug(name);
  const info = db.prepare(
    'INSERT INTO sites (user_id, slug, name, theme, sections, layout) VALUES (?, ?, ?, ?, ?, ?)'
  ).run(req.session.userId, slug, name, JSON.stringify(defaultTheme()), JSON.stringify(defaultSections()), JSON.stringify(defaultLayout()));
  res.redirect(`/sites/${info.lastInsertRowid}/edit`);
});

app.post('/sites/import', requireAuth, importLimiter, async (req, res) => {
  const sourceUrl = str(req.body.url, 2000);
  const socialUrl = str(req.body.social_url, 2000);
  if (!sourceUrl) {
    return renderDashboard(req, res, { importError: 'Please paste a URL.' });
  }

  try {
    const scraped = await scrapeUrl(sourceUrl);

    if (socialUrl) {
      // Best-effort only — a bad/blocked social link should never stop the
      // import itself, so any failure here is silently swallowed.
      try {
        const social = await scrapeSocialInspiration(socialUrl);
        applySocialInspiration(scraped.theme, scraped.sections, social);
      } catch { /* ignore — social inspiration is optional */ }
    }

    const slug = uniqueSlug(scraped.name);
    const info = db.prepare(
      'INSERT INTO sites (user_id, slug, name, theme, sections, layout, source_url, seo_title, seo_description) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
    ).run(
      req.session.userId,
      slug,
      scraped.name,
      JSON.stringify(scraped.theme),
      JSON.stringify(scraped.sections),
      JSON.stringify(defaultLayout()),
      scraped.sourceUrl,
      scraped.sections.seo.title,
      scraped.sections.seo.description
    );
    saveVersion(info.lastInsertRowid, scraped.theme, scraped.sections, defaultLayout(), 'Imported');
    res.redirect(`/sites/${info.lastInsertRowid}/edit?imported=1`);
  } catch (err) {
    renderDashboard(req, res, { importError: err.message || 'Could not import that site.' });
  }
});

// Drops AI-written copy into a sections object (hero text, about, services,
// FAQ, SEO) without touching photos, contact info, hours or credentials.
function applyCopy(sections, copy) {
  sections.hero.headline = copy.hero.headline;
  sections.hero.subheadline = copy.hero.subheadline;
  if (copy.hero.ctaText) sections.hero.ctaText = copy.hero.ctaText;
  sections.about.body = copy.about;
  sections.services.items = copy.services;
  if (copy.faq.length) sections.faq.items = copy.faq;
  if (copy.seoTitle) sections.seo.title = copy.seoTitle;
  if (copy.seoDescription) sections.seo.description = copy.seoDescription;
}

// Optional "client details" from the dashboard's generate form: contact info,
// real hours and a brand color, so the generated site is filled in from the
// start. Anything left blank is simply not touched.
function applyIntake(b, theme, sections) {
  const phone = str(b.phone, 40);
  const email = isValidEmail(b.email || '') ? str(b.email, 254) : '';
  const address = str(b.address, 200);
  if (phone) sections.contact.phone = phone;
  if (email) sections.contact.email = email;
  if (address) sections.contact.address = address;
  const city = str(b.city, 80);
  if (city) sections.meta.city = city;
  for (const k of ['facebook', 'instagram']) {
    if (isSafeUrl(b[k])) sections.contact.social[k] = str(b[k], 300);
  }

  const weekday = str(b.weekday_hours, 40);
  const saturday = str(b.saturday_hours, 40);
  const sunday = str(b.sunday_hours, 40);
  if (weekday) {
    const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
    sections.hours.items = [
      ...days.map(day => ({ day, time: weekday })),
      { day: 'Saturday', time: saturday || 'Closed' },
      { day: 'Sunday', time: sunday || 'Closed' }
    ];
  }

  const years = parseInt(b.years_in_business, 10);
  if (Number.isInteger(years) && years > 0 && years < 200) {
    sections.trust.stats = [{ value: String(years), label: years === 1 ? 'Year in business' : 'Years in business' }];
  }
  const badges = splitList(b.badges, 40, 8);
  if (badges.length) sections.trust.badges = badges;
  const areas = splitList(b.service_areas, 50, 30);
  if (areas.length) sections.trust.serviceAreas = areas;

  if (b.use_brand_color === '1' && isValidHexColor(b.brand_color)) {
    theme.primaryColor = b.brand_color.trim();
    theme.accentColor = darkenHex(theme.primaryColor);
  }
}

// A tagline that is only "<Business name>: <type>" is a placeholder; use the first sentence of the about text instead.
function tidyHero(sections, name, aboutText) {
  const sub = String((sections.hero && sections.hero.subheadline) || '').trim();
  const nm = String(name || '').trim().toLowerCase();
  const bare = !sub || (nm && sub.toLowerCase().startsWith(nm) && sub.length <= nm.length + 30 && /[:\-\u2013\u2014]/.test(sub.slice(nm.length, nm.length + 3)));
  if (bare && aboutText) {
    const first = String(aboutText).split(/(?<=[.!?])\s+/)[0].trim();
    if (first) sections.hero.subheadline = first.slice(0, 160);
  }
}

async function baseSiteFromTemplate(businessType, businessName) {
    const tpl = findTemplate(businessType);
    const filled = fillTemplate(tpl, businessName, businessType);
    const { hero, gallery } = await fetchPhotoSet(tpl.photoQueries, { galleryCount: 6 });
    const colors = colorForCategory(tpl.id);

    const theme = {
      primaryColor: colors.primaryColor,
      accentColor: colors.accentColor,
      font: 'Inter, system-ui, sans-serif',
      style: 'modern',
      headingFont: '', bodyFont: '', headingCase: '',
      logoUrl: ''
    };
    const tplLook = tpl.look || templateLooks[tpl.id];
    if (tplLook) { // a template can bring its own style, colors and fonts
      const L = tplLook;
      if (L.style) theme.style = L.style;
      if (L.primaryColor) theme.primaryColor = L.primaryColor;
      if (L.accentColor) theme.accentColor = L.accentColor;
      if (L.headingFont) theme.headingFont = L.headingFont;
      if (L.bodyFont) theme.bodyFont = L.bodyFont;
      if (L.headingCase) theme.headingCase = L.headingCase;
      if (L.homeLayout) theme.homeLayout = L.homeLayout;
      if (L.homeFull) theme.homeLayout = 'full';
    }

    // a new site starts with the full home page (services, reviews and so on), not just a hero and photos
    if (!theme.homeLayout || theme.homeLayout === 'basic') theme.homeLayout = 'full';
    const sections = defaultSections();
    sections.hero = {
      headline: filled.hero.headline,
      subheadline: filled.hero.subheadline,
      imageUrl: hero ? hero.url : '',
      ctaText: filled.hero.ctaText,
      ctaLink: '#contact'
    };
    tidyHero(sections, filled.name, filled.about);
    sections.about = { heading: 'About Us', body: filled.about, imageUrl: gallery[0] ? gallery[0].url : '' };
    sections.services = { heading: 'What We Offer', items: filled.services };
    sections.faq = { heading: 'Frequently Asked Questions', items: filled.faq };
    Object.assign(sections.about, { eyebrow: 'Who we are' }); Object.assign(sections.services, { eyebrow: 'What we do' }); Object.assign(sections.faq, { eyebrow: 'Good to know' });
    { // template blocks: fill empty photo spots from the fetched photos (the first is used by About)
      let g = 1;
      sections.blocks = { items: (filled.blocks || []).map(b => {
        const wantsPhoto = b.type === 'photoText' || b.type === 'cta';
        return { side: 'auto', bg: 'none', place: 'bottom', buttonText: '', buttonUrl: '', imageUrl: '', ...b,
          imageUrl: wantsPhoto ? (b.imageUrl || (gallery[g++] ? gallery[g - 1].url : '')) : '' };
      }) };
    }
    sections.gallery = { heading: 'Gallery', images: gallery.map(g => g.url) };
    // the booking page starts switched off, set up for this kind of business
    sections.booking = booking.applyPreset(sections.booking, booking.TEMPLATE_KIND[tpl.id] || 'generic', filled.services);
    sections.seo = {
      title: `${filled.name} | ${tpl.label}`.slice(0, 70),
      description: filled.hero.subheadline.slice(0, 160)
    };

    sections.meta.businessType = businessType;
    theme.motionStyle = app.locals.motionLib.suggest({ templateId: tpl.id, style: theme.style, advice: tpl.id !== 'generic' ? industryDesign.industryDesign(tpl.id) : null });
    return { tpl, filled, theme, sections, hero, gallery };
}

// Builds a generated site in memory (nothing saved). Used by both "generate" and "preview first".
async function buildGeneratedSite(body) {
  const businessType = str(body.business_type, 100);
  const businessName = str(body.business_name, 80);
  const socialUrl = str(body.social_url, 2000);
  const { tpl, filled, theme, sections } = await baseSiteFromTemplate(businessType, businessName);
  applyIntake(body, theme, sections);
  if (sections.meta.city) {
    sections.seo.title = `${filled.name} | ${tpl.label} in ${sections.meta.city}`.slice(0, 70);
  }
  // Optional AI-written copy; falls back to the built-in template text.
  let copySource = 'template';
  const aiCopy = await generateCopy({
    name: filled.name,
    type: businessType,
    address: sections.contact.address,
    city: sections.meta.city,
    serviceAreas: sections.trust.serviceAreas,
    years: sections.trust.stats[0] ? sections.trust.stats[0].value : '',
    badges: sections.trust.badges,
    specialties: str(body.specialties, 600),
    design: designBrief.copyBrief(businessType, theme.style)
  });
  if (aiCopy) {
    copySource = 'ai';
    applyCopy(sections, aiCopy);
  }
  tidyHero(sections, filled.name, sections.about && sections.about.body);
  if (socialUrl) {
    // Same best-effort contract as the importer: never let a bad/blocked social link stop generation.
    try {
      const social = await scrapeSocialInspiration(socialUrl);
      applySocialInspiration(theme, sections, social, { preferOverHero: true });
    } catch { /* ignore: social inspiration is optional */ }
  }
  return { name: filled.name, theme, sections, copySource };
}

function insertGeneratedSite(userId, g, label) {
  const slug = uniqueSlug(g.name);
  const layout = defaultLayout();
  const info = db.prepare(
    'INSERT INTO sites (user_id, slug, name, theme, sections, layout, seo_title, seo_description) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
  ).run(userId, slug, g.name, JSON.stringify(g.theme), JSON.stringify(g.sections), JSON.stringify(layout), g.sections.seo.title, g.sections.seo.description);
  saveVersion(info.lastInsertRowid, g.theme, g.sections, layout, label);
  return info.lastInsertRowid;
}

app.post('/sites/generate', requireAuth, generateLimiter, async (req, res) => {
  const businessType = str(req.body.business_type, 100);
  if (!businessType) {
    return renderDashboard(req, res, { generateError: 'Please describe the type of business (e.g. "plumbing company").' });
  }
  try {
    const g = await buildGeneratedSite(req.body);
    if (req.body.preview === '1') { // look first, save only if the owner likes it
      db.prepare("DELETE FROM site_drafts WHERE created_at < datetime('now', '-7 days')").run();
      const n = db.prepare('SELECT COUNT(*) AS n FROM site_drafts WHERE user_id = ?').get(req.session.userId).n;
      if (n >= 20) db.prepare('DELETE FROM site_drafts WHERE id IN (SELECT id FROM site_drafts WHERE user_id = ? ORDER BY id LIMIT ?)').run(req.session.userId, n - 19);
      const token = nanoid(20);
      db.prepare('INSERT INTO site_drafts (user_id, token, name, theme, sections, copy_source) VALUES (?, ?, ?, ?, ?, ?)')
        .run(req.session.userId, token, g.name, JSON.stringify(g.theme), JSON.stringify(g.sections), g.copySource);
      return res.redirect(`/sites/draft/${token}`);
    }
    const id = insertGeneratedSite(req.session.userId, g, 'Generated');
    res.redirect(`/sites/${id}/edit?generated=${g.copySource === 'ai' ? 'ai' : '1'}`);
  } catch (err) {
    renderDashboard(req, res, { generateError: 'Could not generate a site. Please try again.' });
  }
});

// ---- preview before creating ----
function loadDraft(req, res, next) {
  const row = /^[A-Za-z0-9_-]{10,64}$/.test(req.params.token) ? db.prepare('SELECT * FROM site_drafts WHERE token = ? AND user_id = ?').get(req.params.token, req.session.userId) : null;
  if (!row) return res.status(404).render('not-found');
  req.draft = row;
  req.draftSite = hydrateSite({ id: 0, user_id: row.user_id, slug: 'preview', name: row.name, theme: row.theme, sections: row.sections, layout: JSON.stringify(defaultLayout()), published: 0, custom_domain: null });
  next();
}
const DRAFT_LOOKS = intake.MOODS.filter(m => m[0]);
app.get('/sites/draft/:token', requireAuth, loadDraft, (req, res) => {
  res.render('draft-preview', { d: req.draft, token: req.params.token, looks: DRAFT_LOOKS, current: req.draftSite.theme.style, ai: req.draft.copy_source === 'ai' });
});
app.post('/sites/draft/:token/look', requireAuth, loadDraft, (req, res) => {
  const look = DRAFT_LOOKS.find(m => m[0] === req.body.look);
  if (look) {
    const theme = req.draftSite.theme;
    theme.style = look[0]; theme.homeLayout = ''; delete theme.homeFull;
    db.prepare('UPDATE site_drafts SET theme = ? WHERE id = ?').run(JSON.stringify(theme), req.draft.id);
  }
  res.redirect(`/sites/draft/${req.params.token}`);
});
app.post('/sites/draft/:token/create', requireAuth, loadDraft, (req, res) => {
  const d = req.draft;
  const g = { name: d.name, theme: JSON.parse(d.theme), sections: mergeSectionsWithDefaults(JSON.parse(d.sections)), copySource: d.copy_source };
  const id = insertGeneratedSite(req.session.userId, g, 'Generated');
  db.prepare('DELETE FROM site_drafts WHERE id = ?').run(d.id);
  res.redirect(`/sites/${id}/edit?generated=${d.copy_source === 'ai' ? 'ai' : '1'}`);
});
app.post('/sites/draft/:token/discard', requireAuth, loadDraft, (req, res) => {
  db.prepare('DELETE FROM site_drafts WHERE id = ?').run(req.draft.id);
  res.redirect('/');
});
const renderDraft = (req, res, page) => renderSitePage(req, res, null, {
  site: req.draftSite, page, basePath: `/sites/draft/${req.params.token}/frame`,
  preview: true, contactSent: false, contactError: false, cacheKey: null
});
app.get('/sites/draft/:token/frame', requireAuth, loadDraft, (req, res) => renderDraft(req, res, 'home'));
app.get('/sites/draft/:token/frame/:page', requireAuth, loadDraft, (req, res) => renderDraft(req, res, req.params.page));

app.post('/sites/:id/rewrite-copy', requireAuth, loadOwnedSite, generateLimiter, async (req, res) => {
  const site = req.site;
  const back = (q) => res.redirect(`/sites/${site.id}/edit?${q}`);
  if (!hasAiProvider()) return back('rewrite=off');
  const t = site.sections.trust;
  const copy = await generateCopy({
    name: site.name,
    type: (site.sections.meta && site.sections.meta.businessType) || site.name,
    address: site.sections.contact.address,
    city: site.sections.meta && site.sections.meta.city,
    serviceAreas: t.serviceAreas,
    years: t.stats[0] && /year/i.test(t.stats[0].label) ? t.stats[0].value : '',
    badges: t.badges,
    services: site.sections.services.items.map(i => i.title),
    design: designBrief.copyBrief((site.sections.meta && site.sections.meta.businessType) || '', site.theme.style)
  }, str(req.body.instruction, 500));
  if (!copy) return back('rewrite=failed');

  saveVersion(site.id, site.theme, site.sections, site.layout, 'Before AI rewrite');
  const sections = JSON.parse(JSON.stringify(site.sections));
  applyCopy(sections, copy);
  db.prepare(
    `UPDATE sites SET sections = ?, seo_title = ?, seo_description = ?, updated_at = datetime('now') WHERE id = ?`
  ).run(JSON.stringify(sections), sections.seo.title, sections.seo.description, site.id);
  invalidateSiteCache(site);
  back('rewrite=done');
});


// ---- chat-to-edit: describe a change, review it, then apply ----
// Proposals live in memory for 15 minutes; applying re-validates every operation against the current site.
const editProposals = new Map();
function editProposeHandler(scope) {
  return async (req, res) => {
    const site = req.site;
    const instruction = str((req.body || {}).instruction, 600);
    if (!instruction) return res.status(400).json({ ok: false, error: 'Tell me what you would like to change.' });
    if (!hasAiProvider()) return res.json({ ok: false, error: 'AI editing isn\'t set up yet — add ANTHROPIC_API_KEY to the .env file.' });
    const text = await aiComplete({ system: chatedit.SYSTEM, prompt: chatedit.buildPrompt(site, instruction, scope, scope === 'client' ? '' : designBrief.editBrief(site)), maxTokens: 2000 });
    const parsed = chatedit.parseReply(text);
    if (!parsed) return res.json({ ok: false, error: 'The AI didn\'t give a usable answer. Nothing was changed — try again or word it differently.' });
    const result = chatedit.applyOps(site, parsed.ops, { scope, styles: extraThemes.ALL_STYLES });
    if (!result.changes.length) return res.json({ ok: true, reply: parsed.reply || 'I couldn\'t find anything to change for that request.', changes: [], token: '' });
    for (const [k, v] of editProposals) if (v.exp < Date.now()) editProposals.delete(k);
    const token = crypto.randomBytes(16).toString('hex');
    editProposals.set(token, { siteId: site.id, scope, ops: parsed.ops, instruction, exp: Date.now() + 15 * 60 * 1000 });
    const heads = scope === 'client' ? [] : designBrief.warnings(site, parsed.ops);
    res.json({ ok: true, reply: [parsed.reply, ...heads.map(h => 'Heads up: ' + h)].filter(Boolean).join(' '), notes: heads, changes: result.changes, token, skipped: result.rejected });
  };
}
function editApplyHandler(scope) {
  return (req, res) => {
    const site = req.site;
    const p = editProposals.get(str((req.body || {}).token, 64));
    if (!p || p.exp < Date.now() || p.siteId !== site.id || p.scope !== scope) return res.status(400).json({ ok: false, error: 'That suggestion expired. Ask again.' });
    editProposals.delete(str(req.body.token, 64));
    const result = chatedit.applyOps(site, p.ops, { scope, styles: extraThemes.ALL_STYLES });
    if (!result.changes.length) return res.json({ ok: false, error: 'Nothing to apply.' });
    saveVersion(site.id, site.theme, site.sections, site.layout, ('Before AI edit: ' + p.instruction).slice(0, 60));
    db.prepare(`UPDATE sites SET theme = ?, sections = ?, seo_title = ?, seo_description = ?, updated_at = datetime('now') WHERE id = ?`)
      .run(JSON.stringify(result.theme), JSON.stringify(result.sections), result.sections.seo.title, result.sections.seo.description, site.id);
    invalidateSiteCache(site);
    res.json({ ok: true, applied: result.changes.length });
  };
}
app.post('/sites/:id/ai-edit', requireAuth, loadOwnedSite, generateLimiter, editProposeHandler('owner'));
app.post('/sites/:id/ai-edit/apply', requireAuth, loadOwnedSite, editApplyHandler('owner'));

// "Fill in for this business": swap the wording and/or photos for ones that suit the business type.
// Colors, style, contact details, hours, reviews and everything else are left alone. The old version is kept in history.
app.post('/sites/:id/apply-industry', requireAuth, loadOwnedSite, generateLimiter, async (req, res) => {
  const site = req.site, back = (k) => res.redirect(`/sites/${site.id}/edit?ind=${k}#designAdvice`);
  const what = ['photos', 'wording', 'both'].includes(req.body.what) ? req.body.what : 'both';
  const meta = site.sections.meta || {};
  const typed = str(req.body.business_type, 100) || meta.businessType || '';
  let tpl = findTemplate(typed);
  if (tpl.id === 'generic') { // no type saved: guess from the name and services
    const guess = [site.name, ...((site.sections.services && site.sections.services.items) || []).map(x => x && x.title)].filter(Boolean).join(' ');
    tpl = findTemplate(guess);
  }
  if (tpl.id === 'generic') return back('notype');
  const sections = JSON.parse(JSON.stringify(site.sections));
  const done = [];
  if (what !== 'wording') {
    let set = null;
    try { set = hasPhotoProvider() ? await fetchPhotoSet(tpl.photoQueries, { galleryCount: 6 }) : null; } catch { set = null; }
    if (set && (set.hero || (set.gallery && set.gallery.length))) {
      const gallery = set.gallery || [];
      if (set.hero) sections.hero.imageUrl = set.hero.url;
      if (gallery[0]) sections.about.imageUrl = gallery[0].url;
      if (gallery.length) sections.gallery = Object.assign({ heading: 'Gallery' }, sections.gallery, { images: gallery.map(g => g.url), alts: [] });
      let g = 1;
      if (sections.blocks && Array.isArray(sections.blocks.items)) sections.blocks.items.forEach(b => {
        if ((b.type === 'photoText' || b.type === 'cta') && gallery[g]) b.imageUrl = gallery[g++].url;
      });
      done.push('photos');
    }
  }
  let ai = false;
  if (what !== 'photos') {
    const filled = fillTemplate(tpl, site.name, typed || tpl.label.toLowerCase());
    sections.hero.headline = filled.hero.headline;
    sections.hero.subheadline = filled.hero.subheadline;
    if (filled.hero.ctaText) sections.hero.ctaText = filled.hero.ctaText;
    sections.about.body = filled.about;
    sections.services.items = filled.services;
    if (filled.faq && filled.faq.length) sections.faq.items = filled.faq;
    if (hasAiProvider()) {
      try {
        const copy = await generateCopy({
          name: site.name, type: typed || tpl.label, address: (sections.contact || {}).address, city: meta.city,
          serviceAreas: (sections.trust || {}).serviceAreas, years: ((sections.trust || {}).stats || [])[0] ? sections.trust.stats[0].value : '',
          badges: (sections.trust || {}).badges, specialties: '', design: designBrief.copyBrief(typed || tpl.label, site.theme.style)
        });
        if (copy) { applyCopy(sections, copy); ai = true; }
      } catch { /* keep the template wording */ }
    }
    done.push(ai ? 'wording (AI)' : 'wording');
  }
  if (what !== 'photos') tidyHero(sections, site.name, sections.about && sections.about.body);
  if (!done.length) return back('nophotos');
  sections.meta = Object.assign({}, sections.meta, { businessType: typed || sections.meta.businessType || tpl.label.toLowerCase() });
  saveVersion(site.id, site.theme, site.sections, site.layout, 'Before industry fill-in');
  const theme = Object.assign({}, site.theme);
  if (theme.homeLayout === 'basic') theme.homeLayout = 'full'; // the bare hero-and-photos layout hides the content just filled in
  db.prepare(`UPDATE sites SET theme = ?, sections = ?, seo_title = ?, seo_description = ?, updated_at = datetime('now') WHERE id = ?`)
    .run(JSON.stringify(theme), JSON.stringify(sections), (sections.seo || {}).title || site.seo_title, (sections.seo || {}).description || site.seo_description, site.id);
  invalidateSiteCache(site);
  return back(what === 'both' && done.length === 1 ? 'partial' : 'ok');
});

const photoSearchLimiter = rateLimit({
  windowMs: 60 * 1000, limit: 40, standardHeaders: true, legacyHeaders: false,
  skip: () => isTestEnv, message: { ok: false, error: 'Too many searches — wait a moment.' }
});

// Photo picker: search free stock photos for the editor's "Choose photo" button.
app.get('/sites/:id/photos', requireAuth, loadOwnedSite, photoSearchLimiter, async (req, res) => {
  if (!hasPhotoProvider()) return res.json({ ok: true, configured: false, photos: [], hasMore: false });
  const q = str(req.query.q, 100) || (req.site.sections.meta && req.site.sections.meta.businessType) || req.site.name;
  const page = Math.min(Math.max(parseInt(req.query.page, 10) || 1, 1), 20);
  const { photos, hasMore } = await searchPhotosPage(q, 15, page);
  res.json({
    ok: true, configured: true, query: q, page, hasMore,
    photos: photos.map(p => ({ url: p.url, thumb: p.thumb, photographer: p.photographer, pageUrl: p.pageUrl }))
  });
});

// ---- client edit links ----
// The owner can create one private link per site. Whoever has it can change
// the day-to-day basics (headline, about text, services, hours, contact
// details, gallery photos) without an account — but not the design, layout,
// publishing, domain or credentials. Only a hash of the token is stored.
const hashToken = (t) => crypto.createHash('sha256').update(t).digest('hex');

const clientLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, limit: 300, standardHeaders: true, legacyHeaders: false,
  skip: () => isTestEnv, message: 'Too many requests. Please try again in a few minutes.'
});

function loadClientSite(req, res, next) {
  // the token is a secret: never let it leak through Referer headers or search engines
  res.set('Referrer-Policy', 'no-referrer');
  res.set('X-Robots-Tag', 'noindex, nofollow');
  const token = String(req.params.token || '');
  const link = /^[A-Za-z0-9_-]{20,64}$/.test(token)
    ? db.prepare('SELECT * FROM client_links WHERE token_hash = ?').get(hashToken(token))
    : null;
  const site = link ? getSite(link.site_id) : null;
  if (!site) return res.status(404).render('not-found');
  req.site = site;
  req.clientLink = link;
  next();
}

// Applies only the fields a client may change onto a copy of the stored
// sections. A field group is only touched if the form actually included it.
function applyClientEdits(sections, b) {
  const cap = (v, n) => str(v, n);
  if (b.hero_headline !== undefined) sections.hero.headline = cap(b.hero_headline, 100);
  if (b.hero_subheadline !== undefined) sections.hero.subheadline = cap(b.hero_subheadline, 160);
  if (b.about_body !== undefined) sections.about.body = cap(b.about_body, 2000);
  if (b.services_present) {
    // clients don't see the longer service-page text; keep it for services that still exist
    const prevByTitle = new Map((sections.services.items || []).map(it => [it.title, it]));
    sections.services.items = ([]).concat(b.service_title || []).map((title, i) => ({
      ...(prevByTitle.get(cap(title, 60)) || {}),
      title: cap(title, 60),
      description: cap(([]).concat(b.service_description || [])[i], 300),
      detail: (prevByTitle.get(cap(title, 60)) || {}).detail || ''
    })).filter(item => item.title || item.description).slice(0, 12);
  }
  if (b.hours_present) {
    sections.hours.items = ([]).concat(b.hours_day || []).map((day, i) => ({
      day: cap(day, 20),
      time: cap(([]).concat(b.hours_time || [])[i], 60)
    })).filter(item => item.day).slice(0, 7);
  }
  if (b.contact_phone !== undefined) sections.contact.phone = cap(b.contact_phone, 40);
  if (b.contact_email !== undefined) sections.contact.email = isValidEmail(b.contact_email || '') ? str(b.contact_email, 254) : '';
  if (b.contact_address !== undefined) sections.contact.address = cap(b.contact_address, 200);
  if (b.gallery_present) {
    // keep each photo's description when the client re-orders or removes photos
    const oldAlt = {};
    (sections.gallery.images || []).forEach((u, i) => { oldAlt[u] = ((sections.gallery.alts || [])[i]) || ''; });
    sections.gallery.images = ([]).concat(b.gallery_image || []).map(s => str(s, 500)).filter(s => s && isSafeUrl(s)).slice(0, 20);
    sections.gallery.alts = sections.gallery.images.map(u => oldAlt[u] || '');
  }
}

app.post('/sites/:id/client-link', requireAuth, loadOwnedSite, (req, res) => {
  const token = nanoid(32);
  db.prepare('DELETE FROM client_links WHERE site_id = ?').run(req.site.id);
  db.prepare('INSERT INTO client_links (site_id, token_hash) VALUES (?, ?)').run(req.site.id, hashToken(token));
  // shown once on the next editor page load; it can't be recovered afterwards
  req.session.newClientLink = `${req.protocol}://${req.get('host')}/client/${token}`;
  res.redirect(`/sites/${req.site.id}/edit?clientlink=1`);
});

app.post('/sites/:id/client-link/revoke', requireAuth, loadOwnedSite, (req, res) => {
  db.prepare('DELETE FROM client_links WHERE site_id = ?').run(req.site.id);
  res.redirect(`/sites/${req.site.id}/edit?clientlink=revoked`);
});

app.get('/client/:token', clientLimiter, loadClientSite, (req, res) => {
  res.render('client-edit', { site: req.site, base: `/client/${req.params.token}`, saved: req.query.saved === '1' });
});

function saveClientEdits(site, body) {
  saveVersion(site.id, site.theme, site.sections, site.layout, 'Before client edit');
  const sections = JSON.parse(JSON.stringify(site.sections));
  applyClientEdits(sections, body || {});
  db.prepare(`UPDATE sites SET sections = ?, updated_at = datetime('now') WHERE id = ?`).run(JSON.stringify(sections), site.id);
  invalidateSiteCache(site);
}


app.post('/client/:token/ai-edit', clientLimiter, loadClientSite, generateLimiter, editProposeHandler('client'));
app.post('/client/:token/ai-edit/apply', clientLimiter, loadClientSite, editApplyHandler('client'));

app.post('/client/:token', clientLimiter, loadClientSite, (req, res) => {
  saveClientEdits(req.site, req.body);
  db.prepare(`UPDATE client_links SET last_used_at = datetime('now') WHERE id = ?`).run(req.clientLink.id);
  res.redirect(`/client/${req.params.token}?saved=1`);
});

app.post('/client/:token/upload', clientLimiter, loadClientSite, (req, res) => {
  upload.single('image')(req, res, async (err) => {
    if (err) return res.status(400).json({ ok: false, error: err.message });
    if (!req.file) return res.status(400).json({ ok: false, error: 'No file received.' });
    await optimizeUpload(req.file);
    res.json({ ok: true, url: `/uploads/${req.file.filename}` });
  });
});


// ---- client logins ----
// Named logins (email + password) for a site's client, as an alternative to the private link. A client
// can change the same day-to-day basics as with the link, nothing about design, publishing or domain.
// The owner invites them; the invite link (valid 7 days, shown once) lets them choose their own password.
// The session key is separate from the owner's (`clientIds`), so signing in here never grants owner access.
const INVITE_DAYS = 7;
function issueInvite(userId) {
  const token = nanoid(32);
  const expires = new Date(Date.now() + INVITE_DAYS * 86400000).toISOString();
  db.prepare('UPDATE client_users SET invite_hash = ?, invite_expires = ? WHERE id = ?').run(hashToken(token), expires, userId);
  return token;
}
async function emailInvite(req, site, user, link) {
  if (!mailer.isConfigured()) return false;
  try {
    await mailer.sendReport({
      to: user.email, subject: `Edit your ${site.name} website`,
      text: `Hi${user.name ? ' ' + user.name : ''},\n\nYou can now update your website, ${site.name}, yourself: your text, hours, contact details and photos.\n\nChoose your password here (the link works for ${INVITE_DAYS} days):\n${link}\n\nAfter that, log in any time at ${req.protocol}://${req.get('host')}/client-login\n`,
      replyTo: ''
    });
    return true;
  } catch (e) { console.error('Invite email failed:', e.message); return false; }
}
app.post('/sites/:id/client-users', requireAuth, loadOwnedSite, async (req, res) => {
  const email = str((req.body || {}).email, 254).toLowerCase();
  const name = str((req.body || {}).name, 80);
  if (!isValidEmail(email)) return res.redirect(`/sites/${req.site.id}/edit?clientuser=bademail`);
  const count = db.prepare('SELECT COUNT(*) AS n FROM client_users WHERE site_id = ?').get(req.site.id).n;
  let user = db.prepare('SELECT * FROM client_users WHERE site_id = ? AND email = ?').get(req.site.id, email);
  if (!user && count >= 10) return res.redirect(`/sites/${req.site.id}/edit?clientuser=toomany`);
  if (!user) {
    const info = db.prepare('INSERT INTO client_users (site_id, email, name) VALUES (?, ?, ?)').run(req.site.id, email, name);
    user = db.prepare('SELECT * FROM client_users WHERE id = ?').get(info.lastInsertRowid);
  }
  await finishInvite(req, res, user);
});
app.post('/sites/:id/client-users/:uid/invite', requireAuth, loadOwnedSite, async (req, res) => {
  const user = db.prepare('SELECT * FROM client_users WHERE id = ? AND site_id = ?').get(req.params.uid, req.site.id);
  if (!user) return res.redirect(`/sites/${req.site.id}/edit`);
  await finishInvite(req, res, user);
});
async function finishInvite(req, res, user) {
  // a new invite also signs out whoever held the old password
  db.prepare("UPDATE client_users SET password_hash = '' WHERE id = ?").run(user.id);
  const link = `${req.protocol}://${req.get('host')}/client-invite/${issueInvite(user.id)}`;
  const emailed = await emailInvite(req, req.site, user, link);
  req.session.newInvite = { link, email: user.email, emailed };
  res.redirect(`/sites/${req.site.id}/edit?clientuser=invited`);
}
app.post('/sites/:id/client-users/:uid/delete', requireAuth, loadOwnedSite, (req, res) => {
  db.prepare('DELETE FROM client_users WHERE id = ? AND site_id = ?').run(req.params.uid, req.site.id);
  res.redirect(`/sites/${req.site.id}/edit?clientuser=removed`);
});

function inviteUser(token) {
  if (!/^[A-Za-z0-9_-]{20,64}$/.test(String(token || ''))) return null;
  const u = db.prepare('SELECT * FROM client_users WHERE invite_hash = ?').get(hashToken(token));
  return u && u.invite_expires && new Date(u.invite_expires) > new Date() ? u : null;
}
app.get('/client-invite/:token', clientLimiter, (req, res) => {
  res.set({ 'Referrer-Policy': 'no-referrer', 'X-Robots-Tag': 'noindex, nofollow' });
  const u = inviteUser(req.params.token);
  if (!u) return res.status(404).render('client-login', { mode: 'expired', error: '', email: '' });
  res.render('client-login', { mode: 'invite', error: '', email: u.email, siteName: getSite(u.site_id).name });
});
app.post('/client-invite/:token', clientLimiter, (req, res) => {
  res.set({ 'Referrer-Policy': 'no-referrer', 'X-Robots-Tag': 'noindex, nofollow' });
  const u = inviteUser(req.params.token);
  if (!u) return res.status(404).render('client-login', { mode: 'expired', error: '', email: '' });
  const pw = String((req.body || {}).password || '');
  const site = getSite(u.site_id);
  if (pw.length < 8) return res.render('client-login', { mode: 'invite', error: 'Choose a password with at least 8 characters.', email: u.email, siteName: site.name });
  if (pw !== String((req.body || {}).password2 || '')) return res.render('client-login', { mode: 'invite', error: 'The two passwords do not match.', email: u.email, siteName: site.name });
  db.prepare("UPDATE client_users SET password_hash = ?, invite_hash = NULL, invite_expires = NULL, last_login_at = datetime('now') WHERE id = ?").run(bcrypt.hashSync(pw, 10), u.id);
  req.session.clientIds = [u.id];
  res.redirect(`/portal/${u.site_id}`);
});
app.get('/client-login', (req, res) => {
  res.set('X-Robots-Tag', 'noindex, nofollow');
  res.render('client-login', { mode: 'login', error: '', email: '' });
});
app.post('/client-login', authLimiter, (req, res) => {
  const email = str((req.body || {}).email, 254).toLowerCase();
  const pw = String((req.body || {}).password || '');
  const rows = db.prepare("SELECT * FROM client_users WHERE email = ? AND password_hash != ''").all(email);
  const ok = rows.filter(r => bcrypt.compareSync(pw, r.password_hash));
  if (!ok.length) return res.status(401).render('client-login', { mode: 'login', error: 'That email and password do not match.', email });
  for (const r of ok) db.prepare("UPDATE client_users SET last_login_at = datetime('now') WHERE id = ?").run(r.id);
  req.session.clientIds = ok.map(r => r.id);
  res.redirect(ok.length === 1 ? `/portal/${ok[0].site_id}` : '/portal');
});
app.post('/client-logout', (req, res) => {
  delete req.session.clientIds;
  res.redirect('/client-login');
});
function clientSession(req) {
  const ids = Array.isArray(req.session && req.session.clientIds) ? req.session.clientIds : [];
  return ids.length ? db.prepare(`SELECT * FROM client_users WHERE id IN (${ids.map(() => '?').join(',')}) AND password_hash != ''`).all(...ids) : [];
}
app.get('/portal', clientLimiter, (req, res) => {
  const users = clientSession(req);
  if (!users.length) return res.redirect('/client-login');
  if (users.length === 1) return res.redirect(`/portal/${users[0].site_id}`);
  res.render('client-login', { mode: 'pick', error: '', email: users[0].email, sites: users.map(u => getSite(u.site_id)).filter(Boolean) });
});
function loadPortalSite(req, res, next) {
  res.set({ 'Referrer-Policy': 'no-referrer', 'X-Robots-Tag': 'noindex, nofollow' });
  const sid = parseInt(req.params.siteId, 10);
  const user = clientSession(req).find(u => u.site_id === sid);
  if (!user) return res.redirect('/client-login');
  const site = getSite(sid);
  if (!site) return res.status(404).render('not-found');
  req.site = site; req.portalUser = user;
  next();
}
app.get('/portal/:siteId', clientLimiter, loadPortalSite, (req, res) => {
  res.render('client-edit', { site: req.site, base: `/portal/${req.site.id}`, saved: req.query.saved === '1', portalUser: req.portalUser });
});
app.post('/portal/:siteId/ai-edit', clientLimiter, loadPortalSite, generateLimiter, editProposeHandler('client'));
app.post('/portal/:siteId/ai-edit/apply', clientLimiter, loadPortalSite, editApplyHandler('client'));
app.post('/portal/:siteId', clientLimiter, loadPortalSite, (req, res) => {
  saveClientEdits(req.site, req.body);
  res.redirect(`/portal/${req.site.id}?saved=1`);
});
app.post('/portal/:siteId/upload', clientLimiter, loadPortalSite, (req, res) => {
  upload.single('image')(req, res, async (err) => {
    if (err) return res.status(400).json({ ok: false, error: err.message });
    if (!req.file) return res.status(400).json({ ok: false, error: 'No file received.' });
    await optimizeUpload(req.file);
    res.json({ ok: true, url: `/uploads/${req.file.filename}` });
  });
});
app.get('/portal/:siteId/report', clientLimiter, loadPortalSite, (req, res) => {
  res.render('report', {
    site: req.site, ...reportContext(req.site, req.query.days),
    base: `/portal/${req.site.id}/report`, backHref: `/portal/${req.site.id}`, owner: false,
    mailConfigured: false, reportEmail: '', flash: ''
  });
});

// ---- hosting billing (Stripe) ----
function billingRow(id) { return db.prepare('SELECT * FROM sites WHERE id = ?').get(id); }
const billingLabels = { none: 'Not started', active: 'Active', trialing: 'Trial', past_due: 'Payment failed', unpaid: 'Unpaid', canceled: 'Canceled', incomplete: 'Waiting for payment', incomplete_expired: 'Expired', paused: 'Paused' };
const billingMessages = {
  saved: 'Billing settings saved.', link: 'Payment link created.', sent: 'Payment link emailed.',
  sendfailed: 'Could not send the email. Check that email sending is set up (README, "Email alerts"), or copy the link and send it yourself.',
  notconfigured: 'Stripe is not set up yet. See the README, "Charging for hosting".', stripefail: 'Stripe returned an error. Check your keys and price ID.',
  bademail: 'That email address does not look right.', paid: 'Thank you! Payment received. The status below updates as soon as Stripe confirms it.',
  noportal: 'There is no Stripe customer for this site yet.'
};
app.get('/sites/:id/billing', requireAuth, loadOwnedSite, (req, res) => {
  const row = billingRow(req.site.id);
  res.render('billing', {
    site: req.site, row, label: billingLabels[row.billing_status] || row.billing_status,
    suspended: billing.isSuspended(row), graceDays: billing.GRACE_DAYS,
    configured: billing.isConfigured(), webhookReady: billing.webhookReady(), mailConfigured: mailer.isConfigured(),
    webhookUrl: `${req.protocol}://${req.get('host')}/stripe/webhook`,
    link: '', msgs: billingMessages,
    flash: billingMessages[req.query.m] ? req.query.m : ''
  });
});

app.post('/sites/:id/billing/settings', requireAuth, loadOwnedSite, (req, res) => {
  const email = String(req.body.billing_email || '').trim().slice(0, 200);
  if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.redirect(`/sites/${req.site.id}/billing?m=bademail`);
  db.prepare('UPDATE sites SET billing_required = ?, billing_email = ? WHERE id = ?').run(req.body.billing_required === '1' ? 1 : 0, email, req.site.id);
  res.redirect(`/sites/${req.site.id}/billing?m=saved`);
});

app.post('/sites/:id/billing/checkout', requireAuth, loadOwnedSite, async (req, res) => {
  if (!billing.isConfigured()) return res.redirect(`/sites/${req.site.id}/billing?m=notconfigured`);
  const row = billingRow(req.site.id);
  const to = String(req.body.billing_email || row.billing_email || '').trim();
  if (to && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(to)) return res.redirect(`/sites/${req.site.id}/billing?m=bademail`);
  if (to !== row.billing_email) db.prepare('UPDATE sites SET billing_email = ? WHERE id = ?').run(to, row.id);
  try {
    const origin = `${req.protocol}://${req.get('host')}`;
    const session = await billing.createCheckout({
      siteId: row.id, siteName: row.name, email: to,
      successUrl: `${origin}/billing/thanks`, cancelUrl: `${origin}/billing/thanks?canceled=1`
    });
    if (req.body.send === '1') {
      const ok = await mailer.sendPaymentLink({ to, siteName: row.name, link: session.url, replyTo: (db.prepare('SELECT email FROM users WHERE id = ?').get(req.session.userId) || {}).email });
      return res.redirect(`/sites/${row.id}/billing?m=${ok ? 'sent' : 'sendfailed'}`);
    }
    res.render('billing', {
      site: req.site, row: billingRow(row.id), label: billingLabels[row.billing_status] || row.billing_status,
      suspended: billing.isSuspended(row), graceDays: billing.GRACE_DAYS,
      configured: true, webhookReady: billing.webhookReady(), mailConfigured: mailer.isConfigured(),
      webhookUrl: `${origin}/stripe/webhook`, link: session.url, msgs: billingMessages, flash: 'link'
    });
  } catch (err) {
    console.error('stripe checkout failed:', err.message);
    res.redirect(`/sites/${row.id}/billing?m=stripefail`);
  }
});

app.post('/sites/:id/billing/portal', requireAuth, loadOwnedSite, async (req, res) => {
  const row = billingRow(req.site.id);
  if (!billing.isConfigured()) return res.redirect(`/sites/${row.id}/billing?m=notconfigured`);
  if (!row.stripe_customer_id) return res.redirect(`/sites/${row.id}/billing?m=noportal`);
  try {
    const portal = await billing.createPortal({ customer: row.stripe_customer_id, returnUrl: `${req.protocol}://${req.get('host')}/sites/${row.id}/billing` });
    res.redirect(portal.url);
  } catch (err) {
    console.error('stripe portal failed:', err.message);
    res.redirect(`/sites/${row.id}/billing?m=stripefail`);
  }
});

app.get('/billing/thanks', (req, res) => res.render('billing-thanks', { canceled: req.query.canceled === '1' }));

// ---- admin backup ----
// The admin is the account named in ADMIN_EMAIL, or (if unset) the first
// account ever created. The backup holds every user's data, so nobody else
// may download it.
function isAdmin(userId) {
  const user = db.prepare('SELECT id, email FROM users WHERE id = ?').get(userId);
  if (!user) return false;
  const adminEmail = (process.env.ADMIN_EMAIL || '').trim().toLowerCase();
  if (adminEmail) return user.email.toLowerCase() === adminEmail;
  return db.prepare('SELECT MIN(id) AS id FROM users').get().id === user.id;
}

app.get('/admin/backup', requireAuth, async (req, res) => {
  if (!isAdmin(req.session.userId)) return res.status(404).render('not-found');
  const tmp = path.join(os.tmpdir(), `sitegen-backup-${nanoid(10)}.db`);
  try {
    await db.backup(tmp); // a consistent snapshot, even while the app is in use
    res.attachment(`sitegen-backup-${new Date().toISOString().slice(0, 10)}.zip`);
    const zip = new ZipArchive({ zlib: { level: 9 } });
    const cleanup = () => fs.rm(tmp, { force: true }, () => {});
    res.on('close', cleanup);
    zip.on('error', (err) => { console.error('Backup failed:', err.message); res.end(); });
    zip.pipe(res);
    zip.file(tmp, { name: 'sitegen.db' });
    const uploadsDir = path.join(__dirname, 'public', 'uploads');
    for (const name of fs.readdirSync(uploadsDir)) {
      if (name.startsWith('.')) continue;
      const p = path.join(uploadsDir, name);
      if (fs.statSync(p).isFile()) zip.file(p, { name: `uploads/${name}` });
    }
    zip.append(
      'SiteGen backup\n\nTo restore: stop SiteGen, copy sitegen.db into the data folder (replacing data/sitegen.db),\n' +
      'copy the files in uploads/ into public/uploads/, then start SiteGen again.\n',
      { name: 'RESTORE.txt' }
    );
    await zip.finalize();
  } catch (err) {
    console.error('Backup failed:', err.message);
    fs.rm(tmp, { force: true }, () => {});
    if (!res.headersSent) res.status(500).send('Could not create the backup.');
  }
});

// ---- automatic HTTPS support (used by Caddy; see deploy/Caddyfile) ----
// Caddy asks this before getting a certificate for a domain, so strangers
// can't make the server request certificates for domains it doesn't host.
// Only answers the local Caddy itself: anything proxied from the internet
// carries an X-Forwarded-For header and is refused.
app.get('/internal/domain-check', (req, res) => {
  const addr = req.socket.remoteAddress || '';
  const isLocal = ['127.0.0.1', '::1', '::ffff:127.0.0.1'].includes(addr);
  if (!isLocal || req.headers['x-forwarded-for'] || req.headers['forwarded']) return res.status(404).end();
  const domain = String(req.query.domain || '').trim().toLowerCase();
  if (!isValidHostname(domain)) return res.status(404).end();
  const appDomain = (process.env.APP_DOMAIN || '').trim().toLowerCase();
  if (appDomain && domain === appDomain) return res.status(200).send('ok');
  const row = db.prepare('SELECT 1 FROM sites WHERE custom_domain = ? AND published = 1').get(domain);
  return row ? res.status(200).send('ok') : res.status(404).end();
});

app.post('/sites/:id/duplicate', requireAuth, loadOwnedSite, (req, res) => {
  const src = req.site;
  const asTpl = (req.body || {}).mode === 'template' || req.query.mode === 'template';
  const name = (asTpl ? `${src.name} (template copy)` : `${src.name} (copy)`).slice(0, 80);
  // a copy never inherits the live address, domain, client links or published state
  const sections = asTpl ? backups.asTemplate(src.sections) : src.sections;
  const info = db.prepare(
    'INSERT INTO sites (user_id, slug, name, theme, sections, layout, seo_title, seo_description) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
  ).run(
    req.session.userId, uniqueSlug(name), name,
    JSON.stringify(src.theme), JSON.stringify(sections), JSON.stringify(src.layout),
    src.seo_title || '', src.seo_description || ''
  );
  saveVersion(info.lastInsertRowid, src.theme, sections, src.layout, asTpl ? 'Copied as a template' : 'Duplicated');
  res.redirect(`/sites/${info.lastInsertRowid}/edit`);
});

// one site as a portable file, and bringing one back in (photos stay where they are: they are not inside the file)
app.get('/sites/:id/export.json', requireAuth, loadOwnedSite, (req, res) => {
  res.attachment(`${req.site.slug}.sitegen.json`);
  res.type('application/json').send(JSON.stringify(backups.exportSite(req.site), null, 2));
});
const siteFileUpload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 2 * 1024 * 1024, files: 1 } });
app.post('/sites/import-file', requireAuth, (req, res, next) => siteFileUpload.single('sitefile')(req, res, (err) => {
  if (err) return renderDashboard(req, res, { importError: 'That file is too large or could not be read.' });
  next();
}), (req, res) => {
  if (!req.file) return renderDashboard(req, res, { importError: 'Choose a site file (.json) first.' });
  const r = backups.parseSiteFile(req.file.buffer.toString('utf8'));
  if (r.error) return renderDashboard(req, res, { importError: r.error });
  const name = str(r.name, 80) || 'Imported site';
  const theme = { ...defaultTheme(), ...r.theme };
  theme.motionStyle = app.locals.motionLib.resolve(r.theme, r.sections && r.sections.hero);   // an older backup keeps the motion it had
  const sections = mergeSectionsWithDefaults(r.sections);
  const layout = JSON.stringify(safeParseLayout(JSON.stringify(r.layout)));
  const info = db.prepare(
    'INSERT INTO sites (user_id, slug, name, theme, sections, layout, seo_title, seo_description) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
  ).run(req.session.userId, uniqueSlug(name), name, JSON.stringify(theme), JSON.stringify(sections), layout, r.seo_title, r.seo_description);
  saveVersion(info.lastInsertRowid, theme, sections, JSON.parse(layout), 'Imported from file');
  res.redirect(`/sites/${info.lastInsertRowid}/edit`);
});

// ---- automatic backups (admin only) ----
const BACKUP_DIR = process.env.BACKUP_DIR || path.join(__dirname, 'data', 'backups');
const BACKUP_KEEP = Math.max(1, parseInt(process.env.BACKUP_KEEP, 10) || 14);
function requireAdmin(req, res, next) {
  if (!isAdmin(req.session.userId)) return res.status(404).render('not-found');
  next();
}
app.get('/admin/backups', requireAuth, requireAdmin, (req, res) => {
  res.render('admin-backups', { files: backups.list(BACKUP_DIR), keep: BACKUP_KEEP, done: req.query.done === '1', failed: req.query.failed === '1' });
});
app.post('/admin/backups/run', requireAuth, requireAdmin, async (req, res) => {
  try { await backups.run(db, BACKUP_DIR, BACKUP_KEEP); res.redirect('/admin/backups?done=1'); }
  catch (err) { console.error('Backup failed:', err.message); res.redirect('/admin/backups?failed=1'); }
});
app.get('/admin/backups/:name', requireAuth, requireAdmin, (req, res) => {
  const p = backups.pathFor(BACKUP_DIR, req.params.name);
  if (!p || !fs.existsSync(p)) return res.status(404).render('not-found');
  res.download(p, req.params.name);
});
async function autoBackup() {
  try { if (!backups.hasToday(BACKUP_DIR)) await backups.run(db, BACKUP_DIR, BACKUP_KEEP); }
  catch (err) { console.error('Automatic backup failed:', err.message); }
}
if (!isTestEnv && process.env.BACKUP_AUTO !== 'off') {
  setTimeout(autoBackup, 2 * 60 * 1000).unref();
  setInterval(autoBackup, 6 * 60 * 60 * 1000).unref();
}

// extra context the pre-launch audit needs (does this link's page exist, how big are the photos)
function checklistOpts(site) {
  return {
    uploadsDir: path.join(__dirname, 'public', 'uploads'),
    pageExists: (u) => {
      const parts = u.split('/').filter(Boolean);
      if (!parts.length) return true;
      const first = parts[0];
      if (first === 'book') return !!site.sections.booking.enabled;
      if (first === 'thank-you' || first === 'review') return true;
      if (legal.PAGES.includes(first)) return legal.enabled(site);
      if (first === 'estimate') return calc.isUsable(site.sections.calculator);
      if (parts.length === 1) return pageIsAvailable(site, first);
      return true; // service / area / post pages: not worth checking each one
    }
  };
}

// ---- block library: blocks saved once, reusable on any of the user's sites ----
const LIBRARY_MAX = 200;
function libraryRows(userId) {
  return db.prepare('SELECT id, name, block FROM block_library WHERE user_id = ? ORDER BY name COLLATE NOCASE, id').all(userId)
    .map(r => { try { return { id: r.id, name: r.name, block: JSON.parse(r.block) }; } catch { return null; } }).filter(Boolean);
}
// one block's fields as the editor sends them (block_type, block_heading, ...) -> a cleaned block, or null
function cleanSingleBlock(b) {
  const one = {};
  for (const k of ['type', 'heading', 'body', 'image', 'side', 'buttonText', 'buttonUrl', 'edge', 'bg', 'place', 'page']) one['block_' + k] = [Array.isArray(b['block_' + k]) ? b['block_' + k][0] : (b['block_' + k] || '')];
  return parseBlocksFromBody(one)[0] || null;
}
app.post('/library/blocks', requireAuth, (req, res) => {
  const blk = cleanSingleBlock(req.body || {});
  const name = str((req.body || {}).name, 60) || (blk && blk.heading) || '';
  if (!blk || !name) return res.status(400).json({ ok: false, error: 'Fill in the block before saving it.' });
  const n = db.prepare('SELECT COUNT(*) AS n FROM block_library WHERE user_id = ?').get(req.session.userId).n;
  if (n >= LIBRARY_MAX) return res.status(400).json({ ok: false, error: 'Your library is full. Delete a few saved blocks first.' });
  const info = db.prepare('INSERT INTO block_library (user_id, name, block) VALUES (?, ?, ?)').run(req.session.userId, name, JSON.stringify(blk));
  res.json({ ok: true, id: info.lastInsertRowid, name, block: blk });
});
app.post('/library/blocks/:id/delete', requireAuth, (req, res) => {
  const info = db.prepare('DELETE FROM block_library WHERE id = ? AND user_id = ?').run(req.params.id, req.session.userId);
  res.json({ ok: !!info.changes });
});

app.get('/sites/:id/checklist', requireAuth, loadOwnedSite, (req, res) => {
  res.json({ items: buildChecklist(req.site, checklistOpts(req.site)) });
});

// ---- static export ----
// Renders every available page to plain HTML (links rewritten to about.html
// etc., uploaded photos bundled in an uploads/ folder) and zips it, so a
// finished site can be hosted anywhere or handed to the client. The contact
// form is omitted because it needs this server to receive messages.
function renderToString(view, locals) {
  return new Promise((resolve, reject) => {
    app.render(view, locals, (err, html) => (err ? reject(err) : resolve(html)));
  });
}

// Builds the static copy of a site and writes it as a zip to `out`.
// hosted: true is used when publishing to a static host (Netlify): the contact form is kept and handled by the
// host's own form service, the thank-you page and a 404 page are added.
async function writeExportZip(site, out, { hosted = false } = {}) {
    const keys = PAGE_KEYS.filter(k => pageIsAvailable(site, k));
    const trustData = site.sections.trust || {};
    const services = servicesWithSlugs(site.sections.services.items);
    const areas = areasWithSlugs(trustData.serviceAreas, trustData.areaText);
    const posts = servicesWithSlugs(site.sections.blog.items);
    const extras = extraPageList(site);
    // every extra page type gets its own file, but only once it has real text
    const itemPages = [];
    if (keys.includes('services')) for (const sv of services) if (sv.detail) itemPages.push({ page: 'service', item: sv, href: `/services/${sv.slug}`, file: `service-${sv.slug}.html` });
    for (const ar of areas) if (ar.text) itemPages.push({ page: 'area', item: ar, href: `/areas/${ar.slug}`, file: `area-${ar.slug}.html` });
    if (keys.includes('blog')) for (const po of posts) itemPages.push({ page: 'post', item: po, href: `/blog/${po.slug}`, file: `blog-${po.slug}.html` });
    for (const ex of extras) itemPages.push({ page: 'extra', item: ex, href: `/p/${ex.slug}`, file: `p-${ex.slug}.html` });
    const legalPages = legal.enabled(site) ? legal.PAGES.map(k => ({ page: k, file: `${k}.html` })) : [];
    const pages = [{ page: 'home', file: 'index.html' }, ...keys.map(k => ({ page: k, file: `${k}.html` })), ...legalPages, ...itemPages];
    const formsOn = hosted && !!site.sections.contact.acceptSubmissions;
    if (formsOn) pages.push({ page: 'thank-you', file: 'thank-you.html' });
    if (hosted) pages.push({ page: 'notfound', file: '404.html' });
    const uploads = new Set();
    const assets = new Set();
    const files = [];
    for (const entry of pages) {
      const locals = {
        site: extraThemes.withPageStyle(site, entry.page), preview: false, page: entry.page, basePath: '', origin: '', staticExport: true, netlifyForms: formsOn, services, areas, posts, extras,
        service: entry.page === 'service' ? entry.item : null, area: entry.page === 'area' ? entry.item : null,
        post: entry.page === 'post' ? entry.item : null, extra: entry.page === 'extra' ? entry.item : null,
        navPages: buildNavPages(site, '', false), contactSent: false, contactError: false, reviewThanks: false, reviewError: false
      };
      let html = images.optimizeHtml(await renderToString('public-site', locals));
      // page links: "/about" -> "about.html", "/" -> "index.html"
      for (const k of [...keys, ...legalPages.map(x => x.page)]) html = html.split(`href="/${k}"`).join(`href="${k}.html"`);
      // item pages that were not exported (no text yet) fall back to their list page
      const fallback = { '/services/': 'services.html', '/areas/': 'index.html', '/blog/': keys.includes('blog') ? 'blog.html' : 'index.html', '/p/': 'index.html' };
      html = html.replace(/href="(\/(?:services|areas|blog|p)\/)([a-z0-9-]+)"/g, (m, prefix, slug) => {
        const hit = itemPages.find(ip => ip.href === prefix + slug);
        return `href="${hit ? hit.file : fallback[prefix]}"`;
      });
      html = html.split('href="/"').join('href="index.html"');
      // no real canonical URL is known until it is hosted
      html = html.replace(/\s*<link rel="canonical"[^>]*>/, '').replace(/\s*<meta property="og:url"[^>]*>/, '')
        .replace(/,"url":"[^"]*"/, '');
      // the animation script and the Motion library are bundled too, so the site never loads code from elsewhere
      if (html.includes('vendor/motion.js')) assets.add('vendor/motion.js').add('sitegen-motion.js');
      // uploaded photos become relative paths and get bundled
      html = html.replace(/(["'(]|, )\/uploads\/([A-Za-z0-9._-]+)/g, (m, q, name) => {
        uploads.add(name);
        return `${q}uploads/${name}`;
      });
      files.push({ name: entry.file, html });
    }

    const zip = new ZipArchive({ zlib: { level: 9 } });
    const done = new Promise((resolve, reject) => { zip.on('error', reject); out.on('finish', resolve); out.on('close', resolve); out.on('error', reject); });
    zip.pipe(out);
    for (const f of files) zip.append(f.html, { name: f.name });
    for (const rel of assets) zip.file(path.join(__dirname, 'public', rel), { name: rel });
    for (const name of uploads) {
      const p = path.join(__dirname, 'public', 'uploads', name);
      if (fs.existsSync(p)) zip.file(p, { name: `uploads/${name}` });
    }
    if (!hosted) zip.append(
      `${site.name}\n\nThis folder is a complete, static copy of the website.\n` +
      `To publish it, upload everything in this folder to any web host (keep the uploads folder next to the .html files) and open index.html.\n\n` +
      `Note: the contact form is not included in this copy because it needs a server to receive messages. ` +
      `The phone number, email address and map are still shown.\n`,
      { name: 'README.txt' }
    );
    await zip.finalize();
    await done;
}

app.get('/sites/:id/export', requireAuth, loadOwnedSite, async (req, res) => {
  const site = req.site;
  try {
    res.attachment(`${site.slug}-website.zip`);
    await writeExportZip(site, res);
  } catch (err) {
    console.error('Export failed:', err.message);
    if (!res.headersSent) res.status(500).send('Could not export this site.'); else res.end();
  }
});

// ---- publish to Netlify (one click), custom domain and HTTPS ----
const publishLimiter = rateLimit({
  windowMs: 10 * 60 * 1000, limit: 12, standardHeaders: true, legacyHeaders: false, skip: () => isTestEnv,
  message: 'Too many publishes in a short time. Please wait a few minutes.'
});
async function exportToBuffer(site, opts) {
  const { PassThrough } = require('node:stream');
  const sink = new PassThrough(); const chunks = [];
  sink.on('data', c => chunks.push(c));
  await writeExportZip(site, sink, opts);
  return Buffer.concat(chunks);
}
const hostingNotifyEmail = (site) => [site.sections.contact.notifyEmail, site.sections.contact.email].map(e => str(e, 254)).find(e => e && isValidEmail(e)) || (db.prepare('SELECT email FROM users WHERE id = ?').get(site.user_id) || {}).email || '';
const hostingMsg = { published: 'Published. Your site is live.', pending: 'Sent to Netlify. It is still processing; refresh in a minute.', domain: 'Domain saved. Now add the DNS records below at your domain provider.', ssl: 'HTTPS requested. If the DNS records are in place, Netlify issues the certificate within a few minutes.', sslwait: 'Netlify cannot issue HTTPS yet. The DNS records usually need a little time (sometimes a few hours) to spread. Try again later.', unlinked: 'Disconnected. The Netlify site itself is untouched.', nodomain: 'That does not look like a domain name. Use something like www.yourbusiness.com.', nosite: 'Publish the site first.' };

app.get('/sites/:id/hosting', requireAuth, loadOwnedSite, async (req, res) => {
  const site = req.site; let live = null;
  if (site.netlify_site_id && netlify.isConfigured() && req.query.refresh !== '0') { try { live = await netlify.getSite(site.netlify_site_id); } catch { /* shown from saved values */ } }
  const sub = site.netlify_name || '';
  res.render('hosting', {
    site, configured: netlify.isConfigured(), live,
    dns: site.netlify_domain && sub ? netlify.dnsInstructions(site.netlify_domain, sub) : [],
    flash: req.query.f || '', err: req.query.err ? String(req.query.err).slice(0, 300) : '',
    msgs: hostingMsg, formsOn: !!site.sections.contact.acceptSubmissions, notify: hostingNotifyEmail(site),
    hasBooking: !!site.sections.booking.enabled, hasChat: !!(site.sections.chat && site.sections.chat.enabled), hasCalc: !!(site.sections.calculator && site.sections.calculator.enabled)
  });
});

app.post('/sites/:id/hosting/publish', requireAuth, loadOwnedSite, publishLimiter, async (req, res) => {
  const site = req.site; const back = (q) => res.redirect(`/sites/${site.id}/hosting?${q}`);
  if (netlify.isConfigured() && await qualityGate(req, res, 'hosting')) return;
  if (!netlify.isConfigured()) return back('err=' + encodeURIComponent('Netlify is not connected yet. Add NETLIFY_AUTH_TOKEN to the .env file.'));
  try {
    const zipBuf = await exportToBuffer(site, { hosted: true });
    let siteId = site.netlify_site_id, created = false;
    if (!siteId) {
      const ns = await netlify.createSite(site.slug);
      siteId = ns.id; created = true;
      db.prepare('UPDATE sites SET netlify_site_id = ?, netlify_name = ?, netlify_url = ? WHERE id = ?').run(ns.id, ns.name, ns.url, site.id);
    }
    const dep = await netlify.deployZip(siteId, zipBuf);
    const waited = dep.id ? await netlify.waitForDeploy(dep.id) : { ok: true };
    if (!waited.ok && !waited.pending) return back('err=' + encodeURIComponent(waited.error || 'Netlify could not process the files.'));
    db.prepare("UPDATE sites SET netlify_deployed_at = datetime('now') WHERE id = ?").run(site.id);
    recordPublish(site, 'netlify', dep.id);
    if (created && site.sections.contact.acceptSubmissions) { // contact form messages are emailed to the owner by Netlify
      const to = hostingNotifyEmail(site);
      if (to) { try { await netlify.createFormEmailHook(siteId, 'contact', to); } catch (e) { console.error('Netlify form email hook failed:', e.message); } }
    }
    back('f=' + (waited.pending ? 'pending' : 'published'));
  } catch (err) {
    console.error('Netlify publish failed:', err.message);
    back('err=' + encodeURIComponent(err.message));
  }
});

app.post('/sites/:id/hosting/domain', requireAuth, loadOwnedSite, async (req, res) => {
  const site = req.site; const back = (q) => res.redirect(`/sites/${site.id}/hosting?${q}`);
  if (!site.netlify_site_id) return back('f=nosite');
  const domain = netlify.cleanDomain(req.body.domain);
  if (!domain) return back('f=nodomain');
  try {
    await netlify.setCustomDomain(site.netlify_site_id, domain);
    db.prepare('UPDATE sites SET netlify_domain = ?, netlify_ssl = 0 WHERE id = ?').run(domain, site.id);
    back('f=domain');
  } catch (err) { back('err=' + encodeURIComponent(err.message)); }
});

app.post('/sites/:id/hosting/ssl', requireAuth, loadOwnedSite, async (req, res) => {
  const site = req.site; const back = (q) => res.redirect(`/sites/${site.id}/hosting?${q}`);
  if (!site.netlify_site_id || !site.netlify_domain) return back('f=nosite');
  try {
    await netlify.provisionSsl(site.netlify_site_id);
    db.prepare('UPDATE sites SET netlify_ssl = 1 WHERE id = ?').run(site.id);
    back('f=ssl');
  } catch (err) {
    if (err instanceof netlify.NetlifyError && err.status >= 400 && err.status < 500 && err.status !== 401 && err.status !== 429) return back('f=sslwait');
    back('err=' + encodeURIComponent(err.message));
  }
});

app.post('/sites/:id/hosting/remove-domain', requireAuth, loadOwnedSite, async (req, res) => {
  const site = req.site; const back = (q) => res.redirect(`/sites/${site.id}/hosting?${q}`);
  if (!site.netlify_site_id) return back('f=nosite');
  try {
    await netlify.clearCustomDomain(site.netlify_site_id);
    db.prepare("UPDATE sites SET netlify_domain = '', netlify_ssl = 0 WHERE id = ?").run(site.id);
    back('f=unlinked');
  } catch (err) { back('err=' + encodeURIComponent(err.message)); }
});

app.post('/sites/:id/hosting/unlink', requireAuth, loadOwnedSite, (req, res) => {
  db.prepare("UPDATE sites SET netlify_site_id = '', netlify_name = '', netlify_url = '', netlify_domain = '', netlify_deployed_at = '', netlify_ssl = 0 WHERE id = ?").run(req.site.id);
  res.redirect(`/sites/${req.site.id}/hosting?f=unlinked`);
});

// ---- payments hub: payment requests (quotes, invoices), history, manual "paid" ----
const PAY_FLASH = { created: 'Payment request created. Send the link to your customer.', sent: 'Emailed the payment link.', paid: 'Marked as paid.', canceled: 'Payment request canceled.', nokey: 'Add your Stripe key and switch on card payments first (Card payments block in the editor).', bad: 'Please enter an amount (for example 250 or 250.00) and what it is for.', nomail: 'Email sending is not set up, or this customer has no email. Copy the link and send it yourself.' };
app.get('/sites/:id/payments', requireAuth, loadOwnedSite, async (req, res) => {
  const site = req.site;
  const pending = db.prepare("SELECT * FROM payments WHERE site_id = ? AND status = 'pending' AND stripe_session_id != '' ORDER BY id DESC LIMIT 20").all(site.id);
  for (const p of pending) await refreshPayment(site, p);
  const rows = db.prepare('SELECT * FROM payments WHERE site_id = ? ORDER BY id DESC LIMIT 200').all(site.id).map(p => ({ ...p, amount: payments.money(p.amount_cents, p.currency), link: `${payBase(req, site)}/pay/${p.token}` }));
  const cur = site.sections.payments.currency;
  const sum = (st) => payments.money(rows.filter(p => p.status === st && p.currency === cur).reduce((n, p) => n + p.amount_cents, 0), cur);
  let lead = null;
  if (req.query.lead) { const l = db.prepare('SELECT id, name, email, service FROM contact_submissions WHERE id = ? AND site_id = ?').get(req.query.lead, site.id); if (l) lead = l; }
  res.render('payments', { site, rows, ready: payReady(site, site), cfg: site.sections.payments, flash: req.query.f || '', msgs: PAY_FLASH, collected: sum('paid'), outstanding: sum('pending'), lead, mailOn: mailer.isConfigured() });
});
app.post('/sites/:id/payments/new', requireAuth, loadOwnedSite, async (req, res) => {
  const site = req.site; const back = (f) => res.redirect(`/sites/${site.id}/payments?f=${f}`);
  if (!payReady(site, site)) return back('nokey');
  const cents = payments.toCents(req.body.amount); const desc = str(req.body.description, 200);
  if (!cents || !desc) return back('bad');
  const email = isValidEmail(req.body.email || '') ? str(req.body.email, 254) : '';
  const lead = req.body.lead_id ? db.prepare('SELECT id FROM contact_submissions WHERE id = ? AND site_id = ?').get(req.body.lead_id, site.id) : null;
  const p = newPayment(site, { kind: 'invoice', refId: lead ? lead.id : null, description: desc, amountCents: cents, name: str(req.body.name, 100), email, currency: site.sections.payments.currency });
  if (req.body.send === '1' && email && mailer.isConfigured()) {
    mailer.sendReport({ to: email, replyTo: ownerEmailFor(site) || undefined, subject: `${site.name}: payment request for ${payments.money(cents, p.currency)}`,
      text: `Hello${p.customer_name ? ' ' + p.customer_name : ''},\n\n${site.name} has sent you a payment request:\n\n${desc}\nAmount: ${payments.money(cents, p.currency)}\n\nPay securely online here:\n${payBase(req, site)}/pay/${p.token}\n\nThank you!` }).catch(e => console.error('Payment request email failed:', e.message));
    return back('sent');
  }
  back('created');
});
app.post('/sites/:id/payments/:pid/:action', requireAuth, loadOwnedSite, async (req, res) => {
  const site = req.site; const back = (f) => res.redirect(`/sites/${site.id}/payments?f=${f}`);
  const p = db.prepare('SELECT * FROM payments WHERE id = ? AND site_id = ?').get(req.params.pid, site.id);
  if (!p) return back('bad');
  if (req.params.action === 'cancel' && p.status === 'pending' && p.kind !== 'deposit') {
    db.prepare("UPDATE payments SET status = 'canceled' WHERE id = ?").run(p.id); return back('canceled');
  }
  if (req.params.action === 'paid' && p.status === 'pending' && p.kind !== 'deposit') { markPaid(site, p, null, 'manual', req); return back('paid'); }
  if (req.params.action === 'resend' && p.status === 'pending' && p.customer_email && mailer.isConfigured()) {
    mailer.sendReport({ to: p.customer_email, replyTo: ownerEmailFor(site) || undefined, subject: `${site.name}: payment request for ${payments.money(p.amount_cents, p.currency)}`,
      text: `Hello,\n\nReminder of your payment request from ${site.name}:\n\n${p.description}\nAmount: ${payments.money(p.amount_cents, p.currency)}\n\nPay securely online here:\n${payBase(req, site)}/pay/${p.token}\n\nThank you!` }).catch(e => console.error('Payment reminder failed:', e.message));
    return back('sent');
  }
  back(req.params.action === 'resend' ? 'nomail' : 'bad');
});

// pull the Google rating and reviews now (also happens by itself once a day)
app.post('/sites/:id/google-reviews/refresh', requireAuth, loadOwnedSite, async (req, res) => {
  const placeId = googleReviews.cleanPlaceId((req.site.sections.testimonials || {}).googlePlaceId);
  if (!placeId) return res.redirect(`/sites/${req.site.id}/edit?google=noid`);
  const r = await googleReviews.refresh(db, req.site.id, placeId);
  cache.clear();
  res.redirect(`/sites/${req.site.id}/edit?google=${r.data ? 'ok' : 'fail'}`);
});

// ---- client questionnaire ----
// The owner makes a link per client. The client fills in a friendly form (no account). The owner reviews
// the answers and builds the site from them with one button: only what the client wrote goes on the site.
const intakeLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, limit: 12, standardHeaders: true, legacyHeaders: false, skip: () => isTestEnv,
  message: 'Too many submissions from this device. Please try again later.'
});
const intakeUploadLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, limit: 40, standardHeaders: true, legacyHeaders: false, skip: () => isTestEnv,
  handler: (req, res) => res.status(429).json({ ok: false, error: 'Too many uploads. Please try again later.' })
});
function loadIntakeLink(req, res, next) {
  res.set({ 'Referrer-Policy': 'no-referrer', 'X-Robots-Tag': 'noindex, nofollow' });
  const token = String(req.params.token || '');
  const link = /^[A-Za-z0-9_-]{16,64}$/.test(token) ? db.prepare('SELECT * FROM intake_links WHERE token = ?').get(token) : null;
  if (!link || link.closed) return res.status(404).render('start', { mode: 'closed', link: null, token: '', errors: [], d: {}, owner: '' });
  req.intakeLink = link;
  req.intakeOwner = db.prepare('SELECT email FROM users WHERE id = ?').get(link.user_id);
  next();
}
const startView = (req, extra) => ({ mode: 'form', link: req.intakeLink, token: req.params.token, errors: [], d: {}, owner: '', ...extra });

app.get('/start/:token', loadIntakeLink, (req, res) => res.render('start', startView(req, {})));

app.post('/start/:token/upload', intakeUploadLimiter, loadIntakeLink, (req, res) => {
  upload.single('image')(req, res, async (err) => {
    if (err) return res.status(400).json({ ok: false, error: err.message });
    if (!req.file) return res.status(400).json({ ok: false, error: 'No file received.' });
    await optimizeUpload(req.file);
    res.json({ ok: true, url: `/uploads/${req.file.filename}` });
  });
});

app.post('/start/:token', intakeLimiter, loadIntakeLink, (req, res) => {
  const b = req.body || {};
  if (b.website) return res.redirect(`/start/${req.params.token}/done`); // honeypot
  const d = intake.clean(b);
  const errors = intake.problems(d);
  if (errors.length) return res.status(400).render('start', startView(req, { errors, d: b }));
  const info = db.prepare('INSERT INTO intake_submissions (link_id, user_id, data) VALUES (?, ?, ?)').run(req.intakeLink.id, req.intakeLink.user_id, JSON.stringify(d));
  if (mailer.isConfigured() && req.intakeOwner) {
    mailer.sendReport({
      to: req.intakeOwner.email, replyTo: d.contactEmail,
      subject: `New client questionnaire: ${d.bizName}`,
      text: `${d.contactName} filled in the questionnaire for ${d.bizName} (${d.bizType}).\n\nReview it and build the site: ${req.protocol}://${req.get('host')}/intake/submissions/${info.lastInsertRowid}\n\nReply to this email to reach ${d.contactName} (${d.contactEmail}${d.contactPhone ? ', ' + d.contactPhone : ''}).\n`
    }).catch(e => console.error('Questionnaire email failed:', e.message));
  }
  res.redirect(`/start/${req.params.token}/done`);
});
app.get('/start/:token/done', loadIntakeLink, (req, res) => res.render('start', startView(req, { mode: 'done' })));

// owner side
const intakeBase = (req) => `${req.protocol}://${req.get('host')}/start/`;
app.get('/intake', requireAuth, (req, res) => {
  const links = db.prepare(`SELECT l.*, (SELECT COUNT(*) FROM intake_submissions s WHERE s.link_id = l.id) AS n FROM intake_links l WHERE l.user_id = ? ORDER BY l.id DESC`).all(req.session.userId);
  const subs = db.prepare('SELECT s.id, s.status, s.site_id, s.created_at, s.data, l.label FROM intake_submissions s JOIN intake_links l ON l.id = s.link_id WHERE s.user_id = ? ORDER BY s.id DESC LIMIT 100').all(req.session.userId)
    .map(r => { let d = {}; try { d = JSON.parse(r.data); } catch { /* */ } return { ...r, d }; });
  res.render('intake', { links, subs, base: intakeBase(req), flash: req.query.f || '' });
});
app.post('/intake/links', requireAuth, (req, res) => {
  const n = db.prepare('SELECT COUNT(*) AS n FROM intake_links WHERE user_id = ?').get(req.session.userId).n;
  if (n >= 100) return res.redirect('/intake?f=toomany');
  db.prepare('INSERT INTO intake_links (user_id, token, label) VALUES (?, ?, ?)').run(req.session.userId, nanoid(24), str(req.body.label, 80));
  res.redirect('/intake?f=created');
});
app.post('/intake/links/:id/toggle', requireAuth, (req, res) => {
  db.prepare('UPDATE intake_links SET closed = 1 - closed WHERE id = ? AND user_id = ?').run(req.params.id, req.session.userId);
  res.redirect('/intake');
});
app.post('/intake/links/:id/delete', requireAuth, (req, res) => {
  const l = db.prepare('SELECT id FROM intake_links WHERE id = ? AND user_id = ?').get(req.params.id, req.session.userId);
  if (l && !db.prepare('SELECT 1 FROM intake_submissions WHERE link_id = ?').get(l.id)) db.prepare('DELETE FROM intake_links WHERE id = ?').run(l.id);
  res.redirect('/intake');
});
function loadSubmission(req, res, next) {
  const row = db.prepare('SELECT * FROM intake_submissions WHERE id = ? AND user_id = ?').get(req.params.id, req.session.userId);
  if (!row) return res.status(404).render('not-found');
  try { row.d = JSON.parse(row.data); } catch { row.d = {}; }
  try { row.todoList = JSON.parse(row.todo); } catch { row.todoList = []; }
  req.submission = row;
  next();
}
app.get('/intake/submissions/:id', requireAuth, loadSubmission, (req, res) => {
  const s = req.submission;
  res.render('intake-view', { s, d: s.d, claims: intake.claimsToCheck(s.d), todo: s.status === 'built' ? s.todoList : intake.todoList(s.d), site: s.site_id ? getSite(s.site_id) : null, designChoices: s.site_id ? null : designOptionsLib.designOptions(s.d), error: req.query.error || '' });
});
app.post('/intake/submissions/:id/delete', requireAuth, loadSubmission, (req, res) => {
  db.prepare('DELETE FROM intake_submissions WHERE id = ?').run(req.submission.id);
  res.redirect('/intake');
});
app.post('/intake/submissions/:id/build', requireAuth, loadSubmission, generateLimiter, async (req, res) => {
  const s = req.submission;
  if (s.site_id && getSite(s.site_id)) return res.redirect(`/sites/${s.site_id}/edit`);
  try {
    const d = s.d;
    const { tpl, filled, theme, sections } = await baseSiteFromTemplate(d.bizType, d.bizName);
    const name = d.bizName;
    applyIntake(intake.toGenerateBody(d), theme, sections);
    if (d.mood) theme.style = d.mood;
    // the owner's pick from the suggested design options (recomputed here, never trusted from the browser)
    const pickIdx = /^[0-2]$/.test(String(req.body.option || '')) ? parseInt(req.body.option, 10) : -1;
    if (pickIdx >= 0) designOptionsLib.applyOption(theme, designOptionsLib.designOptions(d).options[pickIdx]);
    if (d.logo) theme.logoUrl = d.logo;
    sections.meta.businessType = d.bizType;
    // Facts-only wording: the AI may rephrase what the client told us and nothing else; anything it (or the
    // template) says that the client did not support is then replaced or removed (see grounding.js).
    const facts = grounding.buildFacts(d);
    facts.design = designBrief.copyBrief(d.bizType, theme.style);
    let aiCopy = await generateGroundedCopy(facts);
    if (aiCopy) {
      const probs = grounding.checkCopy(aiCopy, facts);
      if (probs.length) {
        const retry = await generateGroundedCopy(facts, { feedback: [...new Set(probs.map(p => p.reason))].slice(0, 6).join('; ') });
        if (retry) aiCopy = retry;
      }
      if (aiCopy.hero.headline) sections.hero.headline = aiCopy.hero.headline;
      if (aiCopy.hero.subheadline) sections.hero.subheadline = aiCopy.hero.subheadline;
      if (aiCopy.hero.ctaText) sections.hero.ctaText = aiCopy.hero.ctaText;
      if (aiCopy.about) sections.about.body = aiCopy.about;
      if (aiCopy.services.length) sections.services.items = aiCopy.services;
      if (aiCopy.seoTitle) sections.seo.title = aiCopy.seoTitle;
      if (aiCopy.seoDescription) sections.seo.description = aiCopy.seoDescription;
    }
    // the client's own words always win over the AI
    if (d.tagline) sections.hero.subheadline = d.tagline;
    if (d.about) sections.about.body = d.about;
    if (d.services.length) sections.services.items = d.services.map(x => ({ title: x.name, description: [x.price, x.desc].filter(Boolean).join(' · ') }));
    // what sets them apart becomes the "Why choose us" cards, in the client's words
    if (facts.diffs.length) sections.whyChoose = { ...sections.whyChoose, items: facts.diffs.slice(0, 6).map(x => (x.length <= 80 ? { icon: 'check', title: x, text: '' } : { icon: 'check', title: x.split(/[.,;:]/)[0].slice(0, 80), text: x.slice(0, 160) })) };
    else sections.whyChoose = { ...sections.whyChoose, items: [] };
    sections.faq.items = d.faq.map(x => ({ question: x.q, answer: x.a }));
    // photos: the client's own first; stock only if they agreed to it
    if (d.photos.length) {
      sections.hero.imageUrl = d.photos[0];
      sections.about.imageUrl = d.photos[1] || sections.about.imageUrl;
      sections.gallery.images = d.photos.slice(1);
    } else if (!d.stockOk) {
      sections.hero.imageUrl = ''; sections.about.imageUrl = ''; sections.gallery.images = [];
      sections.blocks.items = (sections.blocks.items || []).map(b => ({ ...b, imageUrl: '' }));
    }
    // safe extras: the contact form, privacy pages, and the chat assistant only if asked for
    sections.contact.acceptSubmissions = true;
    sections.legal = { ...sections.legal, enabled: true, ownerName: name, email: d.email || '' };
    if (d.features.includes('chat')) sections.chat = { ...sections.chat, enabled: true };
    sections.seo.title = `${name} | ${d.bizType}${sections.meta.city ? ' in ' + sections.meta.city : ''}`.slice(0, 70);
    if (!aiCopy || d.tagline) sections.seo.description = (d.tagline || sections.hero.subheadline || '').slice(0, 160);
    const scrub = grounding.scrubSections(sections, facts);
    const slug = uniqueSlug(name);
    const layout = defaultLayout();
    if (scrub.hideFaq && !layout.hidden.includes('faq')) layout.hidden.push('faq');
    const info = db.prepare('INSERT INTO sites (user_id, slug, name, theme, sections, layout, seo_title, seo_description) VALUES (?, ?, ?, ?, ?, ?, ?, ?)')
      .run(req.session.userId, slug, name, JSON.stringify(theme), JSON.stringify(sections), JSON.stringify(layout), sections.seo.title, sections.seo.description);
    saveVersion(info.lastInsertRowid, theme, sections, layout, 'Built from client questionnaire');
    db.prepare("UPDATE intake_submissions SET status = 'built', site_id = ?, todo = ? WHERE id = ?").run(info.lastInsertRowid, JSON.stringify(intake.todoList(d).concat(scrub.notes.length ? [`Wording the client did not support was replaced or removed (${scrub.notes.join(', ')}). Add real details if you want those parts back.`] : [])), s.id);
    void tpl; void filled;
    res.redirect(`/sites/${info.lastInsertRowid}/edit?generated=${aiCopy ? 'ai' : '1'}&fromintake=1`);
  } catch (err) {
    console.error('Build from questionnaire failed:', err.message);
    res.redirect(`/intake/submissions/${s.id}?error=1`);
  }
});

app.post('/sites/:id/delete', requireAuth, (req, res) => {
  const site = db.prepare('SELECT * FROM sites WHERE id = ? AND user_id = ?').get(req.params.id, req.session.userId);
  if (site) {
    db.prepare('DELETE FROM site_versions WHERE site_id = ?').run(site.id);
    db.prepare('DELETE FROM site_members WHERE site_id = ?').run(site.id);
    db.prepare('DELETE FROM publish_history WHERE site_id = ?').run(site.id);
    db.prepare('DELETE FROM client_users WHERE site_id = ?').run(site.id);
    db.prepare('DELETE FROM client_links WHERE site_id = ?').run(site.id);
    db.prepare('DELETE FROM sites WHERE id = ?').run(site.id);
    invalidateSiteCache(site);
  }
  res.redirect('/dashboard');
});

// ---- site builder ----
function loadOwnedSite(req, res, next) {
  const site = getSite(req.params.id);
  if (!site || site.user_id !== req.session.userId) {
    return res.status(404).send('Site not found');
  }
  req.site = site;
  next();
}

app.get('/sites/:id/edit', requireAuth, loadOwnedSite, (req, res) => {
  const versions = db.prepare(
    'SELECT id, label, created_at FROM site_versions WHERE site_id = ? ORDER BY id DESC LIMIT 10'
  ).all(req.site.id);
  const leadCount = db.prepare('SELECT COUNT(*) AS n FROM contact_submissions WHERE site_id = ?').get(req.site.id).n;
  const pendingReviews = db.prepare("SELECT COUNT(*) AS n FROM review_submissions WHERE site_id = ? AND status = 'pending'").get(req.site.id).n;
  const pendingBookings = db.prepare("SELECT COUNT(*) AS n FROM bookings WHERE site_id = ? AND status = 'pending'").get(req.site.id).n;
  let newClientLink = '';
  if (req.query.clientlink === '1' && req.session.newClientLink) {
    newClientLink = req.session.newClientLink;
    delete req.session.newClientLink; // show it once only
  }
  let newInvite = null;
  if (req.query.clientuser === 'invited' && req.session.newInvite) { newInvite = req.session.newInvite; delete req.session.newInvite; }
  // Use the saved business type; if there is none (older sites, or a site made another way), guess from its name, headline and services
  let adviceTpl = findTemplate((req.site.sections.meta && req.site.sections.meta.businessType) || '');
  if (adviceTpl.id === 'generic' && !((req.site.sections.meta && req.site.sections.meta.businessType) || '').trim()) {
    const sc = req.site.sections || {};
    const guess = [req.site.name, sc.hero && sc.hero.headline, sc.about && sc.about.heading, ...((sc.services && sc.services.items) || []).map(x => x && x.title)].filter(Boolean).join(' ');
    const g = findTemplate(guess);
    if (g && g.id !== 'generic') adviceTpl = g;
  }
  res.render('editor', {
    indFlash: str(req.query.ind, 12),
    designAdvice: adviceTpl && adviceTpl.id !== 'generic' ? industryDesign.industryDesign(adviceTpl.id) : null,
    motionSuggest: adviceTpl && adviceTpl.id !== 'generic' ? app.locals.motionLib.suggest({ templateId: adviceTpl.id, style: req.site.theme.style, advice: industryDesign.industryDesign(adviceTpl.id) }) : '',
    site: req.site,
    versions,
    leadCount,
    pendingReviews,
    pendingBookings,
    bookingFlash: req.query.booking === '1',
    mailConfigured: mailer.isConfigured(),
    checklist: buildChecklist(req.site, checklistOpts(req.site)),
    library: libraryRows(req.session.userId),
    saved: req.query.saved === '1',
    imported: req.query.imported === '1',
    refreshed: req.query.refreshed === '1',
    generated: req.query.generated === '1' || req.query.generated === 'ai',
    generatedByAi: req.query.generated === 'ai',
    fromIntake: req.query.fromintake === '1',
    aiConfigured: hasAiProvider(),
    rewrite: req.query.rewrite || '',
    clientLinkInfo: db.prepare('SELECT created_at, last_used_at FROM client_links WHERE site_id = ?').get(req.site.id) || null,
    newClientLink,
    clientLinkFlash: req.query.clientlink || '',
    clientUsers: db.prepare('SELECT id, email, name, password_hash != \'\' AS active, invite_expires, last_login_at FROM client_users WHERE site_id = ? ORDER BY id').all(req.site.id),
    newInvite,
    clientUserFlash: req.query.clientuser || '',
    googleFlash: req.query.google || '',
    googleCache: googleReviews.row(db, req.site.id) || null,
    googleConfigured: googleReviews.isConfigured()
  });
});

app.post('/sites/:id/edit', requireAuth, loadOwnedSite, (req, res) => {
  const b = req.body;
  const sections = parseSectionsFromBody(b);
  const theme = parseThemeFromBody(b);
  const layout = parseLayoutFromBody(b);
  const name = str(b.name, 80) || req.site.name;
  const customDomain = str(b.custom_domain, 253);

  if (customDomain && !isValidHostname(customDomain)) {
    if (wantsJson(req)) return res.status(400).json({ ok: false, error: 'That doesn\'t look like a valid domain (e.g. www.example.com).' });
    return res.redirect(`/sites/${req.site.id}/edit`);
  }

  saveVersion(req.site.id, req.site.theme, req.site.sections, req.site.layout);

  db.prepare(
    `UPDATE sites SET name = ?, theme = ?, sections = ?, layout = ?, custom_domain = ?,
     seo_title = ?, seo_description = ?, updated_at = datetime('now') WHERE id = ?`
  ).run(
    name,
    JSON.stringify(theme),
    JSON.stringify(sections),
    JSON.stringify(layout),
    customDomain || null,
    sections.seo.title,
    sections.seo.description,
    req.site.id
  );

  // the Stripe key is write-only: stored encrypted, never sent back to the page
  if (b.stripe_key_remove === '1') db.prepare("UPDATE sites SET stripe_key_enc = '', stripe_key_hint = '' WHERE id = ?").run(req.site.id);
  else if (payments.validKey(b.stripe_key)) {
    const k = String(b.stripe_key).trim();
    db.prepare('UPDATE sites SET stripe_key_enc = ?, stripe_key_hint = ? WHERE id = ?').run(payments.encryptKey(k), payments.keyHint(k), req.site.id);
  }

  invalidateSiteCache(req.site);
  if (customDomain) cache.invalidatePrefix(`${customDomain}:`);

  if (wantsJson(req)) {
    return res.json({ ok: true, savedAt: new Date().toISOString() });
  }
  res.redirect(`/sites/${req.site.id}/edit?saved=1`);
});

app.post('/sites/:id/upload', requireAuth, loadOwnedSite, (req, res) => {
  upload.single('image')(req, res, async (err) => {
    if (err) return res.status(400).json({ ok: false, error: err.message });
    if (!req.file) return res.status(400).json({ ok: false, error: 'No file received.' });
    await optimizeUpload(req.file);
    res.json({ ok: true, url: `/uploads/${req.file.filename}` });
  });
});

// ---- publish history: preview and roll back to an earlier publish ----
function loadPublish(req, res, next) {
  const row = /^\d+$/.test(req.params.hid) ? db.prepare('SELECT * FROM publish_history WHERE id = ? AND site_id = ?').get(req.params.hid, req.site.id) : null;
  if (!row) return res.status(404).render('not-found');
  req.publish = row;
  next();
}
const HISTORY_MSG = { rollback: 'Rolled back. The site now shows that earlier version.', nlok: 'The matching Netlify deploy was made live again too.', nlfail: 'The content was rolled back, but Netlify could not restore its earlier deploy. Use "Publish again" on the Publish online page to update the Netlify copy.', nlskip: 'Netlify was not touched. Use "Publish again" on the Publish online page to update the Netlify copy.' };
app.get('/sites/:id/history', requireAuth, loadOwnedSite, (req, res) => {
  const rows = db.prepare('SELECT id, kind, deploy_id, label, created_at FROM publish_history WHERE site_id = ? ORDER BY id DESC').all(req.site.id);
  res.render('history', { site: req.site, rows, msgs: HISTORY_MSG, flash: ['rollback', 'nlok', 'nlfail', 'nlskip'].filter(k => str(req.query[k], 3) === '1'), canNetlify: netlify.isConfigured() && !!req.site.netlify_site_id });
});
function renderPublishPreview(req, res, page) {
  const p = req.publish;
  let site;
  try { site = hydrateSite({ ...req.site, id: 0, slug: 'preview', theme: p.theme, sections: p.sections, layout: p.layout, published: 0, custom_domain: null }); } catch { return res.status(404).render('not-found'); }
  renderSitePage(req, res, null, { site, page, basePath: `/sites/${req.site.id}/history/${p.id}/view`, preview: true, hideMotionBar: true, contactSent: false, contactError: false, cacheKey: null });
}
app.get('/sites/:id/history/:hid/view', requireAuth, loadOwnedSite, loadPublish, (req, res) => renderPublishPreview(req, res, 'home'));
app.get('/sites/:id/history/:hid/view/:page', requireAuth, loadOwnedSite, loadPublish, (req, res) => renderPublishPreview(req, res, req.params.page));
app.post('/sites/:id/history/:hid/rollback', requireAuth, loadOwnedSite, loadPublish, async (req, res) => {
  const site = req.site, p = req.publish;
  saveVersion(site.id, site.theme, site.sections, site.layout, 'Before rollback');
  let seo = { title: '', description: '' };
  try { const sc = JSON.parse(p.sections); seo = { title: (sc.seo && sc.seo.title) || '', description: (sc.seo && sc.seo.description) || '' }; } catch { /* keep blanks */ }
  db.prepare(`UPDATE sites SET theme = ?, sections = ?, layout = ?, seo_title = ?, seo_description = ?, updated_at = datetime('now') WHERE id = ?`)
    .run(p.theme, p.sections, p.layout, seo.title, seo.description, site.id);
  invalidateSiteCache(site);
  let nl = 'nlskip';
  if (p.kind === 'netlify' && p.deploy_id && site.netlify_site_id && netlify.isConfigured()) {
    try { await netlify.restoreDeploy(site.netlify_site_id, p.deploy_id); nl = 'nlok'; db.prepare("UPDATE sites SET netlify_deployed_at = datetime('now') WHERE id = ?").run(site.id); } catch (err) { console.error('Netlify restore failed:', err.message); nl = 'nlfail'; }
  } else if (p.kind !== 'netlify') nl = '';
  const after = hydrateSite(db.prepare('SELECT * FROM sites WHERE id = ?').get(site.id));
  recordPublish({ ...site, theme: after.theme, sections: after.sections, layout: after.layout }, 'rollback', p.kind === 'netlify' && nl === 'nlok' ? p.deploy_id : '', `Rolled back to ${p.created_at}`);
  res.redirect(`/sites/${site.id}/history?rollback=1${nl ? '&' + nl + '=1' : ''}`);
});

// ---- pre-publish quality check (contrast, tap targets, images, fonts) ----
const UPLOADS_DIR = path.join(__dirname, 'public', 'uploads');
function renderHomeHtml(req, res, site) {
  return new Promise((resolve) => {
    const cap = Object.create(res);
    const timer = setTimeout(() => resolve(''), 8000);
    cap.send = (html) => { clearTimeout(timer); resolve(String(html)); return cap; };
    cap.status = () => cap;
    try {
      renderSitePage(req, cap, (err) => { clearTimeout(timer); resolve(''); void err; }, { site, page: 'home', basePath: `/sites/${site.id}/preview`, preview: true, contactSent: false, contactError: false, cacheKey: null });
    } catch { clearTimeout(timer); resolve(''); }
  });
}
async function runQuality(req, res) {
  const html = await renderHomeHtml(req, res, req.site);
  let sharpLib = null; try { sharpLib = require('sharp'); } catch { /* optional */ }
  return quality.audit(req.site, { html, uploadsDir: UPLOADS_DIR, sharp: sharpLib });
}
app.get('/sites/:id/quality', requireAuth, loadOwnedSite, async (req, res) => {
  const report = await runQuality(req, res);
  res.render('quality', { site: req.site, report, gate: ['publish', 'hosting'].includes(req.query.gate) ? req.query.gate : '', done: str(req.query.done, 20) });
});
app.post('/sites/:id/quality/fix', requireAuth, loadOwnedSite, async (req, res) => {
  const site = req.site; const back = (q) => res.redirect(`/sites/${site.id}/quality${q ? '?' + q : ''}`);
  if (req.body.fix === 'colors') {
    // recomputed here, never trusted from the form
    const report = await runQuality(req, res);
    const fixes = report.items.map(i => i.fix).filter(f => f && f.type === 'colors');
    if (!fixes.length) return back();
    const theme = { ...site.theme };
    if (!quality.applyColorFix(theme, fixes[0])) return back();
    saveVersion(site.id, site.theme, site.sections, site.layout, 'Before quality fix (colors)');
    db.prepare('UPDATE sites SET theme = ? WHERE id = ?').run(JSON.stringify(theme), site.id);
    invalidateSiteCache(site);
    return back('done=colors');
  }
  if (req.body.fix === 'images') {
    let sharpLib = null; try { sharpLib = require('sharp'); } catch { return back(); }
    const r = await quality.optimiseImages(site, { uploadsDir: UPLOADS_DIR, sharp: sharpLib });
    if (r.count) {
      saveVersion(site.id, site.theme, site.sections, site.layout, 'Before quality fix (photos)');
      db.prepare('UPDATE sites SET theme = ?, sections = ? WHERE id = ?').run(JSON.stringify(r.theme), JSON.stringify(r.sections), site.id);
      invalidateSiteCache(site);
    }
    return back('done=images' + r.count);
  }
  back();
});
// Publishing stops at the fix list when there are real errors; "Publish anyway" on that page sets force=1.
async function qualityGate(req, res, kind) {
  if (req.body.force === '1') return false;
  const report = await runQuality(req, res);
  if (report.ok) return false;
  res.redirect(`/sites/${req.site.id}/quality?gate=${kind}`);
  return true;
}

// "Use this style" from the preview switcher (owner only; value checked against the three presets)
app.post('/sites/:id/motion', requireAuth, loadOwnedSite, (req, res) => {
  const lib = app.locals.motionLib;
  if (lib.isValid(req.body.motionStyle)) {
    saveVersion(req.site.id, req.site.theme, req.site.sections, req.site.layout, 'Before motion style change');
    db.prepare('UPDATE sites SET theme = ? WHERE id = ?').run(JSON.stringify({ ...req.site.theme, motionStyle: req.body.motionStyle }), req.site.id);
    invalidateSiteCache(req.site);
  }
  res.redirect(`/sites/${req.site.id}/preview`);
});

app.post('/sites/:id/publish', requireAuth, loadOwnedSite, async (req, res) => {
  const publish = req.body.published === '1' ? 1 : 0;
  if (publish && await qualityGate(req, res, 'publish')) return;
  db.prepare('UPDATE sites SET published = ? WHERE id = ?').run(publish, req.site.id);
  if (publish) recordPublish(req.site, 'live');
  invalidateSiteCache(req.site);
  res.redirect(`/sites/${req.site.id}/edit`);
});

app.post('/sites/:id/refresh', requireAuth, loadOwnedSite, importLimiter, async (req, res) => {
  if (!req.site.source_url) {
    return res.redirect(`/sites/${req.site.id}/edit`);
  }
  try {
    saveVersion(req.site.id, req.site.theme, req.site.sections, req.site.layout, 'Before refresh');
    const scraped = await scrapeUrl(req.site.source_url);
    db.prepare(
      `UPDATE sites SET theme = ?, sections = ?, seo_title = ?, seo_description = ?, updated_at = datetime('now') WHERE id = ?`
    ).run(
      JSON.stringify(scraped.theme),
      JSON.stringify(scraped.sections),
      scraped.sections.seo.title,
      scraped.sections.seo.description,
      req.site.id
    );
    invalidateSiteCache(req.site);
    res.redirect(`/sites/${req.site.id}/edit?refreshed=1`);
  } catch (err) {
    res.redirect(`/sites/${req.site.id}/edit`);
  }
});

app.post('/sites/:id/versions/:versionId/restore', requireAuth, loadOwnedSite, (req, res) => {
  const version = db.prepare('SELECT * FROM site_versions WHERE id = ? AND site_id = ?').get(req.params.versionId, req.site.id);
  if (version) {
    saveVersion(req.site.id, req.site.theme, req.site.sections, req.site.layout, 'Before restore');
    db.prepare(`UPDATE sites SET theme = ?, sections = ?, layout = ?, updated_at = datetime('now') WHERE id = ?`)
      .run(version.theme, version.sections, version.layout, req.site.id);
    invalidateSiteCache(req.site);
  }
  res.redirect(`/sites/${req.site.id}/edit?saved=1`);
});

app.get('/sites/:id/preview', requireAuth, loadOwnedSite, (req, res) => {
  renderSitePage(req, res, null, {
    site: req.site, page: 'home', basePath: `/sites/${req.site.id}/preview`,
    preview: true, contactSent: false, contactError: false, cacheKey: null
  });
});

app.get('/sites/:id/preview/:page', requireAuth, loadOwnedSite, (req, res) => {
  renderSitePage(req, res, null, {
    site: req.site, page: req.params.page, basePath: `/sites/${req.site.id}/preview`,
    preview: true, contactSent: false, contactError: false, cacheKey: null
  });
});

app.get('/sites/:id/preview/:prefix/:item', requireAuth, loadOwnedSite, (req, res) => {
  if (!Object.prototype.hasOwnProperty.call(ITEM_ROUTES, req.params.prefix)) return res.status(404).render('not-found');
  renderSitePage(req, res, null, {
    site: req.site, page: ITEM_ROUTES[req.params.prefix], itemSlug: req.params.item, basePath: `/sites/${req.site.id}/preview`,
    preview: true, contactSent: false, contactError: false, cacheKey: null
  });
});

// ---- public site ----
// Every section (other than the hero, which is the home page) is its own
// page: /site/:slug for home, /site/:slug/:page for everything else.
// old addresses the owner mapped to new ones (see redirects.js)
function redirectFor(row, pathname) {
  let rules;
  try { rules = redirects.clean((JSON.parse(row.sections).seo || {}).redirects); } catch { return null; }
  return rules.length ? redirects.find(rules, pathname) : null;
}
function sendRedirect(req, res, hit, basePath) {
  const q = req.url.includes('?') ? req.url.slice(req.url.indexOf('?')) : '';
  const target = hit.to.startsWith('/') ? basePath + hit.to : hit.to;
  res.redirect(hit.code, target + (target.includes('?') ? '' : q));
}
app.use('/site/:slug', (req, res, next) => {
  if ((req.method !== 'GET' && req.method !== 'HEAD') || req.path === '/') return next();
  const row = db.prepare('SELECT * FROM sites WHERE slug = ?').get(req.params.slug);
  if (!row || !row.published) return next();
  const hit = redirectFor(row, req.path);
  if (!hit) return next();
  sendRedirect(req, res, hit, `/site/${row.slug}`);
});

app.get('/site/:slug', (req, res) => {
  const row = db.prepare('SELECT * FROM sites WHERE slug = ?').get(req.params.slug);
  if (!row || !row.published) return res.status(404).render('not-found');
  if (billing.isSuspended(row)) return res.status(503).render('suspended', { name: row.name });
  const site = hydrateSite(row);
  const hasFlash = req.query.contact_sent === '1' || req.query.contact_error === '1';
  renderSitePage(req, res, null, {
    site, page: 'home', basePath: `/site/${site.slug}`,
    preview: false,
    contactSent: req.query.contact_sent === '1',
    contactError: req.query.contact_error === '1',
    cacheKey: hasFlash ? null : `${site.slug}:home`
  });
});

app.get('/site/:slug/:page', (req, res) => {
  const row = db.prepare('SELECT * FROM sites WHERE slug = ?').get(req.params.slug);
  if (!row || !row.published) return res.status(404).render('not-found');
  if (billing.isSuspended(row)) return res.status(503).render('suspended', { name: row.name });
  const site = hydrateSite(row);
  const page = req.params.page;
  const hasFlash = req.query.contact_sent === '1' || req.query.contact_error === '1';
  renderSitePage(req, res, null, {
    site, page, basePath: `/site/${site.slug}`,
    preview: false,
    contactSent: req.query.contact_sent === '1',
    contactError: req.query.contact_error === '1',
    reviewThanks: page === 'review' && req.query.thanks === '1',
    reviewError: page === 'review' && req.query.error === '1',
    cacheKey: (hasFlash || page === 'review') ? null : `${site.slug}:${page}`
  });
});

app.get('/site/:slug/:prefix/:item', (req, res) => {
  if (!Object.prototype.hasOwnProperty.call(ITEM_ROUTES, req.params.prefix)) return res.status(404).render('not-found');
  const row = db.prepare('SELECT * FROM sites WHERE slug = ?').get(req.params.slug);
  if (!row || !row.published) return res.status(404).render('not-found');
  if (billing.isSuspended(row)) return res.status(503).render('suspended', { name: row.name });
  const site = hydrateSite(row);
  renderSitePage(req, res, null, {
    site, page: ITEM_ROUTES[req.params.prefix], itemSlug: req.params.item, basePath: `/site/${site.slug}`,
    preview: false, contactSent: false, contactError: false,
    cacheKey: `${site.slug}:${req.params.prefix}/${req.params.item}`
  });
});

app.post('/site/:slug/contact', contactLimiter, (req, res) => {
  const row = db.prepare('SELECT * FROM sites WHERE slug = ?').get(req.params.slug);
  if (!row || !row.published) return res.status(404).render('not-found');
  if (billing.isSuspended(row)) return res.status(503).render('suspended', { name: row.name });
  handleContactSubmission(req, res, row, `/site/${row.slug}`);
});

const LEAD_STATUSES = leadsLib.STATUSES;
const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;
function siteToday(siteRow) {
  let tz = 'America/New_York';
  try { tz = (JSON.parse(siteRow.sections).booking || {}).timezone || tz; } catch { /* default */ }
  return booking.nowIn(tz).date;
}

app.get('/sites/:id/leads', requireAuth, loadOwnedSite, (req, res) => {
  const all = db.prepare(
    'SELECT * FROM contact_submissions WHERE site_id = ? ORDER BY id DESC LIMIT 500'
  ).all(req.site.id);
  const todayStr = siteToday(db.prepare('SELECT sections FROM sites WHERE id = ?').get(req.site.id));
  const isDue = (l) => leadsLib.OPEN.includes(l.status) && l.follow_up_at && l.follow_up_at <= todayStr;
  const counts = { all: all.length, due: all.filter(isDue).length };
  for (const st of LEAD_STATUSES) counts[st] = all.filter(l => l.status === st).length;
  const filter = (LEAD_STATUSES.includes(req.query.status) || req.query.status === 'due') ? req.query.status : 'all';
  const leads = filter === 'all' ? all : filter === 'due' ? all.filter(isDue) : all.filter(l => l.status === filter);
  const pending = db.prepare("SELECT lead_id, COUNT(*) AS n FROM followup_queue WHERE site_id = ? AND sent_at IS NULL AND canceled = 0 GROUP BY lead_id").all(req.site.id);
  const pendingBy = new Map(pending.map(p => [p.lead_id, p.n]));
  res.render('leads', { site: req.site, leads: leads.map(l => ({ ...l, due: isDue(l), pendingFollowUps: pendingBy.get(l.id) || 0, answerList: forms.parseAnswers(l.answers) })), counts, filter, statuses: LEAD_STATUSES, today: todayStr });
});

app.post('/sites/:id/leads/:leadId', requireAuth, loadOwnedSite, (req, res) => {
  const status = LEAD_STATUSES.includes(req.body.status) ? req.body.status : null;
  if (!status) return res.status(400).send('Bad status');
  const followUp = DATE_RE.test(String(req.body.follow_up_at || '')) ? req.body.follow_up_at : '';
  const info = db.prepare('UPDATE contact_submissions SET status = ?, notes = ?, follow_up_at = ?, reminded_on = ? WHERE id = ? AND site_id = ?')
    .run(status, str(req.body.notes, 1000), followUp, '', req.params.leadId, req.site.id);
  if (!info.changes) return res.status(404).send('Lead not found');
  if (status !== 'new') leadsLib.cancelPending(db, req.params.leadId); // the owner has taken over: stop automatic emails
  const back = LEAD_STATUSES.includes(req.body.filter) || req.body.filter === 'due' ? '?status=' + req.body.filter : '';
  res.redirect(`/sites/${req.site.id}/leads${back}#lead-${req.params.leadId}`);
});

// the "stop emailing me" link in follow-up emails (works on any host)
app.get('/unsubscribe/:token', (req, res) => res.render('unsubscribe', { token: req.params.token, done: false }));
app.post('/unsubscribe/:token', (req, res) => {
  leadsLib.optOut(db, req.params.token);
  res.render('unsubscribe', { token: req.params.token, done: true });
});

// spreadsheet apps run text that starts with = + - @ as a formula; defuse it
function csvCell(v) {
  let s = String(v == null ? '' : v).replace(/\r?\n/g, ' ');
  if (/^[=+\-@\t]/.test(s)) s = "'" + s;
  return `"${s.replace(/"/g, '""')}"`;
}

app.get('/sites/:id/leads.csv', requireAuth, loadOwnedSite, (req, res) => {
  const rows = db.prepare('SELECT * FROM contact_submissions WHERE site_id = ? ORDER BY id DESC').all(req.site.id);
  const lines = [['Date', 'Name', 'Email', 'Phone', 'Service', 'Message', 'Answers', 'Status', 'Follow up', 'Source', 'Notes'].map(csvCell).join(',')];
  for (const r of rows) {
    lines.push([r.created_at, r.name, r.email, r.phone, r.service, r.message, forms.answersText(forms.parseAnswers(r.answers), ' | '), r.status, r.follow_up_at, r.source, r.notes].map(csvCell).join(','));
  }
  res.attachment(`${req.site.slug}-leads.csv`).type('text/csv').send('\ufeff' + lines.join('\r\n'));
});

app.post('/site/:slug/review', reviewLimiter, (req, res) => {
  const row = db.prepare('SELECT * FROM sites WHERE slug = ?').get(req.params.slug);
  if (!row || !row.published) return res.status(404).render('not-found');
  if (billing.isSuspended(row)) return res.status(503).render('suspended', { name: row.name });
  handleReviewSubmission(req, res, row, `/site/${row.slug}`);
});

// ---- owner side of online booking ----
const BOOKING_ACTIONS = { confirm: 'confirmed', decline: 'declined', cancel: 'cancelled', done: 'done' };
app.get('/sites/:id/bookings', requireAuth, loadOwnedSite, (req, res) => {
  const b = req.site.sections.booking;
  const now = booking.nowIn(b.timezone);
  const nowStr = `${now.date} ${String(Math.floor(now.minutes / 60)).padStart(2, '0')}:${String(now.minutes % 60).padStart(2, '0')}`;
  const rows = db.prepare('SELECT * FROM bookings WHERE site_id = ? ORDER BY start_at').all(req.site.id).map(r => ({
    ...r, addonList: JSON.parse(r.addons || '[]'), detailList: JSON.parse(r.details || '[]'),
    whenText: `${booking.prettyDate(r.start_at.slice(0, 10))} at ${booking.prettyTime(r.start_at.slice(11, 16))}`,
    deposit: (() => { const d = db.prepare("SELECT status, amount_cents, currency FROM payments WHERE kind = 'deposit' AND ref_id = ? AND site_id = ? ORDER BY id DESC").get(r.id, req.site.id); return d ? { status: d.status, text: payments.money(d.amount_cents, d.currency) } : null; })()
  }));
  const waiting = rows.filter(r => r.status === 'awaiting_payment');
  const pending = rows.filter(r => r.status === 'pending' && r.start_at >= nowStr);
  const upcoming = rows.filter(r => r.status === 'confirmed' && r.start_at >= nowStr);
  const past = rows.filter(r => !pending.includes(r) && !upcoming.includes(r) && !waiting.includes(r)).reverse().slice(0, 100);
  res.render('bookings', {
    site: req.site, booking: b, pending, upcoming, past, waiting, flash: str(req.query.m, 20),
    mailConfigured: mailer.isConfigured(),
    bookUrl: req.site.custom_domain ? `https://${req.site.custom_domain}/book` : `${req.protocol}://${req.get('host')}/site/${req.site.slug}/book`
  });
});

app.post('/sites/:id/bookings/:bid', requireAuth, loadOwnedSite, (req, res) => {
  const back = (m) => res.redirect(`/sites/${req.site.id}/bookings?m=${m}`);
  const bk = db.prepare('SELECT * FROM bookings WHERE id = ? AND site_id = ?').get(req.params.bid, req.site.id);
  const status = BOOKING_ACTIONS[req.body.action];
  if (!bk || !status) return back('bad');
  if (status === 'confirmed' && bk.status !== 'pending') return back('bad');
  if (status === 'declined' && bk.status !== 'pending') return back('bad');
  if (status === 'cancelled' && !BOOKING_LIVE.includes(bk.status)) return back('bad');
  if (status === 'done' && bk.status !== 'confirmed') return back('bad');
  db.prepare('UPDATE bookings SET status = ? WHERE id = ?').run(status, bk.id);
  const event = { confirmed: 'confirmed', declined: 'declined', cancelled: 'cancelled' }[status];
  if (event && req.body.notify !== '0') emailBooking(req, req.siteRow || db.prepare('SELECT * FROM sites WHERE id = ?').get(req.site.id), { ...bk, status }, event, str(req.body.message, 500));
  back(status);
});

// load a ready-made setup for an industry (replaces services, add-ons and questions; hours stay)
app.post('/sites/:id/booking/preset', requireAuth, loadOwnedSite, (req, res) => {
  const kind = booking.PRESETS[req.body.kind] ? req.body.kind : 'generic';
  saveVersion(req.site.id, req.site.theme, req.site.sections, req.site.layout, 'Before loading a booking preset');
  const sections = { ...req.site.sections, booking: booking.applyPreset(req.site.sections.booking, kind, req.site.sections.services.items) };
  db.prepare("UPDATE sites SET sections = ?, updated_at = datetime('now') WHERE id = ?").run(JSON.stringify(sections), req.site.id);
  invalidateSiteCache(req.site);
  res.redirect(`/sites/${req.site.id}/edit?booking=1`);
});

// where customers are sent to leave a review: the site's own domain if it has one
function reviewLink(req, site) {
  return site.custom_domain ? `https://${site.custom_domain}/review` : `${req.protocol}://${req.get('host')}/site/${site.slug}/review`;
}

app.get('/sites/:id/reviews', requireAuth, loadOwnedSite, (req, res) => {
  const rows = db.prepare('SELECT * FROM review_submissions WHERE site_id = ? ORDER BY id DESC LIMIT 200').all(req.site.id);
  res.render('reviews', {
    site: req.site,
    link: reviewLink(req, req.site),
    pending: rows.filter(r => r.status === 'pending'),
    done: rows.filter(r => r.status !== 'pending').slice(0, 30),
    mailConfigured: mailer.isConfigured(),
    flash: ['approved', 'rejected', 'sent', 'sendfailed', 'full', 'bademail'].includes(req.query.m) ? req.query.m : ''
  });
});

app.post('/sites/:id/reviews/request', requireAuth, loadOwnedSite, reviewRequestLimiter, async (req, res) => {
  const back = (m) => res.redirect(`/sites/${req.site.id}/reviews?m=${m}`);
  const to = str(req.body.email, 254);
  if (!isValidEmail(to)) return back('bademail');
  const contact = req.site.sections.contact;
  try {
    const ok = await mailer.sendReviewRequest({
      to, name: str(req.body.name, 80), siteName: req.site.name, link: reviewLink(req, req.site),
      replyTo: (contact.notifyEmail && isValidEmail(contact.notifyEmail)) ? contact.notifyEmail : contact.email
    });
    back(ok ? 'sent' : 'sendfailed');
  } catch (err) {
    console.error('Review request failed:', err.message);
    back('sendfailed');
  }
});

app.post('/sites/:id/reviews/:rid', requireAuth, loadOwnedSite, (req, res) => {
  const back = (m) => res.redirect(`/sites/${req.site.id}/reviews?m=${m}`);
  const rev = db.prepare('SELECT * FROM review_submissions WHERE id = ? AND site_id = ?').get(req.params.rid, req.site.id);
  if (!rev || rev.status !== 'pending') return back('');
  if (req.body.action === 'reject') {
    db.prepare("UPDATE review_submissions SET status = 'rejected' WHERE id = ?").run(rev.id);
    return back('rejected');
  }
  if (req.body.action !== 'approve') return res.status(400).send('Bad action');
  const sections = JSON.parse(JSON.stringify(req.site.sections));
  if (sections.testimonials.items.length >= 30) return back('full');
  saveVersion(req.site.id, req.site.theme, req.site.sections, req.site.layout, 'Before adding a review');
  sections.testimonials.items.push({
    quote: rev.quote, author: rev.name, rating: rev.rating,
    date: new Date().toLocaleString('en-US', { month: 'long', year: 'numeric' })
  });
  db.prepare("UPDATE sites SET sections = ?, updated_at = datetime('now') WHERE id = ?").run(JSON.stringify(sections), req.site.id);
  db.prepare("UPDATE review_submissions SET status = 'approved' WHERE id = ?").run(rev.id);
  invalidateSiteCache(req.site);
  back('approved');
});

// ---- activity reports ----
function reportContext(site, daysParam) {
  const days = [7, 30, 90].includes(parseInt(daysParam, 10)) ? parseInt(daysParam, 10) : 30;
  const report = reports.buildReport(db, site.id, reports.rangeForDays(days));
  report.topPages = report.topPages.map(p => ({ ...p, label: reports.pageLabel(site, p.path) }));
  return { report, days };
}

app.get('/sites/:id/report', requireAuth, loadOwnedSite, (req, res) => {
  res.render('report', {
    site: req.site, ...reportContext(req.site, req.query.days),
    base: `/sites/${req.site.id}/report`, backHref: `/sites/${req.site.id}/edit`, owner: true,
    mailConfigured: mailer.isConfigured(), reportEmail: req.site.sections.meta.reportEmail,
    flash: ['sent', 'sendfailed', 'noemail'].includes(req.query.m) ? req.query.m : ''
  });
});

app.post('/sites/:id/report/send', requireAuth, loadOwnedSite, async (req, res) => {
  const days = [7, 30, 90].includes(parseInt(req.body.days, 10)) ? parseInt(req.body.days, 10) : 30;
  const back = (m) => res.redirect(`/sites/${req.site.id}/report?days=${days}&m=${m}`);
  const to = req.site.sections.meta.reportEmail;
  if (!to) return back('noemail');
  const { report } = reportContext(req.site, days);
  try {
    const ok = await mailer.sendReport({
      to, subject: `Website report (last ${days} days) — ${req.site.name}`,
      text: reports.reportEmailText(req.site, report, `last ${days} days`)
    });
    back(ok ? 'sent' : 'sendfailed');
  } catch (err) {
    console.error('Report email failed:', err.message);
    back('sendfailed');
  }
});

app.get('/client/:token/report', clientLimiter, loadClientSite, (req, res) => {
  res.render('report', {
    site: req.site, ...reportContext(req.site, req.query.days),
    base: `/client/${req.params.token}/report`, backHref: `/client/${req.params.token}`, owner: false,
    mailConfigured: false, reportEmail: '', flash: ''
  });
});

// On the first run each month, email last month's report to every published
// site whose owner entered a report address. Logged per site and month, so a
// restart never sends one twice.
async function sendDueReports() {
  if (!mailer.isConfigured()) return;
  const prev = reports.previousMonth();
  for (const row of db.prepare('SELECT * FROM sites WHERE published = 1').all()) {
    if (billing.isSuspended(row)) continue;
    try {
      const site = hydrateSite(row);
      const to = site.sections.meta.reportEmail;
      if (!to || !isValidEmail(to)) continue;
      if (db.prepare('SELECT 1 FROM report_log WHERE site_id = ? AND period = ?').get(row.id, prev.period)) continue;
      db.prepare('INSERT INTO report_log (site_id, period) VALUES (?, ?)').run(row.id, prev.period);
      const report = reports.buildReport(db, row.id, prev);
      try {
        await mailer.sendReport({
          to, subject: `Website report for ${prev.label} — ${row.name}`,
          text: reports.reportEmailText(site, report, prev.label)
        });
      } catch (err) {
        db.prepare('DELETE FROM report_log WHERE site_id = ? AND period = ?').run(row.id, prev.period); // retry next time
        throw err;
      }
    } catch (err) {
      console.error('Monthly report failed:', err.message);
    }
  }
}
if (!isTestEnv) {
  setTimeout(sendDueReports, 60 * 1000).unref();
  setInterval(sendDueReports, 6 * 60 * 60 * 1000).unref();
}

// ---- automatic follow-up emails and "follow up today" reminders ----
async function runFollowUps() {
  if (!mailer.isConfigured()) return 0;
  const base = (process.env.PUBLIC_URL || '').replace(/\/$/, '');
  return leadsLib.process(db, {
    siteFor: (id) => { const r = db.prepare('SELECT * FROM sites WHERE id = ?').get(id); return r && r.published && !billing.isSuspended(r) ? hydrateSite(r) : null; },
    send: async ({ lead, site, text, subject, optoutToken }) => {
      const c = site.sections.contact;
      const replyTo = (c.notifyEmail && isValidEmail(c.notifyEmail)) ? c.notifyEmail : c.email;
      const link = `${base || 'http://localhost:' + PORT}/unsubscribe/${optoutToken}`;
      await mailer.sendReport({ to: lead.email, subject, replyTo, text: `${text}\n\n— ${site.name}\n\nDon't want these emails? ${link}` });
    }
  });
}
async function runLeadReminders() {
  if (!mailer.isConfigured()) return;
  const sites = new Map();
  const todayFor = (id) => { if (!sites.has(id)) { const r = db.prepare('SELECT * FROM sites WHERE id = ?').get(id); sites.set(id, r || null); } return sites.get(id) ? siteToday(sites.get(id)) : '0000-00-00'; };
  const base = (process.env.PUBLIC_URL || '').replace(/\/$/, '') || `http://localhost:${PORT}`;
  for (const [siteId, g] of leadsLib.dueReminders(db, todayFor)) {
    const r = sites.get(siteId); if (!r) continue;
    const site = hydrateSite(r), c = site.sections.contact;
    if (c.remindersOff) continue;
    const to = (c.notifyEmail && isValidEmail(c.notifyEmail)) ? c.notifyEmail : c.email;
    if (!to) continue;
    const lines = g.leads.map(l => `- ${l.name || 'Someone'}${l.phone ? ' · ' + l.phone : ''}${l.email ? ' · ' + l.email : ''} (${l.status}, follow up ${l.follow_up_at})${l.notes ? ' — ' + l.notes : ''}`);
    try {
      await mailer.sendReport({ to, subject: `Follow up today: ${g.leads.length} lead${g.leads.length === 1 ? '' : 's'} — ${site.name}`, text: `These leads for ${site.name} are due for a follow-up:\n\n${lines.join('\n')}\n\nOpen them: ${base}/sites/${siteId}/leads?status=due\n` });
      leadsLib.markReminded(db, g.leads.map(l => l.id), g.today);
    } catch (e) { console.error('Lead reminder failed:', e.message); }
  }
}
if (!isTestEnv) {
  setInterval(() => runFollowUps().catch(e => console.error('Follow-ups failed:', e.message)), 10 * 60 * 1000).unref();
  setInterval(() => runPaymentSweep().catch(e => console.error('Payment sweep failed:', e.message)), 5 * 60 * 1000).unref();
  setInterval(() => runLeadReminders().catch(e => console.error('Reminders failed:', e.message)), 60 * 60 * 1000).unref();
  setTimeout(() => runLeadReminders().catch(() => {}), 90 * 1000).unref();
}
// test hooks (only exist when the suite runs the server with NODE_ENV=test and a secret header)
if (isTestEnv && process.env.NODE_ENV === 'test') {
  app.post('/__test/run-jobs', async (req, res) => {
    if (req.get('x-test-key') !== 'suite') return res.status(404).end();
    res.json({ followUps: await runFollowUps(), reminders: await runLeadReminders().then(() => true), payments: await runPaymentSweep() });
  });
  app.post('/__test/age-queue', (req, res) => {
    if (req.get('x-test-key') !== 'suite') return res.status(404).end();
    db.prepare("UPDATE followup_queue SET due_at = '2000-01-01T00:00:00.000Z' WHERE sent_at IS NULL").run();
    res.json({ ok: true });
  });
}

app.get('/robots.txt', (req, res) => {
  res.type('text/plain').send(`User-agent: *\nAllow: /site/\nDisallow: /site/*/members\nDisallow: /members\nDisallow: /dashboard\nDisallow: /sites/\n\nSitemap: ${req.protocol}://${req.get('host')}/sitemap.xml\n`);
});

app.get('/sitemap.xml', (req, res) => {
  const host = (req.hostname || '').toLowerCase();
  const origin = `${req.protocol}://${req.get('host')}`;
  const entries = [];
  const addSite = (row, base) => {
    const site = hydrateSite(row);
    const lastmod = (row.updated_at || '').slice(0, 10);
    const noindex = (k) => !!(((site.sections.seo || {}).pages || {})[k] || {}).noindex;
    const pages = ['', ...PAGE_KEYS.filter(k => pageIsAvailable(site, k) && !noindex(k)).map(k => `/${k}`)];
    // service pages are only listed once they have their own text (thin pages are noindex)
    if (pageIsAvailable(site, 'services')) {
      for (const sv of servicesWithSlugs(site.sections.services.items)) if (sv.detail) pages.push(`/services/${sv.slug}`);
    }
    // town pages only once the owner wrote text for them
    for (const ar of areasWithSlugs(site.sections.trust.serviceAreas, site.sections.trust.areaText)) if (ar.text) pages.push(`/areas/${ar.slug}`);
    if (pages.includes('/blog')) for (const po of servicesWithSlugs(site.sections.blog.items)) pages.push(`/blog/${po.slug}`);
    for (const ex of extraPageList(site)) pages.push(`/p/${ex.slug}`);
    if (legal.enabled(site)) pages.push('/privacy', '/terms');
    if (calc.isUsable(site.sections.calculator)) pages.push('/estimate');
    for (const p of pages) {
      entries.push(`  <url><loc>${base}${p || (base.endsWith('/site/' + row.slug) ? '' : '/')}</loc><lastmod>${lastmod}</lastmod></url>`);
    }
  };
  // on a site's own custom domain, list just that site, with clean URLs
  const own = host && host !== 'localhost'
    ? db.prepare('SELECT * FROM sites WHERE custom_domain = ? AND published = 1').get(host)
    : null;
  if (own && billing.isSuspended(own)) return res.status(503).type('text/plain').send('');
  if (own) {
    addSite(own, origin);
  } else {
    for (const row of db.prepare('SELECT * FROM sites WHERE published = 1').all()) {
      addSite(row, `${origin}/site/${row.slug}`);
    }
  }
  res.type('application/xml').send(
    `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${entries.join('\n')}\n</urlset>`
  );
});

// anything nothing else answered: a published site's own 404 page when the address
// belongs to a site (its custom domain, or /site/<name>/...), otherwise a plain one
app.use((req, res) => {
  if (req.method !== 'GET' && req.method !== 'HEAD') return res.status(404).render('not-found');
  const host = (req.hostname || '').toLowerCase();
  let row = null, basePath = '';
  if (host && host !== 'localhost') row = db.prepare('SELECT * FROM sites WHERE custom_domain = ? AND published = 1').get(host);
  if (!row) {
    const m = /^\/site\/([^/]+)(?:\/|$)/.exec(req.path);
    if (m) { row = db.prepare('SELECT * FROM sites WHERE slug = ? AND published = 1').get(m[1]); basePath = row ? `/site/${row.slug}` : ''; }
  }
  if (!row || billing.isSuspended(row)) return res.status(404).render('not-found');
  return siteNotFound(req, res, null, hydrateSite(row), basePath, false);
});

app.listen(PORT, () => {
  console.log(`Site generator running at http://localhost:${PORT}`);
});
